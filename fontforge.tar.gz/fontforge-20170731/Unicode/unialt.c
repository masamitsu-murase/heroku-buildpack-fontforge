#include <chardata.h>

/* This file was generated using the program 'makeutype' for Unicode_version 9.0 */

static const unichar_t str_a0[] = { 0x0020, 0 };
static const unichar_t str_a8[] = { 0x0020, 0x0308, 0 };
static const unichar_t str_aa[] = { 0x0061, 0 };
static const unichar_t str_af[] = { 0x0020, 0x0304, 0 };
static const unichar_t str_b2[] = { 0x0032, 0 };
static const unichar_t str_b3[] = { 0x0033, 0 };
static const unichar_t str_b4[] = { 0x0020, 0x0301, 0 };
static const unichar_t str_b5[] = { 0x03bc, 0 };
static const unichar_t str_b8[] = { 0x0020, 0x0327, 0 };
static const unichar_t str_b9[] = { 0x0031, 0 };
static const unichar_t str_ba[] = { 0x006f, 0 };
static const unichar_t str_bc[] = { 0x0031, 0x2044, 0x0034, 0 };
static const unichar_t str_bd[] = { 0x0031, 0x2044, 0x0032, 0 };
static const unichar_t str_be[] = { 0x0033, 0x2044, 0x0034, 0 };
static const unichar_t str_c0[] = { 0x0041, 0x0300, 0 };
static const unichar_t str_c1[] = { 0x0041, 0x0301, 0 };
static const unichar_t str_c2[] = { 0x0041, 0x0302, 0 };
static const unichar_t str_c3[] = { 0x0041, 0x0303, 0 };
static const unichar_t str_c4[] = { 0x0041, 0x0308, 0 };
static const unichar_t str_c5[] = { 0x0041, 0x030a, 0 };
static const unichar_t str_c7[] = { 0x0043, 0x0327, 0 };
static const unichar_t str_c8[] = { 0x0045, 0x0300, 0 };
static const unichar_t str_c9[] = { 0x0045, 0x0301, 0 };
static const unichar_t str_ca[] = { 0x0045, 0x0302, 0 };
static const unichar_t str_cb[] = { 0x0045, 0x0308, 0 };
static const unichar_t str_cc[] = { 0x0049, 0x0300, 0 };
static const unichar_t str_cd[] = { 0x0049, 0x0301, 0 };
static const unichar_t str_ce[] = { 0x0049, 0x0302, 0 };
static const unichar_t str_cf[] = { 0x0049, 0x0308, 0 };
static const unichar_t str_d1[] = { 0x004e, 0x0303, 0 };
static const unichar_t str_d2[] = { 0x004f, 0x0300, 0 };
static const unichar_t str_d3[] = { 0x004f, 0x0301, 0 };
static const unichar_t str_d4[] = { 0x004f, 0x0302, 0 };
static const unichar_t str_d5[] = { 0x004f, 0x0303, 0 };
static const unichar_t str_d6[] = { 0x004f, 0x0308, 0 };
static const unichar_t str_d9[] = { 0x0055, 0x0300, 0 };
static const unichar_t str_da[] = { 0x0055, 0x0301, 0 };
static const unichar_t str_db[] = { 0x0055, 0x0302, 0 };
static const unichar_t str_dc[] = { 0x0055, 0x0308, 0 };
static const unichar_t str_dd[] = { 0x0059, 0x0301, 0 };
static const unichar_t str_e0[] = { 0x0061, 0x0300, 0 };
static const unichar_t str_e1[] = { 0x0061, 0x0301, 0 };
static const unichar_t str_e2[] = { 0x0061, 0x0302, 0 };
static const unichar_t str_e3[] = { 0x0061, 0x0303, 0 };
static const unichar_t str_e4[] = { 0x0061, 0x0308, 0 };
static const unichar_t str_e5[] = { 0x0061, 0x030a, 0 };
static const unichar_t str_e7[] = { 0x0063, 0x0327, 0 };
static const unichar_t str_e8[] = { 0x0065, 0x0300, 0 };
static const unichar_t str_e9[] = { 0x0065, 0x0301, 0 };
static const unichar_t str_ea[] = { 0x0065, 0x0302, 0 };
static const unichar_t str_eb[] = { 0x0065, 0x0308, 0 };
static const unichar_t str_ec[] = { 0x0069, 0x0300, 0 };
static const unichar_t str_ed[] = { 0x0069, 0x0301, 0 };
static const unichar_t str_ee[] = { 0x0069, 0x0302, 0 };
static const unichar_t str_ef[] = { 0x0069, 0x0308, 0 };
static const unichar_t str_f1[] = { 0x006e, 0x0303, 0 };
static const unichar_t str_f2[] = { 0x006f, 0x0300, 0 };
static const unichar_t str_f3[] = { 0x006f, 0x0301, 0 };
static const unichar_t str_f4[] = { 0x006f, 0x0302, 0 };
static const unichar_t str_f5[] = { 0x006f, 0x0303, 0 };
static const unichar_t str_f6[] = { 0x006f, 0x0308, 0 };
static const unichar_t str_f9[] = { 0x0075, 0x0300, 0 };
static const unichar_t str_fa[] = { 0x0075, 0x0301, 0 };
static const unichar_t str_fb[] = { 0x0075, 0x0302, 0 };
static const unichar_t str_fc[] = { 0x0075, 0x0308, 0 };
static const unichar_t str_fd[] = { 0x0079, 0x0301, 0 };
static const unichar_t str_ff[] = { 0x0079, 0x0308, 0 };
static const unichar_t str_100[] = { 0x0041, 0x0304, 0 };
static const unichar_t str_101[] = { 0x0061, 0x0304, 0 };
static const unichar_t str_102[] = { 0x0041, 0x0306, 0 };
static const unichar_t str_103[] = { 0x0061, 0x0306, 0 };
static const unichar_t str_104[] = { 0x0041, 0x0328, 0 };
static const unichar_t str_105[] = { 0x0061, 0x0328, 0 };
static const unichar_t str_106[] = { 0x0043, 0x0301, 0 };
static const unichar_t str_107[] = { 0x0063, 0x0301, 0 };
static const unichar_t str_108[] = { 0x0043, 0x0302, 0 };
static const unichar_t str_109[] = { 0x0063, 0x0302, 0 };
static const unichar_t str_10a[] = { 0x0043, 0x0307, 0 };
static const unichar_t str_10b[] = { 0x0063, 0x0307, 0 };
static const unichar_t str_10c[] = { 0x0043, 0x030c, 0 };
static const unichar_t str_10d[] = { 0x0063, 0x030c, 0 };
static const unichar_t str_10e[] = { 0x0044, 0x030c, 0 };
static const unichar_t str_10f[] = { 0x0064, 0x030c, 0 };
static const unichar_t str_110[] = { 0x00d0, 0 };
static const unichar_t str_112[] = { 0x0045, 0x0304, 0 };
static const unichar_t str_113[] = { 0x0065, 0x0304, 0 };
static const unichar_t str_114[] = { 0x0045, 0x0306, 0 };
static const unichar_t str_115[] = { 0x0065, 0x0306, 0 };
static const unichar_t str_116[] = { 0x0045, 0x0307, 0 };
static const unichar_t str_117[] = { 0x0065, 0x0307, 0 };
static const unichar_t str_118[] = { 0x0045, 0x0328, 0 };
static const unichar_t str_119[] = { 0x0065, 0x0328, 0 };
static const unichar_t str_11a[] = { 0x0045, 0x030c, 0 };
static const unichar_t str_11b[] = { 0x0065, 0x030c, 0 };
static const unichar_t str_11c[] = { 0x0047, 0x0302, 0 };
static const unichar_t str_11d[] = { 0x0067, 0x0302, 0 };
static const unichar_t str_11e[] = { 0x0047, 0x0306, 0 };
static const unichar_t str_11f[] = { 0x0067, 0x0306, 0 };
static const unichar_t str_120[] = { 0x0047, 0x0307, 0 };
static const unichar_t str_121[] = { 0x0067, 0x0307, 0 };
static const unichar_t str_122[] = { 0x0047, 0x0327, 0 };
static const unichar_t str_123[] = { 0x0067, 0x0327, 0 };
static const unichar_t str_124[] = { 0x0048, 0x0302, 0 };
static const unichar_t str_125[] = { 0x0068, 0x0302, 0 };
static const unichar_t str_128[] = { 0x0049, 0x0303, 0 };
static const unichar_t str_129[] = { 0x0069, 0x0303, 0 };
static const unichar_t str_12a[] = { 0x0049, 0x0304, 0 };
static const unichar_t str_12b[] = { 0x0069, 0x0304, 0 };
static const unichar_t str_12c[] = { 0x0049, 0x0306, 0 };
static const unichar_t str_12d[] = { 0x0069, 0x0306, 0 };
static const unichar_t str_12e[] = { 0x0049, 0x0328, 0 };
static const unichar_t str_12f[] = { 0x0069, 0x0328, 0 };
static const unichar_t str_130[] = { 0x0049, 0x0307, 0 };
static const unichar_t str_132[] = { 0x0049, 0x004a, 0 };
static const unichar_t str_133[] = { 0x0069, 0x006a, 0 };
static const unichar_t str_134[] = { 0x004a, 0x0302, 0 };
static const unichar_t str_135[] = { 0x006a, 0x0302, 0 };
static const unichar_t str_136[] = { 0x004b, 0x0327, 0 };
static const unichar_t str_137[] = { 0x006b, 0x0327, 0 };
static const unichar_t str_138[] = { 0x03ba, 0 };
static const unichar_t str_139[] = { 0x004c, 0x0301, 0 };
static const unichar_t str_13a[] = { 0x006c, 0x0301, 0 };
static const unichar_t str_13b[] = { 0x004c, 0x0327, 0 };
static const unichar_t str_13c[] = { 0x006c, 0x0327, 0 };
static const unichar_t str_13d[] = { 0x004c, 0x030c, 0 };
static const unichar_t str_13e[] = { 0x006c, 0x030c, 0 };
static const unichar_t str_13f[] = { 0x004c, 0x00b7, 0 };
static const unichar_t str_140[] = { 0x006c, 0x00b7, 0 };
static const unichar_t str_143[] = { 0x004e, 0x0301, 0 };
static const unichar_t str_144[] = { 0x006e, 0x0301, 0 };
static const unichar_t str_145[] = { 0x004e, 0x0327, 0 };
static const unichar_t str_146[] = { 0x006e, 0x0327, 0 };
static const unichar_t str_147[] = { 0x004e, 0x030c, 0 };
static const unichar_t str_148[] = { 0x006e, 0x030c, 0 };
static const unichar_t str_149[] = { 0x02bc, 0x006e, 0 };
static const unichar_t str_14c[] = { 0x004f, 0x0304, 0 };
static const unichar_t str_14d[] = { 0x006f, 0x0304, 0 };
static const unichar_t str_14e[] = { 0x004f, 0x0306, 0 };
static const unichar_t str_14f[] = { 0x006f, 0x0306, 0 };
static const unichar_t str_150[] = { 0x004f, 0x030b, 0 };
static const unichar_t str_151[] = { 0x006f, 0x030b, 0 };
static const unichar_t str_152[] = { 0x004f, 0x0045, 0 };
static const unichar_t str_153[] = { 0x006f, 0x0065, 0 };
static const unichar_t str_154[] = { 0x0052, 0x0301, 0 };
static const unichar_t str_155[] = { 0x0072, 0x0301, 0 };
static const unichar_t str_156[] = { 0x0052, 0x0327, 0 };
static const unichar_t str_157[] = { 0x0072, 0x0327, 0 };
static const unichar_t str_158[] = { 0x0052, 0x030c, 0 };
static const unichar_t str_159[] = { 0x0072, 0x030c, 0 };
static const unichar_t str_15a[] = { 0x0053, 0x0301, 0 };
static const unichar_t str_15b[] = { 0x0073, 0x0301, 0 };
static const unichar_t str_15c[] = { 0x0053, 0x0302, 0 };
static const unichar_t str_15d[] = { 0x0073, 0x0302, 0 };
static const unichar_t str_15e[] = { 0x0053, 0x0327, 0 };
static const unichar_t str_15f[] = { 0x0073, 0x0327, 0 };
static const unichar_t str_160[] = { 0x0053, 0x030c, 0 };
static const unichar_t str_161[] = { 0x0073, 0x030c, 0 };
static const unichar_t str_162[] = { 0x0054, 0x0327, 0 };
static const unichar_t str_163[] = { 0x0074, 0x0327, 0 };
static const unichar_t str_164[] = { 0x0054, 0x030c, 0 };
static const unichar_t str_165[] = { 0x0074, 0x030c, 0 };
static const unichar_t str_168[] = { 0x0055, 0x0303, 0 };
static const unichar_t str_169[] = { 0x0075, 0x0303, 0 };
static const unichar_t str_16a[] = { 0x0055, 0x0304, 0 };
static const unichar_t str_16b[] = { 0x0075, 0x0304, 0 };
static const unichar_t str_16c[] = { 0x0055, 0x0306, 0 };
static const unichar_t str_16d[] = { 0x0075, 0x0306, 0 };
static const unichar_t str_16e[] = { 0x0055, 0x030a, 0 };
static const unichar_t str_16f[] = { 0x0075, 0x030a, 0 };
static const unichar_t str_170[] = { 0x0055, 0x030b, 0 };
static const unichar_t str_171[] = { 0x0075, 0x030b, 0 };
static const unichar_t str_172[] = { 0x0055, 0x0328, 0 };
static const unichar_t str_173[] = { 0x0075, 0x0328, 0 };
static const unichar_t str_174[] = { 0x0057, 0x0302, 0 };
static const unichar_t str_175[] = { 0x0077, 0x0302, 0 };
static const unichar_t str_176[] = { 0x0059, 0x0302, 0 };
static const unichar_t str_177[] = { 0x0079, 0x0302, 0 };
static const unichar_t str_178[] = { 0x0059, 0x0308, 0 };
static const unichar_t str_179[] = { 0x005a, 0x0301, 0 };
static const unichar_t str_17a[] = { 0x007a, 0x0301, 0 };
static const unichar_t str_17b[] = { 0x005a, 0x0307, 0 };
static const unichar_t str_17c[] = { 0x007a, 0x0307, 0 };
static const unichar_t str_17d[] = { 0x005a, 0x030c, 0 };
static const unichar_t str_17e[] = { 0x007a, 0x030c, 0 };
static const unichar_t str_17f[] = { 0x0073, 0 };
static const unichar_t str_182[] = { 0x0402, 0 };
static const unichar_t str_189[] = { 0x00d0, 0 };
static const unichar_t str_19e[] = { 0x03b7, 0 };
static const unichar_t str_19f[] = { 0x0398, 0 };
static const unichar_t str_1a0[] = { 0x004f, 0x031b, 0 };
static const unichar_t str_1a1[] = { 0x006f, 0x031b, 0 };
static const unichar_t str_1a9[] = { 0x03a3, 0 };
static const unichar_t str_1af[] = { 0x0055, 0x031b, 0 };
static const unichar_t str_1b0[] = { 0x0075, 0x031b, 0 };
static const unichar_t str_1c0[] = { 0x007c, 0 };
static const unichar_t str_1c1[] = { 0x007c, 0x007c, 0 };
static const unichar_t str_1c4[] = { 0x0044, 0x017d, 0 };
static const unichar_t str_1c5[] = { 0x0044, 0x017e, 0 };
static const unichar_t str_1c6[] = { 0x0064, 0x017e, 0 };
static const unichar_t str_1c7[] = { 0x004c, 0x004a, 0 };
static const unichar_t str_1c8[] = { 0x004c, 0x006a, 0 };
static const unichar_t str_1c9[] = { 0x006c, 0x006a, 0 };
static const unichar_t str_1ca[] = { 0x004e, 0x004a, 0 };
static const unichar_t str_1cb[] = { 0x004e, 0x006a, 0 };
static const unichar_t str_1cc[] = { 0x006e, 0x006a, 0 };
static const unichar_t str_1cd[] = { 0x0041, 0x030c, 0 };
static const unichar_t str_1ce[] = { 0x0061, 0x030c, 0 };
static const unichar_t str_1cf[] = { 0x0049, 0x030c, 0 };
static const unichar_t str_1d0[] = { 0x0069, 0x030c, 0 };
static const unichar_t str_1d1[] = { 0x004f, 0x030c, 0 };
static const unichar_t str_1d2[] = { 0x006f, 0x030c, 0 };
static const unichar_t str_1d3[] = { 0x0055, 0x030c, 0 };
static const unichar_t str_1d4[] = { 0x0075, 0x030c, 0 };
static const unichar_t str_1d5[] = { 0x00dc, 0x0304, 0 };
static const unichar_t str_1d6[] = { 0x00fc, 0x0304, 0 };
static const unichar_t str_1d7[] = { 0x00dc, 0x0301, 0 };
static const unichar_t str_1d8[] = { 0x00fc, 0x0301, 0 };
static const unichar_t str_1d9[] = { 0x00dc, 0x030c, 0 };
static const unichar_t str_1da[] = { 0x00fc, 0x030c, 0 };
static const unichar_t str_1db[] = { 0x00dc, 0x0300, 0 };
static const unichar_t str_1dc[] = { 0x00fc, 0x0300, 0 };
static const unichar_t str_1de[] = { 0x00c4, 0x0304, 0 };
static const unichar_t str_1df[] = { 0x00e4, 0x0304, 0 };
static const unichar_t str_1e0[] = { 0x0226, 0x0304, 0 };
static const unichar_t str_1e1[] = { 0x0227, 0x0304, 0 };
static const unichar_t str_1e2[] = { 0x00c6, 0x0304, 0 };
static const unichar_t str_1e3[] = { 0x00e6, 0x0304, 0 };
static const unichar_t str_1e6[] = { 0x0047, 0x030c, 0 };
static const unichar_t str_1e7[] = { 0x0067, 0x030c, 0 };
static const unichar_t str_1e8[] = { 0x004b, 0x030c, 0 };
static const unichar_t str_1e9[] = { 0x006b, 0x030c, 0 };
static const unichar_t str_1ea[] = { 0x004f, 0x0328, 0 };
static const unichar_t str_1eb[] = { 0x006f, 0x0328, 0 };
static const unichar_t str_1ec[] = { 0x01ea, 0x0304, 0 };
static const unichar_t str_1ed[] = { 0x01eb, 0x0304, 0 };
static const unichar_t str_1ee[] = { 0x01b7, 0x030c, 0 };
static const unichar_t str_1ef[] = { 0x0292, 0x030c, 0 };
static const unichar_t str_1f0[] = { 0x006a, 0x030c, 0 };
static const unichar_t str_1f1[] = { 0x0044, 0x005a, 0 };
static const unichar_t str_1f2[] = { 0x0044, 0x007a, 0 };
static const unichar_t str_1f3[] = { 0x0064, 0x007a, 0 };
static const unichar_t str_1f4[] = { 0x0047, 0x0301, 0 };
static const unichar_t str_1f5[] = { 0x0067, 0x0301, 0 };
static const unichar_t str_1f8[] = { 0x004e, 0x0300, 0 };
static const unichar_t str_1f9[] = { 0x006e, 0x0300, 0 };
static const unichar_t str_1fa[] = { 0x00c5, 0x0301, 0 };
static const unichar_t str_1fb[] = { 0x00e5, 0x0301, 0 };
static const unichar_t str_1fc[] = { 0x00c6, 0x0301, 0 };
static const unichar_t str_1fd[] = { 0x00e6, 0x0301, 0 };
static const unichar_t str_1fe[] = { 0x00d8, 0x0301, 0 };
static const unichar_t str_1ff[] = { 0x00f8, 0x0301, 0 };
static const unichar_t str_200[] = { 0x0041, 0x030f, 0 };
static const unichar_t str_201[] = { 0x0061, 0x030f, 0 };
static const unichar_t str_202[] = { 0x0041, 0x0311, 0 };
static const unichar_t str_203[] = { 0x0061, 0x0311, 0 };
static const unichar_t str_204[] = { 0x0045, 0x030f, 0 };
static const unichar_t str_205[] = { 0x0065, 0x030f, 0 };
static const unichar_t str_206[] = { 0x0045, 0x0311, 0 };
static const unichar_t str_207[] = { 0x0065, 0x0311, 0 };
static const unichar_t str_208[] = { 0x0049, 0x030f, 0 };
static const unichar_t str_209[] = { 0x0069, 0x030f, 0 };
static const unichar_t str_20a[] = { 0x0049, 0x0311, 0 };
static const unichar_t str_20b[] = { 0x0069, 0x0311, 0 };
static const unichar_t str_20c[] = { 0x004f, 0x030f, 0 };
static const unichar_t str_20d[] = { 0x006f, 0x030f, 0 };
static const unichar_t str_20e[] = { 0x004f, 0x0311, 0 };
static const unichar_t str_20f[] = { 0x006f, 0x0311, 0 };
static const unichar_t str_210[] = { 0x0052, 0x030f, 0 };
static const unichar_t str_211[] = { 0x0072, 0x030f, 0 };
static const unichar_t str_212[] = { 0x0052, 0x0311, 0 };
static const unichar_t str_213[] = { 0x0072, 0x0311, 0 };
static const unichar_t str_214[] = { 0x0055, 0x030f, 0 };
static const unichar_t str_215[] = { 0x0075, 0x030f, 0 };
static const unichar_t str_216[] = { 0x0055, 0x0311, 0 };
static const unichar_t str_217[] = { 0x0075, 0x0311, 0 };
static const unichar_t str_218[] = { 0x0053, 0x0326, 0 };
static const unichar_t str_219[] = { 0x0073, 0x0326, 0 };
static const unichar_t str_21a[] = { 0x0054, 0x0326, 0 };
static const unichar_t str_21b[] = { 0x0074, 0x0326, 0 };
static const unichar_t str_21e[] = { 0x0048, 0x030c, 0 };
static const unichar_t str_21f[] = { 0x0068, 0x030c, 0 };
static const unichar_t str_226[] = { 0x0041, 0x0307, 0 };
static const unichar_t str_227[] = { 0x0061, 0x0307, 0 };
static const unichar_t str_228[] = { 0x0045, 0x0327, 0 };
static const unichar_t str_229[] = { 0x0065, 0x0327, 0 };
static const unichar_t str_22a[] = { 0x00d6, 0x0304, 0 };
static const unichar_t str_22b[] = { 0x00f6, 0x0304, 0 };
static const unichar_t str_22c[] = { 0x00d5, 0x0304, 0 };
static const unichar_t str_22d[] = { 0x00f5, 0x0304, 0 };
static const unichar_t str_22e[] = { 0x004f, 0x0307, 0 };
static const unichar_t str_22f[] = { 0x006f, 0x0307, 0 };
static const unichar_t str_230[] = { 0x022e, 0x0304, 0 };
static const unichar_t str_231[] = { 0x022f, 0x0304, 0 };
static const unichar_t str_232[] = { 0x0059, 0x0304, 0 };
static const unichar_t str_233[] = { 0x0079, 0x0304, 0 };
static const unichar_t str_269[] = { 0x03b9, 0 };
static const unichar_t str_278[] = { 0x03a6, 0 };
static const unichar_t str_292[] = { 0x01b7, 0 };
static const unichar_t str_299[] = { 0x0432, 0 };
static const unichar_t str_29c[] = { 0x043d, 0 };
static const unichar_t str_2b0[] = { 0x0068, 0 };
static const unichar_t str_2b1[] = { 0x0266, 0 };
static const unichar_t str_2b2[] = { 0x006a, 0 };
static const unichar_t str_2b3[] = { 0x0072, 0 };
static const unichar_t str_2b4[] = { 0x0279, 0 };
static const unichar_t str_2b5[] = { 0x027b, 0 };
static const unichar_t str_2b6[] = { 0x0281, 0 };
static const unichar_t str_2b7[] = { 0x0077, 0 };
static const unichar_t str_2b8[] = { 0x0079, 0 };
static const unichar_t str_2b9[] = { 0x0027, 0 };
static const unichar_t str_2ba[] = { 0x0022, 0 };
static const unichar_t str_2bc[] = { 0x0027, 0 };
static const unichar_t str_2c4[] = { 0x005e, 0 };
static const unichar_t str_2c6[] = { 0x005e, 0 };
static const unichar_t str_2c8[] = { 0x0027, 0 };
static const unichar_t str_2d8[] = { 0x0020, 0x0306, 0 };
static const unichar_t str_2d9[] = { 0x0020, 0x0307, 0 };
static const unichar_t str_2da[] = { 0x0020, 0x030a, 0 };
static const unichar_t str_2db[] = { 0x0020, 0x0328, 0 };
static const unichar_t str_2dc[] = { 0x0020, 0x0303, 0 };
static const unichar_t str_2dd[] = { 0x0020, 0x030b, 0 };
static const unichar_t str_2e0[] = { 0x0263, 0 };
static const unichar_t str_2e1[] = { 0x006c, 0 };
static const unichar_t str_2e2[] = { 0x0073, 0 };
static const unichar_t str_2e3[] = { 0x0078, 0 };
static const unichar_t str_2e4[] = { 0x0295, 0 };
static const unichar_t str_301[] = { 0x00b4, 0 };
static const unichar_t str_302[] = { 0x005e, 0 };
static const unichar_t str_303[] = { 0x007e, 0 };
static const unichar_t str_308[] = { 0x00a8, 0 };
static const unichar_t str_30a[] = { 0x00b0, 0 };
static const unichar_t str_30b[] = { 0x0022, 0 };
static const unichar_t str_30e[] = { 0x0022, 0 };
static const unichar_t str_327[] = { 0x00b8, 0 };
static const unichar_t str_340[] = { 0x0300, 0 };
static const unichar_t str_341[] = { 0x0301, 0 };
static const unichar_t str_343[] = { 0x0313, 0 };
static const unichar_t str_344[] = { 0x0308, 0x0301, 0 };
static const unichar_t str_374[] = { 0x02b9, 0 };
static const unichar_t str_375[] = { 0x02cf, 0 };
static const unichar_t str_37a[] = { 0x0020, 0x0345, 0 };
static const unichar_t str_37e[] = { 0x003b, 0 };
static const unichar_t str_384[] = { 0x0020, 0x0301, 0 };
static const unichar_t str_385[] = { 0x00a8, 0x0301, 0 };
static const unichar_t str_386[] = { 0x0391, 0x0301, 0 };
static const unichar_t str_387[] = { 0x00b7, 0 };
static const unichar_t str_388[] = { 0x0395, 0x0301, 0 };
static const unichar_t str_389[] = { 0x0397, 0x0301, 0 };
static const unichar_t str_38a[] = { 0x0399, 0x0301, 0 };
static const unichar_t str_38c[] = { 0x039f, 0x0301, 0 };
static const unichar_t str_38e[] = { 0x03a5, 0x0301, 0 };
static const unichar_t str_38f[] = { 0x03a9, 0x0301, 0 };
static const unichar_t str_390[] = { 0x03ca, 0x0301, 0 };
static const unichar_t str_391[] = { 0x0041, 0 };
static const unichar_t str_392[] = { 0x0042, 0 };
static const unichar_t str_393[] = { 0x0413, 0 };
static const unichar_t str_395[] = { 0x0045, 0 };
static const unichar_t str_396[] = { 0x005a, 0 };
static const unichar_t str_397[] = { 0x0048, 0 };
static const unichar_t str_399[] = { 0x0049, 0 };
static const unichar_t str_39a[] = { 0x004b, 0 };
static const unichar_t str_39c[] = { 0x004d, 0 };
static const unichar_t str_39d[] = { 0x004e, 0 };
static const unichar_t str_39f[] = { 0x004f, 0 };
static const unichar_t str_3a1[] = { 0x0050, 0 };
static const unichar_t str_3a4[] = { 0x0054, 0 };
static const unichar_t str_3a5[] = { 0x0059, 0 };
static const unichar_t str_3a7[] = { 0x0058, 0 };
static const unichar_t str_3aa[] = { 0x0399, 0x0308, 0 };
static const unichar_t str_3ab[] = { 0x03a5, 0x0308, 0 };
static const unichar_t str_3ac[] = { 0x03b1, 0x0301, 0 };
static const unichar_t str_3ad[] = { 0x03b5, 0x0301, 0 };
static const unichar_t str_3ae[] = { 0x03b7, 0x0301, 0 };
static const unichar_t str_3af[] = { 0x03b9, 0x0301, 0 };
static const unichar_t str_3b0[] = { 0x03cb, 0x0301, 0 };
static const unichar_t str_3ba[] = { 0x0138, 0 };
static const unichar_t str_3bf[] = { 0x006f, 0 };
static const unichar_t str_3c1[] = { 0x0070, 0 };
static const unichar_t str_3c7[] = { 0x0078, 0 };
static const unichar_t str_3ca[] = { 0x03b9, 0x0308, 0 };
static const unichar_t str_3cb[] = { 0x03c5, 0x0308, 0 };
static const unichar_t str_3cc[] = { 0x03bf, 0x0301, 0 };
static const unichar_t str_3cd[] = { 0x03c5, 0x0301, 0 };
static const unichar_t str_3ce[] = { 0x03c9, 0x0301, 0 };
static const unichar_t str_3d0[] = { 0x03b2, 0 };
static const unichar_t str_3d1[] = { 0x03b8, 0 };
static const unichar_t str_3d2[] = { 0x03a5, 0 };
static const unichar_t str_3d3[] = { 0x03d2, 0x0301, 0 };
static const unichar_t str_3d4[] = { 0x03d2, 0x0308, 0 };
static const unichar_t str_3d5[] = { 0x03c6, 0 };
static const unichar_t str_3d6[] = { 0x03c0, 0 };
static const unichar_t str_3f0[] = { 0x03ba, 0 };
static const unichar_t str_3f1[] = { 0x03c1, 0 };
static const unichar_t str_3f2[] = { 0x03c2, 0 };
static const unichar_t str_3f4[] = { 0x0398, 0 };
static const unichar_t str_3f5[] = { 0x03b5, 0 };
static const unichar_t str_3f9[] = { 0x03a3, 0 };
static const unichar_t str_400[] = { 0x0415, 0x0300, 0 };
static const unichar_t str_401[] = { 0x0415, 0x0308, 0 };
static const unichar_t str_403[] = { 0x0413, 0x0301, 0 };
static const unichar_t str_405[] = { 0x0053, 0 };
static const unichar_t str_406[] = { 0x0049, 0 };
static const unichar_t str_407[] = { 0x0406, 0x0308, 0 };
static const unichar_t str_408[] = { 0x004a, 0 };
static const unichar_t str_40c[] = { 0x041a, 0x0301, 0 };
static const unichar_t str_40d[] = { 0x0418, 0x0300, 0 };
static const unichar_t str_40e[] = { 0x0423, 0x0306, 0 };
static const unichar_t str_410[] = { 0x0041, 0 };
static const unichar_t str_412[] = { 0x0042, 0 };
static const unichar_t str_413[] = { 0x0393, 0 };
static const unichar_t str_415[] = { 0x0045, 0 };
static const unichar_t str_419[] = { 0x0418, 0x0306, 0 };
static const unichar_t str_41a[] = { 0x004b, 0 };
static const unichar_t str_41c[] = { 0x004d, 0 };
static const unichar_t str_41d[] = { 0x0048, 0 };
static const unichar_t str_41e[] = { 0x004f, 0 };
static const unichar_t str_41f[] = { 0x03a0, 0 };
static const unichar_t str_420[] = { 0x0050, 0 };
static const unichar_t str_421[] = { 0x0043, 0 };
static const unichar_t str_422[] = { 0x0054, 0 };
static const unichar_t str_424[] = { 0x03a6, 0 };
static const unichar_t str_425[] = { 0x0058, 0 };
static const unichar_t str_430[] = { 0x0061, 0 };
static const unichar_t str_435[] = { 0x0065, 0 };
static const unichar_t str_439[] = { 0x0438, 0x0306, 0 };
static const unichar_t str_43a[] = { 0x03ba, 0 };
static const unichar_t str_43e[] = { 0x006f, 0 };
static const unichar_t str_43f[] = { 0x03c0, 0 };
static const unichar_t str_440[] = { 0x0070, 0 };
static const unichar_t str_441[] = { 0x0063, 0 };
static const unichar_t str_443[] = { 0x0079, 0 };
static const unichar_t str_445[] = { 0x0078, 0 };
static const unichar_t str_450[] = { 0x0435, 0x0300, 0 };
static const unichar_t str_451[] = { 0x0435, 0x0308, 0 };
static const unichar_t str_453[] = { 0x0433, 0x0301, 0 };
static const unichar_t str_455[] = { 0x0073, 0 };
static const unichar_t str_456[] = { 0x0069, 0 };
static const unichar_t str_457[] = { 0x0456, 0x0308, 0 };
static const unichar_t str_458[] = { 0x006a, 0 };
static const unichar_t str_45c[] = { 0x043a, 0x0301, 0 };
static const unichar_t str_45d[] = { 0x0438, 0x0300, 0 };
static const unichar_t str_45e[] = { 0x0443, 0x0306, 0 };
static const unichar_t str_470[] = { 0x03a8, 0 };
static const unichar_t str_471[] = { 0x03c8, 0 };
static const unichar_t str_476[] = { 0x0474, 0x030f, 0 };
static const unichar_t str_477[] = { 0x0475, 0x030f, 0 };
static const unichar_t str_4ae[] = { 0x0059, 0 };
static const unichar_t str_4c0[] = { 0x0049, 0 };
static const unichar_t str_4c1[] = { 0x0416, 0x0306, 0 };
static const unichar_t str_4c2[] = { 0x0436, 0x0306, 0 };
static const unichar_t str_4d0[] = { 0x0410, 0x0306, 0 };
static const unichar_t str_4d1[] = { 0x0430, 0x0306, 0 };
static const unichar_t str_4d2[] = { 0x0410, 0x0308, 0 };
static const unichar_t str_4d3[] = { 0x0430, 0x0308, 0 };
static const unichar_t str_4d4[] = { 0x00c6, 0 };
static const unichar_t str_4d5[] = { 0x00e6, 0 };
static const unichar_t str_4d6[] = { 0x0415, 0x0306, 0 };
static const unichar_t str_4d7[] = { 0x0435, 0x0306, 0 };
static const unichar_t str_4da[] = { 0x04d8, 0x0308, 0 };
static const unichar_t str_4db[] = { 0x04d9, 0x0308, 0 };
static const unichar_t str_4dc[] = { 0x0416, 0x0308, 0 };
static const unichar_t str_4dd[] = { 0x0436, 0x0308, 0 };
static const unichar_t str_4de[] = { 0x0417, 0x0308, 0 };
static const unichar_t str_4df[] = { 0x0437, 0x0308, 0 };
static const unichar_t str_4e0[] = { 0x01b7, 0 };
static const unichar_t str_4e1[] = { 0x0292, 0 };
static const unichar_t str_4e2[] = { 0x0418, 0x0304, 0 };
static const unichar_t str_4e3[] = { 0x0438, 0x0304, 0 };
static const unichar_t str_4e4[] = { 0x0418, 0x0308, 0 };
static const unichar_t str_4e5[] = { 0x0438, 0x0308, 0 };
static const unichar_t str_4e6[] = { 0x041e, 0x0308, 0 };
static const unichar_t str_4e7[] = { 0x043e, 0x0308, 0 };
static const unichar_t str_4e8[] = { 0x0398, 0 };
static const unichar_t str_4e9[] = { 0x03b8, 0 };
static const unichar_t str_4ea[] = { 0x04e8, 0x0308, 0 };
static const unichar_t str_4eb[] = { 0x04e9, 0x0308, 0 };
static const unichar_t str_4ec[] = { 0x042d, 0x0308, 0 };
static const unichar_t str_4ed[] = { 0x044d, 0x0308, 0 };
static const unichar_t str_4ee[] = { 0x0423, 0x0304, 0 };
static const unichar_t str_4ef[] = { 0x0443, 0x0304, 0 };
static const unichar_t str_4f0[] = { 0x0423, 0x0308, 0 };
static const unichar_t str_4f1[] = { 0x0443, 0x0308, 0 };
static const unichar_t str_4f2[] = { 0x0423, 0x030b, 0 };
static const unichar_t str_4f3[] = { 0x0443, 0x030b, 0 };
static const unichar_t str_4f4[] = { 0x0427, 0x0308, 0 };
static const unichar_t str_4f5[] = { 0x0447, 0x0308, 0 };
static const unichar_t str_4f8[] = { 0x042b, 0x0308, 0 };
static const unichar_t str_4f9[] = { 0x044b, 0x0308, 0 };
static const unichar_t str_54f[] = { 0x0053, 0 };
static const unichar_t str_555[] = { 0x004f, 0 };
static const unichar_t str_570[] = { 0x0068, 0 };
static const unichar_t str_578[] = { 0x006e, 0 };
static const unichar_t str_57a[] = { 0x0270, 0 };
static const unichar_t str_57d[] = { 0x0075, 0 };
static const unichar_t str_581[] = { 0x0261, 0 };
static const unichar_t str_582[] = { 0x0269, 0 };
static const unichar_t str_584[] = { 0x0066, 0 };
static const unichar_t str_585[] = { 0x006f, 0 };
static const unichar_t str_587[] = { 0x0565, 0x0582, 0 };
static const unichar_t str_589[] = { 0x003a, 0 };
static const unichar_t str_5f0[] = { 0x05d5, 0x05d5, 0 };
static const unichar_t str_5f1[] = { 0x05d5, 0x05d9, 0 };
static const unichar_t str_5f2[] = { 0x05d9, 0x05d9, 0 };
static const unichar_t str_60c[] = { 0x2018, 0 };
static const unichar_t str_621[] = { 0xfe80, 0 };
static const unichar_t str_622[] = { 0x0627, 0x0653, 0 };
static const unichar_t str_623[] = { 0x0627, 0x0654, 0 };
static const unichar_t str_624[] = { 0x0648, 0x0654, 0 };
static const unichar_t str_625[] = { 0x0627, 0x0655, 0 };
static const unichar_t str_626[] = { 0x064a, 0x0654, 0 };
static const unichar_t str_627[] = { 0xfe8d, 0 };
static const unichar_t str_628[] = { 0xfe8f, 0 };
static const unichar_t str_629[] = { 0xfe93, 0 };
static const unichar_t str_62a[] = { 0xfe95, 0 };
static const unichar_t str_62b[] = { 0xfe99, 0 };
static const unichar_t str_62c[] = { 0xfe9d, 0 };
static const unichar_t str_62d[] = { 0xfea1, 0 };
static const unichar_t str_62e[] = { 0xfea5, 0 };
static const unichar_t str_62f[] = { 0xfea9, 0 };
static const unichar_t str_630[] = { 0xfeab, 0 };
static const unichar_t str_631[] = { 0xfead, 0 };
static const unichar_t str_632[] = { 0xfeaf, 0 };
static const unichar_t str_633[] = { 0xfeb1, 0 };
static const unichar_t str_634[] = { 0xfeb5, 0 };
static const unichar_t str_635[] = { 0xfeb9, 0 };
static const unichar_t str_636[] = { 0xfebd, 0 };
static const unichar_t str_637[] = { 0xfec1, 0 };
static const unichar_t str_638[] = { 0xfec5, 0 };
static const unichar_t str_639[] = { 0xfec9, 0 };
static const unichar_t str_63a[] = { 0xfecd, 0 };
static const unichar_t str_641[] = { 0xfed1, 0 };
static const unichar_t str_642[] = { 0xfed5, 0 };
static const unichar_t str_643[] = { 0xfed9, 0 };
static const unichar_t str_644[] = { 0xfedd, 0 };
static const unichar_t str_645[] = { 0xfee1, 0 };
static const unichar_t str_646[] = { 0xfee5, 0 };
static const unichar_t str_647[] = { 0xfee9, 0 };
static const unichar_t str_648[] = { 0xfeed, 0 };
static const unichar_t str_649[] = { 0xfeef, 0 };
static const unichar_t str_64a[] = { 0xfef1, 0 };
static const unichar_t str_66a[] = { 0x0025, 0 };
static const unichar_t str_66c[] = { 0x002c, 0 };
static const unichar_t str_66d[] = { 0x22c6, 0 };
static const unichar_t str_671[] = { 0xfb50, 0 };
static const unichar_t str_675[] = { 0x0627, 0x0674, 0 };
static const unichar_t str_676[] = { 0x0648, 0x0674, 0 };
static const unichar_t str_677[] = { 0x06c7, 0x0674, 0 };
static const unichar_t str_678[] = { 0x064a, 0x0674, 0 };
static const unichar_t str_679[] = { 0xfb66, 0 };
static const unichar_t str_67a[] = { 0xfb5e, 0 };
static const unichar_t str_67b[] = { 0xfb52, 0 };
static const unichar_t str_67e[] = { 0xfb56, 0 };
static const unichar_t str_67f[] = { 0xfb62, 0 };
static const unichar_t str_680[] = { 0xfb5a, 0 };
static const unichar_t str_683[] = { 0xfb76, 0 };
static const unichar_t str_684[] = { 0xfb72, 0 };
static const unichar_t str_686[] = { 0xfb7a, 0 };
static const unichar_t str_687[] = { 0xfb7e, 0 };
static const unichar_t str_688[] = { 0xfb88, 0 };
static const unichar_t str_68c[] = { 0xfb84, 0 };
static const unichar_t str_68d[] = { 0xfb82, 0 };
static const unichar_t str_68e[] = { 0xfb86, 0 };
static const unichar_t str_691[] = { 0xfb8c, 0 };
static const unichar_t str_698[] = { 0xfb8a, 0 };
static const unichar_t str_6a4[] = { 0xfb6a, 0 };
static const unichar_t str_6a6[] = { 0xfb6e, 0 };
static const unichar_t str_6a9[] = { 0xfb8e, 0 };
static const unichar_t str_6ad[] = { 0xfbd3, 0 };
static const unichar_t str_6af[] = { 0xfb92, 0 };
static const unichar_t str_6b1[] = { 0xfb9a, 0 };
static const unichar_t str_6b3[] = { 0xfb96, 0 };
static const unichar_t str_6ba[] = { 0xfb9e, 0 };
static const unichar_t str_6bb[] = { 0xfba0, 0 };
static const unichar_t str_6be[] = { 0xfbaa, 0 };
static const unichar_t str_6c0[] = { 0x06d5, 0x0654, 0 };
static const unichar_t str_6c1[] = { 0xfba6, 0 };
static const unichar_t str_6c2[] = { 0x06c1, 0x0654, 0 };
static const unichar_t str_6c5[] = { 0xfbe0, 0 };
static const unichar_t str_6c6[] = { 0xfbd9, 0 };
static const unichar_t str_6c7[] = { 0xfbd7, 0 };
static const unichar_t str_6c8[] = { 0xfbdb, 0 };
static const unichar_t str_6c9[] = { 0xfbe2, 0 };
static const unichar_t str_6cb[] = { 0xfbde, 0 };
static const unichar_t str_6cc[] = { 0xfbfc, 0 };
static const unichar_t str_6d0[] = { 0xfbe4, 0 };
static const unichar_t str_6d2[] = { 0xfbae, 0 };
static const unichar_t str_6d3[] = { 0x06d2, 0x0654, 0 };
static const unichar_t str_6d4[] = { 0x00b7, 0 };
static const unichar_t str_929[] = { 0x0928, 0x093c, 0 };
static const unichar_t str_931[] = { 0x0930, 0x093c, 0 };
static const unichar_t str_934[] = { 0x0933, 0x093c, 0 };
static const unichar_t str_958[] = { 0x0915, 0x093c, 0 };
static const unichar_t str_959[] = { 0x0916, 0x093c, 0 };
static const unichar_t str_95a[] = { 0x0917, 0x093c, 0 };
static const unichar_t str_95b[] = { 0x091c, 0x093c, 0 };
static const unichar_t str_95c[] = { 0x0921, 0x093c, 0 };
static const unichar_t str_95d[] = { 0x0922, 0x093c, 0 };
static const unichar_t str_95e[] = { 0x092b, 0x093c, 0 };
static const unichar_t str_95f[] = { 0x092f, 0x093c, 0 };
static const unichar_t str_9cb[] = { 0x09c7, 0x09be, 0 };
static const unichar_t str_9cc[] = { 0x09c7, 0x09d7, 0 };
static const unichar_t str_9dc[] = { 0x09a1, 0x09bc, 0 };
static const unichar_t str_9dd[] = { 0x09a2, 0x09bc, 0 };
static const unichar_t str_9df[] = { 0x09af, 0x09bc, 0 };
static const unichar_t str_a33[] = { 0x0a32, 0x0a3c, 0 };
static const unichar_t str_a36[] = { 0x0a38, 0x0a3c, 0 };
static const unichar_t str_a59[] = { 0x0a16, 0x0a3c, 0 };
static const unichar_t str_a5a[] = { 0x0a17, 0x0a3c, 0 };
static const unichar_t str_a5b[] = { 0x0a1c, 0x0a3c, 0 };
static const unichar_t str_a5e[] = { 0x0a2b, 0x0a3c, 0 };
static const unichar_t str_b48[] = { 0x0b47, 0x0b56, 0 };
static const unichar_t str_b4b[] = { 0x0b47, 0x0b3e, 0 };
static const unichar_t str_b4c[] = { 0x0b47, 0x0b57, 0 };
static const unichar_t str_b5c[] = { 0x0b21, 0x0b3c, 0 };
static const unichar_t str_b5d[] = { 0x0b22, 0x0b3c, 0 };
static const unichar_t str_b94[] = { 0x0b92, 0x0bd7, 0 };
static const unichar_t str_bca[] = { 0x0bc6, 0x0bbe, 0 };
static const unichar_t str_bcb[] = { 0x0bc7, 0x0bbe, 0 };
static const unichar_t str_bcc[] = { 0x0bc6, 0x0bd7, 0 };
static const unichar_t str_c48[] = { 0x0c46, 0x0c56, 0 };
static const unichar_t str_cc0[] = { 0x0cbf, 0x0cd5, 0 };
static const unichar_t str_cc7[] = { 0x0cc6, 0x0cd5, 0 };
static const unichar_t str_cc8[] = { 0x0cc6, 0x0cd6, 0 };
static const unichar_t str_cca[] = { 0x0cc6, 0x0cc2, 0 };
static const unichar_t str_ccb[] = { 0x0cca, 0x0cd5, 0 };
static const unichar_t str_d4a[] = { 0x0d46, 0x0d3e, 0 };
static const unichar_t str_d4b[] = { 0x0d47, 0x0d3e, 0 };
static const unichar_t str_d4c[] = { 0x0d46, 0x0d57, 0 };
static const unichar_t str_dda[] = { 0x0dd9, 0x0dca, 0 };
static const unichar_t str_ddc[] = { 0x0dd9, 0x0dcf, 0 };
static const unichar_t str_ddd[] = { 0x0ddc, 0x0dca, 0 };
static const unichar_t str_dde[] = { 0x0dd9, 0x0ddf, 0 };
static const unichar_t str_e33[] = { 0x0e4d, 0x0e32, 0 };
static const unichar_t str_eb3[] = { 0x0ecd, 0x0eb2, 0 };
static const unichar_t str_edc[] = { 0x0eab, 0x0e99, 0 };
static const unichar_t str_edd[] = { 0x0eab, 0x0ea1, 0 };
static const unichar_t str_f0c[] = { 0x0f0b, 0 };
static const unichar_t str_f43[] = { 0x0f42, 0x0fb7, 0 };
static const unichar_t str_f4d[] = { 0x0f4c, 0x0fb7, 0 };
static const unichar_t str_f52[] = { 0x0f51, 0x0fb7, 0 };
static const unichar_t str_f57[] = { 0x0f56, 0x0fb7, 0 };
static const unichar_t str_f5c[] = { 0x0f5b, 0x0fb7, 0 };
static const unichar_t str_f69[] = { 0x0f40, 0x0fb5, 0 };
static const unichar_t str_f73[] = { 0x0f71, 0x0f72, 0 };
static const unichar_t str_f75[] = { 0x0f71, 0x0f74, 0 };
static const unichar_t str_f76[] = { 0x0fb2, 0x0f80, 0 };
static const unichar_t str_f77[] = { 0x0fb2, 0x0f81, 0 };
static const unichar_t str_f78[] = { 0x0fb3, 0x0f80, 0 };
static const unichar_t str_f79[] = { 0x0fb3, 0x0f81, 0 };
static const unichar_t str_f81[] = { 0x0f71, 0x0f80, 0 };
static const unichar_t str_f93[] = { 0x0f92, 0x0fb7, 0 };
static const unichar_t str_f9d[] = { 0x0f9c, 0x0fb7, 0 };
static const unichar_t str_fa2[] = { 0x0fa1, 0x0fb7, 0 };
static const unichar_t str_fa7[] = { 0x0fa6, 0x0fb7, 0 };
static const unichar_t str_fac[] = { 0x0fab, 0x0fb7, 0 };
static const unichar_t str_fb9[] = { 0x0f90, 0x0fb5, 0 };
static const unichar_t str_1026[] = { 0x1025, 0x102e, 0 };
static const unichar_t str_10fc[] = { 0x10dc, 0 };
static const unichar_t str_1101[] = { 0x1100, 0x1100, 0 };
static const unichar_t str_1104[] = { 0x1103, 0x1103, 0 };
static const unichar_t str_1108[] = { 0x1107, 0x1107, 0 };
static const unichar_t str_110a[] = { 0x1109, 0x1109, 0 };
static const unichar_t str_110d[] = { 0x110c, 0x110c, 0 };
static const unichar_t str_1113[] = { 0x1102, 0x1100, 0 };
static const unichar_t str_1114[] = { 0x1102, 0x1102, 0 };
static const unichar_t str_1115[] = { 0x1102, 0x1103, 0 };
static const unichar_t str_1116[] = { 0x1102, 0x1107, 0 };
static const unichar_t str_1117[] = { 0x1103, 0x1100, 0 };
static const unichar_t str_1118[] = { 0x1105, 0x1102, 0 };
static const unichar_t str_1119[] = { 0x1105, 0x1105, 0 };
static const unichar_t str_111a[] = { 0x1105, 0x1112, 0 };
static const unichar_t str_111b[] = { 0x1105, 0x110b, 0 };
static const unichar_t str_111c[] = { 0x1106, 0x1107, 0 };
static const unichar_t str_111d[] = { 0x1106, 0x110b, 0 };
static const unichar_t str_111e[] = { 0x1107, 0x1100, 0 };
static const unichar_t str_111f[] = { 0x1107, 0x1102, 0 };
static const unichar_t str_1120[] = { 0x1107, 0x1103, 0 };
static const unichar_t str_1121[] = { 0x1107, 0x1109, 0 };
static const unichar_t str_1122[] = { 0x1107, 0x1109, 0x1100, 0 };
static const unichar_t str_1123[] = { 0x1107, 0x1109, 0x1103, 0 };
static const unichar_t str_1124[] = { 0x1107, 0x1109, 0x1107, 0 };
static const unichar_t str_1125[] = { 0x1107, 0x1109, 0x1109, 0 };
static const unichar_t str_1126[] = { 0x1107, 0x1109, 0x110c, 0 };
static const unichar_t str_1127[] = { 0x1107, 0x110c, 0 };
static const unichar_t str_1128[] = { 0x1107, 0x110e, 0 };
static const unichar_t str_1129[] = { 0x1107, 0x1110, 0 };
static const unichar_t str_112a[] = { 0x1107, 0x1111, 0 };
static const unichar_t str_112b[] = { 0x1107, 0x110b, 0 };
static const unichar_t str_112c[] = { 0x1107, 0x1107, 0x110b, 0 };
static const unichar_t str_112d[] = { 0x1109, 0x1100, 0 };
static const unichar_t str_112e[] = { 0x1109, 0x1102, 0 };
static const unichar_t str_112f[] = { 0x1109, 0x1103, 0 };
static const unichar_t str_1130[] = { 0x1109, 0x1105, 0 };
static const unichar_t str_1131[] = { 0x1109, 0x1106, 0 };
static const unichar_t str_1132[] = { 0x1109, 0x1107, 0 };
static const unichar_t str_1133[] = { 0x1109, 0x1107, 0x1100, 0 };
static const unichar_t str_1134[] = { 0x1109, 0x1109, 0x1109, 0 };
static const unichar_t str_1135[] = { 0x1109, 0x110b, 0 };
static const unichar_t str_1136[] = { 0x1109, 0x110c, 0 };
static const unichar_t str_1137[] = { 0x1109, 0x110e, 0 };
static const unichar_t str_1138[] = { 0x1109, 0x110f, 0 };
static const unichar_t str_1139[] = { 0x1109, 0x1110, 0 };
static const unichar_t str_113a[] = { 0x1109, 0x1111, 0 };
static const unichar_t str_113b[] = { 0x1109, 0x1112, 0 };
static const unichar_t str_113d[] = { 0x113c, 0x113c, 0 };
static const unichar_t str_113f[] = { 0x113e, 0x113e, 0 };
static const unichar_t str_1141[] = { 0x110b, 0x1100, 0 };
static const unichar_t str_1142[] = { 0x110b, 0x1103, 0 };
static const unichar_t str_1143[] = { 0x110b, 0x1106, 0 };
static const unichar_t str_1144[] = { 0x110b, 0x1107, 0 };
static const unichar_t str_1145[] = { 0x110b, 0x1109, 0 };
static const unichar_t str_1146[] = { 0x110b, 0x1140, 0 };
static const unichar_t str_1147[] = { 0x110b, 0x110b, 0 };
static const unichar_t str_1148[] = { 0x110b, 0x110c, 0 };
static const unichar_t str_1149[] = { 0x110b, 0x110e, 0 };
static const unichar_t str_114a[] = { 0x110b, 0x1110, 0 };
static const unichar_t str_114b[] = { 0x110b, 0x1111, 0 };
static const unichar_t str_114d[] = { 0x110c, 0x110b, 0 };
static const unichar_t str_114f[] = { 0x114e, 0x114e, 0 };
static const unichar_t str_1151[] = { 0x1150, 0x1150, 0 };
static const unichar_t str_1152[] = { 0x110e, 0x110f, 0 };
static const unichar_t str_1153[] = { 0x110e, 0x1112, 0 };
static const unichar_t str_1156[] = { 0x1111, 0x1107, 0 };
static const unichar_t str_1157[] = { 0x1111, 0x110b, 0 };
static const unichar_t str_1158[] = { 0x1112, 0x1112, 0 };
static const unichar_t str_1162[] = { 0x1161, 0x1175, 0 };
static const unichar_t str_1164[] = { 0x1163, 0x1175, 0 };
static const unichar_t str_1166[] = { 0x1165, 0x1175, 0 };
static const unichar_t str_1168[] = { 0x1167, 0x1175, 0 };
static const unichar_t str_116a[] = { 0x1169, 0x1161, 0 };
static const unichar_t str_116b[] = { 0x1169, 0x1162, 0 };
static const unichar_t str_116c[] = { 0x1169, 0x1175, 0 };
static const unichar_t str_116f[] = { 0x116e, 0x1165, 0 };
static const unichar_t str_1170[] = { 0x116e, 0x1166, 0 };
static const unichar_t str_1171[] = { 0x116e, 0x1175, 0 };
static const unichar_t str_1174[] = { 0x1173, 0x1175, 0 };
static const unichar_t str_1176[] = { 0x1161, 0x1169, 0 };
static const unichar_t str_1177[] = { 0x1161, 0x116e, 0 };
static const unichar_t str_1178[] = { 0x1163, 0x1169, 0 };
static const unichar_t str_1179[] = { 0x1163, 0x116d, 0 };
static const unichar_t str_117a[] = { 0x1165, 0x1169, 0 };
static const unichar_t str_117b[] = { 0x1165, 0x116e, 0 };
static const unichar_t str_117c[] = { 0x1165, 0x1173, 0 };
static const unichar_t str_117d[] = { 0x1167, 0x1169, 0 };
static const unichar_t str_117e[] = { 0x1167, 0x116e, 0 };
static const unichar_t str_117f[] = { 0x1169, 0x1165, 0 };
static const unichar_t str_1180[] = { 0x1169, 0x1166, 0 };
static const unichar_t str_1181[] = { 0x1169, 0x1168, 0 };
static const unichar_t str_1182[] = { 0x1169, 0x1169, 0 };
static const unichar_t str_1183[] = { 0x1169, 0x116e, 0 };
static const unichar_t str_1184[] = { 0x116d, 0x1163, 0 };
static const unichar_t str_1185[] = { 0x116d, 0x1164, 0 };
static const unichar_t str_1186[] = { 0x116d, 0x1167, 0 };
static const unichar_t str_1187[] = { 0x116d, 0x1169, 0 };
static const unichar_t str_1188[] = { 0x116d, 0x1175, 0 };
static const unichar_t str_1189[] = { 0x116e, 0x1161, 0 };
static const unichar_t str_118a[] = { 0x116e, 0x1162, 0 };
static const unichar_t str_118b[] = { 0x116e, 0x1165, 0x1173, 0 };
static const unichar_t str_118c[] = { 0x116e, 0x1168, 0 };
static const unichar_t str_118d[] = { 0x116e, 0x116e, 0 };
static const unichar_t str_118e[] = { 0x1172, 0x1161, 0 };
static const unichar_t str_118f[] = { 0x1172, 0x1165, 0 };
static const unichar_t str_1190[] = { 0x1172, 0x1166, 0 };
static const unichar_t str_1191[] = { 0x1172, 0x1167, 0 };
static const unichar_t str_1192[] = { 0x1172, 0x1168, 0 };
static const unichar_t str_1193[] = { 0x1172, 0x116e, 0 };
static const unichar_t str_1194[] = { 0x1172, 0x1175, 0 };
static const unichar_t str_1195[] = { 0x1173, 0x116e, 0 };
static const unichar_t str_1196[] = { 0x1173, 0x1173, 0 };
static const unichar_t str_1197[] = { 0x1174, 0x116e, 0 };
static const unichar_t str_1198[] = { 0x1175, 0x1161, 0 };
static const unichar_t str_1199[] = { 0x1175, 0x1163, 0 };
static const unichar_t str_119a[] = { 0x1175, 0x1169, 0 };
static const unichar_t str_119b[] = { 0x1175, 0x116e, 0 };
static const unichar_t str_119c[] = { 0x1175, 0x1173, 0 };
static const unichar_t str_119d[] = { 0x1175, 0x119e, 0 };
static const unichar_t str_119f[] = { 0x119e, 0x1165, 0 };
static const unichar_t str_11a0[] = { 0x119e, 0x116e, 0 };
static const unichar_t str_11a1[] = { 0x119e, 0x1175, 0 };
static const unichar_t str_11a2[] = { 0x119e, 0x119e, 0 };
static const unichar_t str_11a8[] = { 0x1100, 0 };
static const unichar_t str_11a9[] = { 0x11a8, 0x11a8, 0 };
static const unichar_t str_11aa[] = { 0x11a8, 0x11ba, 0 };
static const unichar_t str_11ab[] = { 0x1102, 0 };
static const unichar_t str_11ac[] = { 0x11ab, 0x11bd, 0 };
static const unichar_t str_11ad[] = { 0x11ab, 0x11c2, 0 };
static const unichar_t str_11ae[] = { 0x1103, 0 };
static const unichar_t str_11af[] = { 0x1105, 0 };
static const unichar_t str_11b0[] = { 0x11af, 0x11a8, 0 };
static const unichar_t str_11b1[] = { 0x11af, 0x11b7, 0 };
static const unichar_t str_11b2[] = { 0x11af, 0x11b8, 0 };
static const unichar_t str_11b3[] = { 0x11af, 0x11ba, 0 };
static const unichar_t str_11b4[] = { 0x11af, 0x11c0, 0 };
static const unichar_t str_11b5[] = { 0x11af, 0x11c1, 0 };
static const unichar_t str_11b6[] = { 0x11af, 0x11c2, 0 };
static const unichar_t str_11b7[] = { 0x1106, 0 };
static const unichar_t str_11b8[] = { 0x1107, 0 };
static const unichar_t str_11b9[] = { 0x11b8, 0x11ba, 0 };
static const unichar_t str_11ba[] = { 0x1109, 0 };
static const unichar_t str_11bb[] = { 0x11ba, 0x11ba, 0 };
static const unichar_t str_11bc[] = { 0x110b, 0 };
static const unichar_t str_11bd[] = { 0x110c, 0 };
static const unichar_t str_11be[] = { 0x110e, 0 };
static const unichar_t str_11bf[] = { 0x110f, 0 };
static const unichar_t str_11c0[] = { 0x1110, 0 };
static const unichar_t str_11c1[] = { 0x1111, 0 };
static const unichar_t str_11c2[] = { 0x1112, 0 };
static const unichar_t str_11c3[] = { 0x11a8, 0x11af, 0 };
static const unichar_t str_11c4[] = { 0x11a8, 0x11ba, 0x11a8, 0 };
static const unichar_t str_11c5[] = { 0x11ab, 0x11a8, 0 };
static const unichar_t str_11c6[] = { 0x11ab, 0x11ae, 0 };
static const unichar_t str_11c7[] = { 0x11ab, 0x11ba, 0 };
static const unichar_t str_11c8[] = { 0x11ab, 0x11eb, 0 };
static const unichar_t str_11c9[] = { 0x11ab, 0x11c0, 0 };
static const unichar_t str_11ca[] = { 0x11ae, 0x11a8, 0 };
static const unichar_t str_11cb[] = { 0x11ae, 0x11af, 0 };
static const unichar_t str_11cc[] = { 0x11af, 0x11a8, 0x11ba, 0 };
static const unichar_t str_11cd[] = { 0x11af, 0x11ab, 0 };
static const unichar_t str_11ce[] = { 0x11af, 0x11ae, 0 };
static const unichar_t str_11cf[] = { 0x11af, 0x11ae, 0x11c2, 0 };
static const unichar_t str_11d0[] = { 0x11af, 0x11af, 0 };
static const unichar_t str_11d1[] = { 0x11af, 0x11b7, 0x11a8, 0 };
static const unichar_t str_11d2[] = { 0x11af, 0x11b7, 0x11ba, 0 };
static const unichar_t str_11d3[] = { 0x11af, 0x11b8, 0x11ba, 0 };
static const unichar_t str_11d4[] = { 0x11af, 0x11b8, 0x11c2, 0 };
static const unichar_t str_11d5[] = { 0x11af, 0x11e6, 0 };
static const unichar_t str_11d6[] = { 0x11af, 0x11ba, 0x11ba, 0 };
static const unichar_t str_11d7[] = { 0x11af, 0x11eb, 0 };
static const unichar_t str_11d8[] = { 0x11af, 0x11bf, 0 };
static const unichar_t str_11d9[] = { 0x11af, 0x11f9, 0 };
static const unichar_t str_11da[] = { 0x11b7, 0x11a8, 0 };
static const unichar_t str_11db[] = { 0x11b7, 0x11af, 0 };
static const unichar_t str_11dc[] = { 0x11b7, 0x11b8, 0 };
static const unichar_t str_11dd[] = { 0x11b7, 0x11ba, 0 };
static const unichar_t str_11de[] = { 0x11b7, 0x11ba, 0x11ba, 0 };
static const unichar_t str_11df[] = { 0x11b7, 0x11eb, 0 };
static const unichar_t str_11e0[] = { 0x11b7, 0x11be, 0 };
static const unichar_t str_11e1[] = { 0x11b7, 0x11c2, 0 };
static const unichar_t str_11e2[] = { 0x11b7, 0x11bc, 0 };
static const unichar_t str_11e3[] = { 0x11b8, 0x11af, 0 };
static const unichar_t str_11e4[] = { 0x11b8, 0x11c1, 0 };
static const unichar_t str_11e5[] = { 0x11b8, 0x11c2, 0 };
static const unichar_t str_11e6[] = { 0x11b8, 0x11bc, 0 };
static const unichar_t str_11e7[] = { 0x11ba, 0x11a8, 0 };
static const unichar_t str_11e8[] = { 0x11ba, 0x11ae, 0 };
static const unichar_t str_11e9[] = { 0x11ba, 0x11af, 0 };
static const unichar_t str_11ea[] = { 0x11ba, 0x11b8, 0 };
static const unichar_t str_11eb[] = { 0x1140, 0 };
static const unichar_t str_11ec[] = { 0x11bc, 0x11a8, 0 };
static const unichar_t str_11ed[] = { 0x11bc, 0x11a8, 0x11a8, 0 };
static const unichar_t str_11ee[] = { 0x11bc, 0x11bc, 0 };
static const unichar_t str_11ef[] = { 0x11bc, 0x11bf, 0 };
static const unichar_t str_11f0[] = { 0x114c, 0 };
static const unichar_t str_11f1[] = { 0x11f0, 0x11ba, 0 };
static const unichar_t str_11f2[] = { 0x11f0, 0x11eb, 0 };
static const unichar_t str_11f3[] = { 0x11c1, 0x11b8, 0 };
static const unichar_t str_11f4[] = { 0x11c1, 0x11bc, 0 };
static const unichar_t str_11f5[] = { 0x11c2, 0x11ab, 0 };
static const unichar_t str_11f6[] = { 0x11c2, 0x11af, 0 };
static const unichar_t str_11f7[] = { 0x11c2, 0x11b7, 0 };
static const unichar_t str_11f8[] = { 0x11c2, 0x11b8, 0 };
static const unichar_t str_11f9[] = { 0x1159, 0 };
static const unichar_t str_13a0[] = { 0x0044, 0 };
static const unichar_t str_13a1[] = { 0x0052, 0 };
static const unichar_t str_13a2[] = { 0x0054, 0 };
static const unichar_t str_13a9[] = { 0x0423, 0 };
static const unichar_t str_13aa[] = { 0x0041, 0 };
static const unichar_t str_13ab[] = { 0x004a, 0 };
static const unichar_t str_13ac[] = { 0x0045, 0 };
static const unichar_t str_13b1[] = { 0x0393, 0 };
static const unichar_t str_13b3[] = { 0x0057, 0 };
static const unichar_t str_13b7[] = { 0x004d, 0 };
static const unichar_t str_13bb[] = { 0x0048, 0 };
static const unichar_t str_13be[] = { 0x0398, 0 };
static const unichar_t str_13c0[] = { 0x0047, 0 };
static const unichar_t str_13c2[] = { 0x0068, 0 };
static const unichar_t str_13c3[] = { 0x005a, 0 };
static const unichar_t str_13cf[] = { 0x042c, 0 };
static const unichar_t str_13d9[] = { 0x0056, 0 };
static const unichar_t str_13da[] = { 0x0053, 0 };
static const unichar_t str_13de[] = { 0x004c, 0 };
static const unichar_t str_13df[] = { 0x0043, 0 };
static const unichar_t str_13e2[] = { 0x0050, 0 };
static const unichar_t str_13e6[] = { 0x004b, 0 };
static const unichar_t str_13f4[] = { 0x0042, 0 };
static const unichar_t str_1b06[] = { 0x1b05, 0x1b35, 0 };
static const unichar_t str_1b08[] = { 0x1b07, 0x1b35, 0 };
static const unichar_t str_1b0a[] = { 0x1b09, 0x1b35, 0 };
static const unichar_t str_1b0c[] = { 0x1b0b, 0x1b35, 0 };
static const unichar_t str_1b0e[] = { 0x1b0d, 0x1b35, 0 };
static const unichar_t str_1b12[] = { 0x1b11, 0x1b35, 0 };
static const unichar_t str_1b3b[] = { 0x1b3a, 0x1b35, 0 };
static const unichar_t str_1b3d[] = { 0x1b3c, 0x1b35, 0 };
static const unichar_t str_1b40[] = { 0x1b3e, 0x1b35, 0 };
static const unichar_t str_1b41[] = { 0x1b3f, 0x1b35, 0 };
static const unichar_t str_1b43[] = { 0x1b42, 0x1b35, 0 };
static const unichar_t str_1d2c[] = { 0x0041, 0 };
static const unichar_t str_1d2d[] = { 0x00c6, 0 };
static const unichar_t str_1d2e[] = { 0x0042, 0 };
static const unichar_t str_1d30[] = { 0x0044, 0 };
static const unichar_t str_1d31[] = { 0x0045, 0 };
static const unichar_t str_1d32[] = { 0x018e, 0 };
static const unichar_t str_1d33[] = { 0x0047, 0 };
static const unichar_t str_1d34[] = { 0x0048, 0 };
static const unichar_t str_1d35[] = { 0x0049, 0 };
static const unichar_t str_1d36[] = { 0x004a, 0 };
static const unichar_t str_1d37[] = { 0x004b, 0 };
static const unichar_t str_1d38[] = { 0x004c, 0 };
static const unichar_t str_1d39[] = { 0x004d, 0 };
static const unichar_t str_1d3a[] = { 0x004e, 0 };
static const unichar_t str_1d3c[] = { 0x004f, 0 };
static const unichar_t str_1d3d[] = { 0x0222, 0 };
static const unichar_t str_1d3e[] = { 0x0050, 0 };
static const unichar_t str_1d3f[] = { 0x0052, 0 };
static const unichar_t str_1d40[] = { 0x0054, 0 };
static const unichar_t str_1d41[] = { 0x0055, 0 };
static const unichar_t str_1d42[] = { 0x0057, 0 };
static const unichar_t str_1d43[] = { 0x0061, 0 };
static const unichar_t str_1d44[] = { 0x0250, 0 };
static const unichar_t str_1d45[] = { 0x0251, 0 };
static const unichar_t str_1d46[] = { 0x1d02, 0 };
static const unichar_t str_1d47[] = { 0x0062, 0 };
static const unichar_t str_1d48[] = { 0x0064, 0 };
static const unichar_t str_1d49[] = { 0x0065, 0 };
static const unichar_t str_1d4a[] = { 0x0259, 0 };
static const unichar_t str_1d4b[] = { 0x025b, 0 };
static const unichar_t str_1d4c[] = { 0x025c, 0 };
static const unichar_t str_1d4d[] = { 0x0067, 0 };
static const unichar_t str_1d4f[] = { 0x006b, 0 };
static const unichar_t str_1d50[] = { 0x006d, 0 };
static const unichar_t str_1d51[] = { 0x014b, 0 };
static const unichar_t str_1d52[] = { 0x006f, 0 };
static const unichar_t str_1d53[] = { 0x0254, 0 };
static const unichar_t str_1d54[] = { 0x1d16, 0 };
static const unichar_t str_1d55[] = { 0x1d17, 0 };
static const unichar_t str_1d56[] = { 0x0070, 0 };
static const unichar_t str_1d57[] = { 0x0074, 0 };
static const unichar_t str_1d58[] = { 0x0075, 0 };
static const unichar_t str_1d59[] = { 0x1d1d, 0 };
static const unichar_t str_1d5a[] = { 0x026f, 0 };
static const unichar_t str_1d5b[] = { 0x0076, 0 };
static const unichar_t str_1d5c[] = { 0x1d25, 0 };
static const unichar_t str_1d5d[] = { 0x03b2, 0 };
static const unichar_t str_1d5e[] = { 0x03b3, 0 };
static const unichar_t str_1d5f[] = { 0x03b4, 0 };
static const unichar_t str_1d60[] = { 0x03c6, 0 };
static const unichar_t str_1d61[] = { 0x03c7, 0 };
static const unichar_t str_1d62[] = { 0x0069, 0 };
static const unichar_t str_1d63[] = { 0x0072, 0 };
static const unichar_t str_1d64[] = { 0x0075, 0 };
static const unichar_t str_1d65[] = { 0x0076, 0 };
static const unichar_t str_1d66[] = { 0x03b2, 0 };
static const unichar_t str_1d67[] = { 0x03b3, 0 };
static const unichar_t str_1d68[] = { 0x03c1, 0 };
static const unichar_t str_1d69[] = { 0x03c6, 0 };
static const unichar_t str_1d6a[] = { 0x03c7, 0 };
static const unichar_t str_1d78[] = { 0x043d, 0 };
static const unichar_t str_1d9b[] = { 0x0252, 0 };
static const unichar_t str_1d9c[] = { 0x0063, 0 };
static const unichar_t str_1d9d[] = { 0x0255, 0 };
static const unichar_t str_1d9e[] = { 0x00f0, 0 };
static const unichar_t str_1d9f[] = { 0x025c, 0 };
static const unichar_t str_1da0[] = { 0x0066, 0 };
static const unichar_t str_1da1[] = { 0x025f, 0 };
static const unichar_t str_1da2[] = { 0x0261, 0 };
static const unichar_t str_1da3[] = { 0x0265, 0 };
static const unichar_t str_1da4[] = { 0x0268, 0 };
static const unichar_t str_1da5[] = { 0x0269, 0 };
static const unichar_t str_1da6[] = { 0x026a, 0 };
static const unichar_t str_1da7[] = { 0x1d7b, 0 };
static const unichar_t str_1da8[] = { 0x029d, 0 };
static const unichar_t str_1da9[] = { 0x026d, 0 };
static const unichar_t str_1daa[] = { 0x1d85, 0 };
static const unichar_t str_1dab[] = { 0x029f, 0 };
static const unichar_t str_1dac[] = { 0x0271, 0 };
static const unichar_t str_1dad[] = { 0x0270, 0 };
static const unichar_t str_1dae[] = { 0x0272, 0 };
static const unichar_t str_1daf[] = { 0x0273, 0 };
static const unichar_t str_1db0[] = { 0x0274, 0 };
static const unichar_t str_1db1[] = { 0x0275, 0 };
static const unichar_t str_1db2[] = { 0x0278, 0 };
static const unichar_t str_1db3[] = { 0x0282, 0 };
static const unichar_t str_1db4[] = { 0x0283, 0 };
static const unichar_t str_1db5[] = { 0x01ab, 0 };
static const unichar_t str_1db6[] = { 0x0289, 0 };
static const unichar_t str_1db7[] = { 0x028a, 0 };
static const unichar_t str_1db8[] = { 0x1d1c, 0 };
static const unichar_t str_1db9[] = { 0x028b, 0 };
static const unichar_t str_1dba[] = { 0x028c, 0 };
static const unichar_t str_1dbb[] = { 0x007a, 0 };
static const unichar_t str_1dbc[] = { 0x0290, 0 };
static const unichar_t str_1dbd[] = { 0x0291, 0 };
static const unichar_t str_1dbe[] = { 0x0292, 0 };
static const unichar_t str_1dbf[] = { 0x03b8, 0 };
static const unichar_t str_1e00[] = { 0x0041, 0x0325, 0 };
static const unichar_t str_1e01[] = { 0x0061, 0x0325, 0 };
static const unichar_t str_1e02[] = { 0x0042, 0x0307, 0 };
static const unichar_t str_1e03[] = { 0x0062, 0x0307, 0 };
static const unichar_t str_1e04[] = { 0x0042, 0x0323, 0 };
static const unichar_t str_1e05[] = { 0x0062, 0x0323, 0 };
static const unichar_t str_1e06[] = { 0x0042, 0x0331, 0 };
static const unichar_t str_1e07[] = { 0x0062, 0x0331, 0 };
static const unichar_t str_1e08[] = { 0x00c7, 0x0301, 0 };
static const unichar_t str_1e09[] = { 0x00e7, 0x0301, 0 };
static const unichar_t str_1e0a[] = { 0x0044, 0x0307, 0 };
static const unichar_t str_1e0b[] = { 0x0064, 0x0307, 0 };
static const unichar_t str_1e0c[] = { 0x0044, 0x0323, 0 };
static const unichar_t str_1e0d[] = { 0x0064, 0x0323, 0 };
static const unichar_t str_1e0e[] = { 0x0044, 0x0331, 0 };
static const unichar_t str_1e0f[] = { 0x0064, 0x0331, 0 };
static const unichar_t str_1e10[] = { 0x0044, 0x0327, 0 };
static const unichar_t str_1e11[] = { 0x0064, 0x0327, 0 };
static const unichar_t str_1e12[] = { 0x0044, 0x032d, 0 };
static const unichar_t str_1e13[] = { 0x0064, 0x032d, 0 };
static const unichar_t str_1e14[] = { 0x0112, 0x0300, 0 };
static const unichar_t str_1e15[] = { 0x0113, 0x0300, 0 };
static const unichar_t str_1e16[] = { 0x0112, 0x0301, 0 };
static const unichar_t str_1e17[] = { 0x0113, 0x0301, 0 };
static const unichar_t str_1e18[] = { 0x0045, 0x032d, 0 };
static const unichar_t str_1e19[] = { 0x0065, 0x032d, 0 };
static const unichar_t str_1e1a[] = { 0x0045, 0x0330, 0 };
static const unichar_t str_1e1b[] = { 0x0065, 0x0330, 0 };
static const unichar_t str_1e1c[] = { 0x0228, 0x0306, 0 };
static const unichar_t str_1e1d[] = { 0x0229, 0x0306, 0 };
static const unichar_t str_1e1e[] = { 0x0046, 0x0307, 0 };
static const unichar_t str_1e1f[] = { 0x0066, 0x0307, 0 };
static const unichar_t str_1e20[] = { 0x0047, 0x0304, 0 };
static const unichar_t str_1e21[] = { 0x0067, 0x0304, 0 };
static const unichar_t str_1e22[] = { 0x0048, 0x0307, 0 };
static const unichar_t str_1e23[] = { 0x0068, 0x0307, 0 };
static const unichar_t str_1e24[] = { 0x0048, 0x0323, 0 };
static const unichar_t str_1e25[] = { 0x0068, 0x0323, 0 };
static const unichar_t str_1e26[] = { 0x0048, 0x0308, 0 };
static const unichar_t str_1e27[] = { 0x0068, 0x0308, 0 };
static const unichar_t str_1e28[] = { 0x0048, 0x0327, 0 };
static const unichar_t str_1e29[] = { 0x0068, 0x0327, 0 };
static const unichar_t str_1e2a[] = { 0x0048, 0x032e, 0 };
static const unichar_t str_1e2b[] = { 0x0068, 0x032e, 0 };
static const unichar_t str_1e2c[] = { 0x0049, 0x0330, 0 };
static const unichar_t str_1e2d[] = { 0x0069, 0x0330, 0 };
static const unichar_t str_1e2e[] = { 0x00cf, 0x0301, 0 };
static const unichar_t str_1e2f[] = { 0x00ef, 0x0301, 0 };
static const unichar_t str_1e30[] = { 0x004b, 0x0301, 0 };
static const unichar_t str_1e31[] = { 0x006b, 0x0301, 0 };
static const unichar_t str_1e32[] = { 0x004b, 0x0323, 0 };
static const unichar_t str_1e33[] = { 0x006b, 0x0323, 0 };
static const unichar_t str_1e34[] = { 0x004b, 0x0331, 0 };
static const unichar_t str_1e35[] = { 0x006b, 0x0331, 0 };
static const unichar_t str_1e36[] = { 0x004c, 0x0323, 0 };
static const unichar_t str_1e37[] = { 0x006c, 0x0323, 0 };
static const unichar_t str_1e38[] = { 0x1e36, 0x0304, 0 };
static const unichar_t str_1e39[] = { 0x1e37, 0x0304, 0 };
static const unichar_t str_1e3a[] = { 0x004c, 0x0331, 0 };
static const unichar_t str_1e3b[] = { 0x006c, 0x0331, 0 };
static const unichar_t str_1e3c[] = { 0x004c, 0x032d, 0 };
static const unichar_t str_1e3d[] = { 0x006c, 0x032d, 0 };
static const unichar_t str_1e3e[] = { 0x004d, 0x0301, 0 };
static const unichar_t str_1e3f[] = { 0x006d, 0x0301, 0 };
static const unichar_t str_1e40[] = { 0x004d, 0x0307, 0 };
static const unichar_t str_1e41[] = { 0x006d, 0x0307, 0 };
static const unichar_t str_1e42[] = { 0x004d, 0x0323, 0 };
static const unichar_t str_1e43[] = { 0x006d, 0x0323, 0 };
static const unichar_t str_1e44[] = { 0x004e, 0x0307, 0 };
static const unichar_t str_1e45[] = { 0x006e, 0x0307, 0 };
static const unichar_t str_1e46[] = { 0x004e, 0x0323, 0 };
static const unichar_t str_1e47[] = { 0x006e, 0x0323, 0 };
static const unichar_t str_1e48[] = { 0x004e, 0x0331, 0 };
static const unichar_t str_1e49[] = { 0x006e, 0x0331, 0 };
static const unichar_t str_1e4a[] = { 0x004e, 0x032d, 0 };
static const unichar_t str_1e4b[] = { 0x006e, 0x032d, 0 };
static const unichar_t str_1e4c[] = { 0x00d5, 0x0301, 0 };
static const unichar_t str_1e4d[] = { 0x00f5, 0x0301, 0 };
static const unichar_t str_1e4e[] = { 0x00d5, 0x0308, 0 };
static const unichar_t str_1e4f[] = { 0x00f5, 0x0308, 0 };
static const unichar_t str_1e50[] = { 0x014c, 0x0300, 0 };
static const unichar_t str_1e51[] = { 0x014d, 0x0300, 0 };
static const unichar_t str_1e52[] = { 0x014c, 0x0301, 0 };
static const unichar_t str_1e53[] = { 0x014d, 0x0301, 0 };
static const unichar_t str_1e54[] = { 0x0050, 0x0301, 0 };
static const unichar_t str_1e55[] = { 0x0070, 0x0301, 0 };
static const unichar_t str_1e56[] = { 0x0050, 0x0307, 0 };
static const unichar_t str_1e57[] = { 0x0070, 0x0307, 0 };
static const unichar_t str_1e58[] = { 0x0052, 0x0307, 0 };
static const unichar_t str_1e59[] = { 0x0072, 0x0307, 0 };
static const unichar_t str_1e5a[] = { 0x0052, 0x0323, 0 };
static const unichar_t str_1e5b[] = { 0x0072, 0x0323, 0 };
static const unichar_t str_1e5c[] = { 0x1e5a, 0x0304, 0 };
static const unichar_t str_1e5d[] = { 0x1e5b, 0x0304, 0 };
static const unichar_t str_1e5e[] = { 0x0052, 0x0331, 0 };
static const unichar_t str_1e5f[] = { 0x0072, 0x0331, 0 };
static const unichar_t str_1e60[] = { 0x0053, 0x0307, 0 };
static const unichar_t str_1e61[] = { 0x0073, 0x0307, 0 };
static const unichar_t str_1e62[] = { 0x0053, 0x0323, 0 };
static const unichar_t str_1e63[] = { 0x0073, 0x0323, 0 };
static const unichar_t str_1e64[] = { 0x015a, 0x0307, 0 };
static const unichar_t str_1e65[] = { 0x015b, 0x0307, 0 };
static const unichar_t str_1e66[] = { 0x0160, 0x0307, 0 };
static const unichar_t str_1e67[] = { 0x0161, 0x0307, 0 };
static const unichar_t str_1e68[] = { 0x1e62, 0x0307, 0 };
static const unichar_t str_1e69[] = { 0x1e63, 0x0307, 0 };
static const unichar_t str_1e6a[] = { 0x0054, 0x0307, 0 };
static const unichar_t str_1e6b[] = { 0x0074, 0x0307, 0 };
static const unichar_t str_1e6c[] = { 0x0054, 0x0323, 0 };
static const unichar_t str_1e6d[] = { 0x0074, 0x0323, 0 };
static const unichar_t str_1e6e[] = { 0x0054, 0x0331, 0 };
static const unichar_t str_1e6f[] = { 0x0074, 0x0331, 0 };
static const unichar_t str_1e70[] = { 0x0054, 0x032d, 0 };
static const unichar_t str_1e71[] = { 0x0074, 0x032d, 0 };
static const unichar_t str_1e72[] = { 0x0055, 0x0324, 0 };
static const unichar_t str_1e73[] = { 0x0075, 0x0324, 0 };
static const unichar_t str_1e74[] = { 0x0055, 0x0330, 0 };
static const unichar_t str_1e75[] = { 0x0075, 0x0330, 0 };
static const unichar_t str_1e76[] = { 0x0055, 0x032d, 0 };
static const unichar_t str_1e77[] = { 0x0075, 0x032d, 0 };
static const unichar_t str_1e78[] = { 0x0168, 0x0301, 0 };
static const unichar_t str_1e79[] = { 0x0169, 0x0301, 0 };
static const unichar_t str_1e7a[] = { 0x016a, 0x0308, 0 };
static const unichar_t str_1e7b[] = { 0x016b, 0x0308, 0 };
static const unichar_t str_1e7c[] = { 0x0056, 0x0303, 0 };
static const unichar_t str_1e7d[] = { 0x0076, 0x0303, 0 };
static const unichar_t str_1e7e[] = { 0x0056, 0x0323, 0 };
static const unichar_t str_1e7f[] = { 0x0076, 0x0323, 0 };
static const unichar_t str_1e80[] = { 0x0057, 0x0300, 0 };
static const unichar_t str_1e81[] = { 0x0077, 0x0300, 0 };
static const unichar_t str_1e82[] = { 0x0057, 0x0301, 0 };
static const unichar_t str_1e83[] = { 0x0077, 0x0301, 0 };
static const unichar_t str_1e84[] = { 0x0057, 0x0308, 0 };
static const unichar_t str_1e85[] = { 0x0077, 0x0308, 0 };
static const unichar_t str_1e86[] = { 0x0057, 0x0307, 0 };
static const unichar_t str_1e87[] = { 0x0077, 0x0307, 0 };
static const unichar_t str_1e88[] = { 0x0057, 0x0323, 0 };
static const unichar_t str_1e89[] = { 0x0077, 0x0323, 0 };
static const unichar_t str_1e8a[] = { 0x0058, 0x0307, 0 };
static const unichar_t str_1e8b[] = { 0x0078, 0x0307, 0 };
static const unichar_t str_1e8c[] = { 0x0058, 0x0308, 0 };
static const unichar_t str_1e8d[] = { 0x0078, 0x0308, 0 };
static const unichar_t str_1e8e[] = { 0x0059, 0x0307, 0 };
static const unichar_t str_1e8f[] = { 0x0079, 0x0307, 0 };
static const unichar_t str_1e90[] = { 0x005a, 0x0302, 0 };
static const unichar_t str_1e91[] = { 0x007a, 0x0302, 0 };
static const unichar_t str_1e92[] = { 0x005a, 0x0323, 0 };
static const unichar_t str_1e93[] = { 0x007a, 0x0323, 0 };
static const unichar_t str_1e94[] = { 0x005a, 0x0331, 0 };
static const unichar_t str_1e95[] = { 0x007a, 0x0331, 0 };
static const unichar_t str_1e96[] = { 0x0068, 0x0331, 0 };
static const unichar_t str_1e97[] = { 0x0074, 0x0308, 0 };
static const unichar_t str_1e98[] = { 0x0077, 0x030a, 0 };
static const unichar_t str_1e99[] = { 0x0079, 0x030a, 0 };
static const unichar_t str_1e9a[] = { 0x0061, 0x02be, 0 };
static const unichar_t str_1e9b[] = { 0x017f, 0x0307, 0 };
static const unichar_t str_1ea0[] = { 0x0041, 0x0323, 0 };
static const unichar_t str_1ea1[] = { 0x0061, 0x0323, 0 };
static const unichar_t str_1ea2[] = { 0x0041, 0x0309, 0 };
static const unichar_t str_1ea3[] = { 0x0061, 0x0309, 0 };
static const unichar_t str_1ea4[] = { 0x00c2, 0x0301, 0 };
static const unichar_t str_1ea5[] = { 0x00e2, 0x0301, 0 };
static const unichar_t str_1ea6[] = { 0x00c2, 0x0300, 0 };
static const unichar_t str_1ea7[] = { 0x00e2, 0x0300, 0 };
static const unichar_t str_1ea8[] = { 0x00c2, 0x0309, 0 };
static const unichar_t str_1ea9[] = { 0x00e2, 0x0309, 0 };
static const unichar_t str_1eaa[] = { 0x00c2, 0x0303, 0 };
static const unichar_t str_1eab[] = { 0x00e2, 0x0303, 0 };
static const unichar_t str_1eac[] = { 0x1ea0, 0x0302, 0 };
static const unichar_t str_1ead[] = { 0x1ea1, 0x0302, 0 };
static const unichar_t str_1eae[] = { 0x0102, 0x0301, 0 };
static const unichar_t str_1eaf[] = { 0x0103, 0x0301, 0 };
static const unichar_t str_1eb0[] = { 0x0102, 0x0300, 0 };
static const unichar_t str_1eb1[] = { 0x0103, 0x0300, 0 };
static const unichar_t str_1eb2[] = { 0x0102, 0x0309, 0 };
static const unichar_t str_1eb3[] = { 0x0103, 0x0309, 0 };
static const unichar_t str_1eb4[] = { 0x0102, 0x0303, 0 };
static const unichar_t str_1eb5[] = { 0x0103, 0x0303, 0 };
static const unichar_t str_1eb6[] = { 0x1ea0, 0x0306, 0 };
static const unichar_t str_1eb7[] = { 0x1ea1, 0x0306, 0 };
static const unichar_t str_1eb8[] = { 0x0045, 0x0323, 0 };
static const unichar_t str_1eb9[] = { 0x0065, 0x0323, 0 };
static const unichar_t str_1eba[] = { 0x0045, 0x0309, 0 };
static const unichar_t str_1ebb[] = { 0x0065, 0x0309, 0 };
static const unichar_t str_1ebc[] = { 0x0045, 0x0303, 0 };
static const unichar_t str_1ebd[] = { 0x0065, 0x0303, 0 };
static const unichar_t str_1ebe[] = { 0x00ca, 0x0301, 0 };
static const unichar_t str_1ebf[] = { 0x00ea, 0x0301, 0 };
static const unichar_t str_1ec0[] = { 0x00ca, 0x0300, 0 };
static const unichar_t str_1ec1[] = { 0x00ea, 0x0300, 0 };
static const unichar_t str_1ec2[] = { 0x00ca, 0x0309, 0 };
static const unichar_t str_1ec3[] = { 0x00ea, 0x0309, 0 };
static const unichar_t str_1ec4[] = { 0x00ca, 0x0303, 0 };
static const unichar_t str_1ec5[] = { 0x00ea, 0x0303, 0 };
static const unichar_t str_1ec6[] = { 0x1eb8, 0x0302, 0 };
static const unichar_t str_1ec7[] = { 0x1eb9, 0x0302, 0 };
static const unichar_t str_1ec8[] = { 0x0049, 0x0309, 0 };
static const unichar_t str_1ec9[] = { 0x0069, 0x0309, 0 };
static const unichar_t str_1eca[] = { 0x0049, 0x0323, 0 };
static const unichar_t str_1ecb[] = { 0x0069, 0x0323, 0 };
static const unichar_t str_1ecc[] = { 0x004f, 0x0323, 0 };
static const unichar_t str_1ecd[] = { 0x006f, 0x0323, 0 };
static const unichar_t str_1ece[] = { 0x004f, 0x0309, 0 };
static const unichar_t str_1ecf[] = { 0x006f, 0x0309, 0 };
static const unichar_t str_1ed0[] = { 0x00d4, 0x0301, 0 };
static const unichar_t str_1ed1[] = { 0x00f4, 0x0301, 0 };
static const unichar_t str_1ed2[] = { 0x00d4, 0x0300, 0 };
static const unichar_t str_1ed3[] = { 0x00f4, 0x0300, 0 };
static const unichar_t str_1ed4[] = { 0x00d4, 0x0309, 0 };
static const unichar_t str_1ed5[] = { 0x00f4, 0x0309, 0 };
static const unichar_t str_1ed6[] = { 0x00d4, 0x0303, 0 };
static const unichar_t str_1ed7[] = { 0x00f4, 0x0303, 0 };
static const unichar_t str_1ed8[] = { 0x1ecc, 0x0302, 0 };
static const unichar_t str_1ed9[] = { 0x1ecd, 0x0302, 0 };
static const unichar_t str_1eda[] = { 0x01a0, 0x0301, 0 };
static const unichar_t str_1edb[] = { 0x01a1, 0x0301, 0 };
static const unichar_t str_1edc[] = { 0x01a0, 0x0300, 0 };
static const unichar_t str_1edd[] = { 0x01a1, 0x0300, 0 };
static const unichar_t str_1ede[] = { 0x01a0, 0x0309, 0 };
static const unichar_t str_1edf[] = { 0x01a1, 0x0309, 0 };
static const unichar_t str_1ee0[] = { 0x01a0, 0x0303, 0 };
static const unichar_t str_1ee1[] = { 0x01a1, 0x0303, 0 };
static const unichar_t str_1ee2[] = { 0x01a0, 0x0323, 0 };
static const unichar_t str_1ee3[] = { 0x01a1, 0x0323, 0 };
static const unichar_t str_1ee4[] = { 0x0055, 0x0323, 0 };
static const unichar_t str_1ee5[] = { 0x0075, 0x0323, 0 };
static const unichar_t str_1ee6[] = { 0x0055, 0x0309, 0 };
static const unichar_t str_1ee7[] = { 0x0075, 0x0309, 0 };
static const unichar_t str_1ee8[] = { 0x01af, 0x0301, 0 };
static const unichar_t str_1ee9[] = { 0x01b0, 0x0301, 0 };
static const unichar_t str_1eea[] = { 0x01af, 0x0300, 0 };
static const unichar_t str_1eeb[] = { 0x01b0, 0x0300, 0 };
static const unichar_t str_1eec[] = { 0x01af, 0x0309, 0 };
static const unichar_t str_1eed[] = { 0x01b0, 0x0309, 0 };
static const unichar_t str_1eee[] = { 0x01af, 0x0303, 0 };
static const unichar_t str_1eef[] = { 0x01b0, 0x0303, 0 };
static const unichar_t str_1ef0[] = { 0x01af, 0x0323, 0 };
static const unichar_t str_1ef1[] = { 0x01b0, 0x0323, 0 };
static const unichar_t str_1ef2[] = { 0x0059, 0x0300, 0 };
static const unichar_t str_1ef3[] = { 0x0079, 0x0300, 0 };
static const unichar_t str_1ef4[] = { 0x0059, 0x0323, 0 };
static const unichar_t str_1ef5[] = { 0x0079, 0x0323, 0 };
static const unichar_t str_1ef6[] = { 0x0059, 0x0309, 0 };
static const unichar_t str_1ef7[] = { 0x0079, 0x0309, 0 };
static const unichar_t str_1ef8[] = { 0x0059, 0x0303, 0 };
static const unichar_t str_1ef9[] = { 0x0079, 0x0303, 0 };
static const unichar_t str_1f00[] = { 0x03b1, 0x0313, 0 };
static const unichar_t str_1f01[] = { 0x03b1, 0x0314, 0 };
static const unichar_t str_1f02[] = { 0x1f00, 0x0300, 0 };
static const unichar_t str_1f03[] = { 0x1f01, 0x0300, 0 };
static const unichar_t str_1f04[] = { 0x1f00, 0x0301, 0 };
static const unichar_t str_1f05[] = { 0x1f01, 0x0301, 0 };
static const unichar_t str_1f06[] = { 0x1f00, 0x0342, 0 };
static const unichar_t str_1f07[] = { 0x1f01, 0x0342, 0 };
static const unichar_t str_1f08[] = { 0x0391, 0x0313, 0 };
static const unichar_t str_1f09[] = { 0x0391, 0x0314, 0 };
static const unichar_t str_1f0a[] = { 0x1f08, 0x0300, 0 };
static const unichar_t str_1f0b[] = { 0x1f09, 0x0300, 0 };
static const unichar_t str_1f0c[] = { 0x1f08, 0x0301, 0 };
static const unichar_t str_1f0d[] = { 0x1f09, 0x0301, 0 };
static const unichar_t str_1f0e[] = { 0x1f08, 0x0342, 0 };
static const unichar_t str_1f0f[] = { 0x1f09, 0x0342, 0 };
static const unichar_t str_1f10[] = { 0x03b5, 0x0313, 0 };
static const unichar_t str_1f11[] = { 0x03b5, 0x0314, 0 };
static const unichar_t str_1f12[] = { 0x1f10, 0x0300, 0 };
static const unichar_t str_1f13[] = { 0x1f11, 0x0300, 0 };
static const unichar_t str_1f14[] = { 0x1f10, 0x0301, 0 };
static const unichar_t str_1f15[] = { 0x1f11, 0x0301, 0 };
static const unichar_t str_1f18[] = { 0x0395, 0x0313, 0 };
static const unichar_t str_1f19[] = { 0x0395, 0x0314, 0 };
static const unichar_t str_1f1a[] = { 0x1f18, 0x0300, 0 };
static const unichar_t str_1f1b[] = { 0x1f19, 0x0300, 0 };
static const unichar_t str_1f1c[] = { 0x1f18, 0x0301, 0 };
static const unichar_t str_1f1d[] = { 0x1f19, 0x0301, 0 };
static const unichar_t str_1f20[] = { 0x03b7, 0x0313, 0 };
static const unichar_t str_1f21[] = { 0x03b7, 0x0314, 0 };
static const unichar_t str_1f22[] = { 0x1f20, 0x0300, 0 };
static const unichar_t str_1f23[] = { 0x1f21, 0x0300, 0 };
static const unichar_t str_1f24[] = { 0x1f20, 0x0301, 0 };
static const unichar_t str_1f25[] = { 0x1f21, 0x0301, 0 };
static const unichar_t str_1f26[] = { 0x1f20, 0x0342, 0 };
static const unichar_t str_1f27[] = { 0x1f21, 0x0342, 0 };
static const unichar_t str_1f28[] = { 0x0397, 0x0313, 0 };
static const unichar_t str_1f29[] = { 0x0397, 0x0314, 0 };
static const unichar_t str_1f2a[] = { 0x1f28, 0x0300, 0 };
static const unichar_t str_1f2b[] = { 0x1f29, 0x0300, 0 };
static const unichar_t str_1f2c[] = { 0x1f28, 0x0301, 0 };
static const unichar_t str_1f2d[] = { 0x1f29, 0x0301, 0 };
static const unichar_t str_1f2e[] = { 0x1f28, 0x0342, 0 };
static const unichar_t str_1f2f[] = { 0x1f29, 0x0342, 0 };
static const unichar_t str_1f30[] = { 0x03b9, 0x0313, 0 };
static const unichar_t str_1f31[] = { 0x03b9, 0x0314, 0 };
static const unichar_t str_1f32[] = { 0x1f30, 0x0300, 0 };
static const unichar_t str_1f33[] = { 0x1f31, 0x0300, 0 };
static const unichar_t str_1f34[] = { 0x1f30, 0x0301, 0 };
static const unichar_t str_1f35[] = { 0x1f31, 0x0301, 0 };
static const unichar_t str_1f36[] = { 0x1f30, 0x0342, 0 };
static const unichar_t str_1f37[] = { 0x1f31, 0x0342, 0 };
static const unichar_t str_1f38[] = { 0x0399, 0x0313, 0 };
static const unichar_t str_1f39[] = { 0x0399, 0x0314, 0 };
static const unichar_t str_1f3a[] = { 0x1f38, 0x0300, 0 };
static const unichar_t str_1f3b[] = { 0x1f39, 0x0300, 0 };
static const unichar_t str_1f3c[] = { 0x1f38, 0x0301, 0 };
static const unichar_t str_1f3d[] = { 0x1f39, 0x0301, 0 };
static const unichar_t str_1f3e[] = { 0x1f38, 0x0342, 0 };
static const unichar_t str_1f3f[] = { 0x1f39, 0x0342, 0 };
static const unichar_t str_1f40[] = { 0x03bf, 0x0313, 0 };
static const unichar_t str_1f41[] = { 0x03bf, 0x0314, 0 };
static const unichar_t str_1f42[] = { 0x1f40, 0x0300, 0 };
static const unichar_t str_1f43[] = { 0x1f41, 0x0300, 0 };
static const unichar_t str_1f44[] = { 0x1f40, 0x0301, 0 };
static const unichar_t str_1f45[] = { 0x1f41, 0x0301, 0 };
static const unichar_t str_1f48[] = { 0x039f, 0x0313, 0 };
static const unichar_t str_1f49[] = { 0x039f, 0x0314, 0 };
static const unichar_t str_1f4a[] = { 0x1f48, 0x0300, 0 };
static const unichar_t str_1f4b[] = { 0x1f49, 0x0300, 0 };
static const unichar_t str_1f4c[] = { 0x1f48, 0x0301, 0 };
static const unichar_t str_1f4d[] = { 0x1f49, 0x0301, 0 };
static const unichar_t str_1f50[] = { 0x03c5, 0x0313, 0 };
static const unichar_t str_1f51[] = { 0x03c5, 0x0314, 0 };
static const unichar_t str_1f52[] = { 0x1f50, 0x0300, 0 };
static const unichar_t str_1f53[] = { 0x1f51, 0x0300, 0 };
static const unichar_t str_1f54[] = { 0x1f50, 0x0301, 0 };
static const unichar_t str_1f55[] = { 0x1f51, 0x0301, 0 };
static const unichar_t str_1f56[] = { 0x1f50, 0x0342, 0 };
static const unichar_t str_1f57[] = { 0x1f51, 0x0342, 0 };
static const unichar_t str_1f59[] = { 0x03a5, 0x0314, 0 };
static const unichar_t str_1f5b[] = { 0x1f59, 0x0300, 0 };
static const unichar_t str_1f5d[] = { 0x1f59, 0x0301, 0 };
static const unichar_t str_1f5f[] = { 0x1f59, 0x0342, 0 };
static const unichar_t str_1f60[] = { 0x03c9, 0x0313, 0 };
static const unichar_t str_1f61[] = { 0x03c9, 0x0314, 0 };
static const unichar_t str_1f62[] = { 0x1f60, 0x0300, 0 };
static const unichar_t str_1f63[] = { 0x1f61, 0x0300, 0 };
static const unichar_t str_1f64[] = { 0x1f60, 0x0301, 0 };
static const unichar_t str_1f65[] = { 0x1f61, 0x0301, 0 };
static const unichar_t str_1f66[] = { 0x1f60, 0x0342, 0 };
static const unichar_t str_1f67[] = { 0x1f61, 0x0342, 0 };
static const unichar_t str_1f68[] = { 0x03a9, 0x0313, 0 };
static const unichar_t str_1f69[] = { 0x03a9, 0x0314, 0 };
static const unichar_t str_1f6a[] = { 0x1f68, 0x0300, 0 };
static const unichar_t str_1f6b[] = { 0x1f69, 0x0300, 0 };
static const unichar_t str_1f6c[] = { 0x1f68, 0x0301, 0 };
static const unichar_t str_1f6d[] = { 0x1f69, 0x0301, 0 };
static const unichar_t str_1f6e[] = { 0x1f68, 0x0342, 0 };
static const unichar_t str_1f6f[] = { 0x1f69, 0x0342, 0 };
static const unichar_t str_1f70[] = { 0x03b1, 0x0300, 0 };
static const unichar_t str_1f71[] = { 0x03ac, 0 };
static const unichar_t str_1f72[] = { 0x03b5, 0x0300, 0 };
static const unichar_t str_1f73[] = { 0x03ad, 0 };
static const unichar_t str_1f74[] = { 0x03b7, 0x0300, 0 };
static const unichar_t str_1f75[] = { 0x03ae, 0 };
static const unichar_t str_1f76[] = { 0x03b9, 0x0300, 0 };
static const unichar_t str_1f77[] = { 0x03af, 0 };
static const unichar_t str_1f78[] = { 0x03bf, 0x0300, 0 };
static const unichar_t str_1f79[] = { 0x03cc, 0 };
static const unichar_t str_1f7a[] = { 0x03c5, 0x0300, 0 };
static const unichar_t str_1f7b[] = { 0x03cd, 0 };
static const unichar_t str_1f7c[] = { 0x03c9, 0x0300, 0 };
static const unichar_t str_1f7d[] = { 0x03ce, 0 };
static const unichar_t str_1f80[] = { 0x1f00, 0x0345, 0 };
static const unichar_t str_1f81[] = { 0x1f01, 0x0345, 0 };
static const unichar_t str_1f82[] = { 0x1f02, 0x0345, 0 };
static const unichar_t str_1f83[] = { 0x1f03, 0x0345, 0 };
static const unichar_t str_1f84[] = { 0x1f04, 0x0345, 0 };
static const unichar_t str_1f85[] = { 0x1f05, 0x0345, 0 };
static const unichar_t str_1f86[] = { 0x1f06, 0x0345, 0 };
static const unichar_t str_1f87[] = { 0x1f07, 0x0345, 0 };
static const unichar_t str_1f88[] = { 0x1f08, 0x0345, 0 };
static const unichar_t str_1f89[] = { 0x1f09, 0x0345, 0 };
static const unichar_t str_1f8a[] = { 0x1f0a, 0x0345, 0 };
static const unichar_t str_1f8b[] = { 0x1f0b, 0x0345, 0 };
static const unichar_t str_1f8c[] = { 0x1f0c, 0x0345, 0 };
static const unichar_t str_1f8d[] = { 0x1f0d, 0x0345, 0 };
static const unichar_t str_1f8e[] = { 0x1f0e, 0x0345, 0 };
static const unichar_t str_1f8f[] = { 0x1f0f, 0x0345, 0 };
static const unichar_t str_1f90[] = { 0x1f20, 0x0345, 0 };
static const unichar_t str_1f91[] = { 0x1f21, 0x0345, 0 };
static const unichar_t str_1f92[] = { 0x1f22, 0x0345, 0 };
static const unichar_t str_1f93[] = { 0x1f23, 0x0345, 0 };
static const unichar_t str_1f94[] = { 0x1f24, 0x0345, 0 };
static const unichar_t str_1f95[] = { 0x1f25, 0x0345, 0 };
static const unichar_t str_1f96[] = { 0x1f26, 0x0345, 0 };
static const unichar_t str_1f97[] = { 0x1f27, 0x0345, 0 };
static const unichar_t str_1f98[] = { 0x1f28, 0x0345, 0 };
static const unichar_t str_1f99[] = { 0x1f29, 0x0345, 0 };
static const unichar_t str_1f9a[] = { 0x1f2a, 0x0345, 0 };
static const unichar_t str_1f9b[] = { 0x1f2b, 0x0345, 0 };
static const unichar_t str_1f9c[] = { 0x1f2c, 0x0345, 0 };
static const unichar_t str_1f9d[] = { 0x1f2d, 0x0345, 0 };
static const unichar_t str_1f9e[] = { 0x1f2e, 0x0345, 0 };
static const unichar_t str_1f9f[] = { 0x1f2f, 0x0345, 0 };
static const unichar_t str_1fa0[] = { 0x1f60, 0x0345, 0 };
static const unichar_t str_1fa1[] = { 0x1f61, 0x0345, 0 };
static const unichar_t str_1fa2[] = { 0x1f62, 0x0345, 0 };
static const unichar_t str_1fa3[] = { 0x1f63, 0x0345, 0 };
static const unichar_t str_1fa4[] = { 0x1f64, 0x0345, 0 };
static const unichar_t str_1fa5[] = { 0x1f65, 0x0345, 0 };
static const unichar_t str_1fa6[] = { 0x1f66, 0x0345, 0 };
static const unichar_t str_1fa7[] = { 0x1f67, 0x0345, 0 };
static const unichar_t str_1fa8[] = { 0x1f68, 0x0345, 0 };
static const unichar_t str_1fa9[] = { 0x1f69, 0x0345, 0 };
static const unichar_t str_1faa[] = { 0x1f6a, 0x0345, 0 };
static const unichar_t str_1fab[] = { 0x1f6b, 0x0345, 0 };
static const unichar_t str_1fac[] = { 0x1f6c, 0x0345, 0 };
static const unichar_t str_1fad[] = { 0x1f6d, 0x0345, 0 };
static const unichar_t str_1fae[] = { 0x1f6e, 0x0345, 0 };
static const unichar_t str_1faf[] = { 0x1f6f, 0x0345, 0 };
static const unichar_t str_1fb0[] = { 0x03b1, 0x0306, 0 };
static const unichar_t str_1fb1[] = { 0x03b1, 0x0304, 0 };
static const unichar_t str_1fb2[] = { 0x1f70, 0x0345, 0 };
static const unichar_t str_1fb3[] = { 0x03b1, 0x0345, 0 };
static const unichar_t str_1fb4[] = { 0x03ac, 0x0345, 0 };
static const unichar_t str_1fb6[] = { 0x03b1, 0x0342, 0 };
static const unichar_t str_1fb7[] = { 0x1fb6, 0x0345, 0 };
static const unichar_t str_1fb8[] = { 0x0391, 0x0306, 0 };
static const unichar_t str_1fb9[] = { 0x0391, 0x0304, 0 };
static const unichar_t str_1fba[] = { 0x0391, 0x0300, 0 };
static const unichar_t str_1fbb[] = { 0x0386, 0 };
static const unichar_t str_1fbc[] = { 0x0391, 0x0345, 0 };
static const unichar_t str_1fbd[] = { 0x0020, 0x0313, 0 };
static const unichar_t str_1fbe[] = { 0x03b9, 0 };
static const unichar_t str_1fbf[] = { 0x0020, 0x0313, 0 };
static const unichar_t str_1fc0[] = { 0x0020, 0x0342, 0 };
static const unichar_t str_1fc1[] = { 0x00a8, 0x0342, 0 };
static const unichar_t str_1fc2[] = { 0x1f74, 0x0345, 0 };
static const unichar_t str_1fc3[] = { 0x03b7, 0x0345, 0 };
static const unichar_t str_1fc4[] = { 0x03ae, 0x0345, 0 };
static const unichar_t str_1fc6[] = { 0x03b7, 0x0342, 0 };
static const unichar_t str_1fc7[] = { 0x1fc6, 0x0345, 0 };
static const unichar_t str_1fc8[] = { 0x0395, 0x0300, 0 };
static const unichar_t str_1fc9[] = { 0x0388, 0 };
static const unichar_t str_1fca[] = { 0x0397, 0x0300, 0 };
static const unichar_t str_1fcb[] = { 0x0389, 0 };
static const unichar_t str_1fcc[] = { 0x0397, 0x0345, 0 };
static const unichar_t str_1fcd[] = { 0x1fbf, 0x0300, 0 };
static const unichar_t str_1fce[] = { 0x1fbf, 0x0301, 0 };
static const unichar_t str_1fcf[] = { 0x1fbf, 0x0342, 0 };
static const unichar_t str_1fd0[] = { 0x03b9, 0x0306, 0 };
static const unichar_t str_1fd1[] = { 0x03b9, 0x0304, 0 };
static const unichar_t str_1fd2[] = { 0x03ca, 0x0300, 0 };
static const unichar_t str_1fd3[] = { 0x0390, 0 };
static const unichar_t str_1fd6[] = { 0x03b9, 0x0342, 0 };
static const unichar_t str_1fd7[] = { 0x03ca, 0x0342, 0 };
static const unichar_t str_1fd8[] = { 0x0399, 0x0306, 0 };
static const unichar_t str_1fd9[] = { 0x0399, 0x0304, 0 };
static const unichar_t str_1fda[] = { 0x0399, 0x0300, 0 };
static const unichar_t str_1fdb[] = { 0x038a, 0 };
static const unichar_t str_1fdd[] = { 0x1ffe, 0x0300, 0 };
static const unichar_t str_1fde[] = { 0x1ffe, 0x0301, 0 };
static const unichar_t str_1fdf[] = { 0x1ffe, 0x0342, 0 };
static const unichar_t str_1fe0[] = { 0x03c5, 0x0306, 0 };
static const unichar_t str_1fe1[] = { 0x03c5, 0x0304, 0 };
static const unichar_t str_1fe2[] = { 0x03cb, 0x0300, 0 };
static const unichar_t str_1fe3[] = { 0x03b0, 0 };
static const unichar_t str_1fe4[] = { 0x03c1, 0x0313, 0 };
static const unichar_t str_1fe5[] = { 0x03c1, 0x0314, 0 };
static const unichar_t str_1fe6[] = { 0x03c5, 0x0342, 0 };
static const unichar_t str_1fe7[] = { 0x03cb, 0x0342, 0 };
static const unichar_t str_1fe8[] = { 0x03a5, 0x0306, 0 };
static const unichar_t str_1fe9[] = { 0x03a5, 0x0304, 0 };
static const unichar_t str_1fea[] = { 0x03a5, 0x0300, 0 };
static const unichar_t str_1feb[] = { 0x038e, 0 };
static const unichar_t str_1fec[] = { 0x03a1, 0x0314, 0 };
static const unichar_t str_1fed[] = { 0x00a8, 0x0300, 0 };
static const unichar_t str_1fee[] = { 0x0385, 0 };
static const unichar_t str_1fef[] = { 0x0060, 0 };
static const unichar_t str_1ff2[] = { 0x1f7c, 0x0345, 0 };
static const unichar_t str_1ff3[] = { 0x03c9, 0x0345, 0 };
static const unichar_t str_1ff4[] = { 0x03ce, 0x0345, 0 };
static const unichar_t str_1ff6[] = { 0x03c9, 0x0342, 0 };
static const unichar_t str_1ff7[] = { 0x1ff6, 0x0345, 0 };
static const unichar_t str_1ff8[] = { 0x039f, 0x0300, 0 };
static const unichar_t str_1ff9[] = { 0x038c, 0 };
static const unichar_t str_1ffa[] = { 0x03a9, 0x0300, 0 };
static const unichar_t str_1ffb[] = { 0x038f, 0 };
static const unichar_t str_1ffc[] = { 0x03a9, 0x0345, 0 };
static const unichar_t str_1ffd[] = { 0x00b4, 0 };
static const unichar_t str_1ffe[] = { 0x0020, 0x0314, 0 };
static const unichar_t str_2000[] = { 0x2002, 0 };
static const unichar_t str_2001[] = { 0x2003, 0 };
static const unichar_t str_2002[] = { 0x0020, 0 };
static const unichar_t str_2003[] = { 0x0020, 0 };
static const unichar_t str_2004[] = { 0x0020, 0 };
static const unichar_t str_2005[] = { 0x0020, 0 };
static const unichar_t str_2006[] = { 0x0020, 0 };
static const unichar_t str_2007[] = { 0x0020, 0 };
static const unichar_t str_2008[] = { 0x0020, 0 };
static const unichar_t str_2009[] = { 0x0020, 0 };
static const unichar_t str_200a[] = { 0x0020, 0 };
static const unichar_t str_2010[] = { 0x002d, 0 };
static const unichar_t str_2011[] = { 0x2010, 0 };
static const unichar_t str_2012[] = { 0x002d, 0 };
static const unichar_t str_2013[] = { 0x002d, 0 };
static const unichar_t str_2014[] = { 0x002d, 0 };
static const unichar_t str_2015[] = { 0x002d, 0 };
static const unichar_t str_2016[] = { 0x007c, 0x007c, 0 };
static const unichar_t str_2017[] = { 0x0020, 0x0333, 0 };
static const unichar_t str_2018[] = { 0x0060, 0 };
static const unichar_t str_2019[] = { 0x0027, 0 };
static const unichar_t str_201c[] = { 0x0022, 0 };
static const unichar_t str_201d[] = { 0x0022, 0 };
static const unichar_t str_2024[] = { 0x002e, 0 };
static const unichar_t str_2025[] = { 0x002e, 0x002e, 0 };
static const unichar_t str_2026[] = { 0x002e, 0x002e, 0x002e, 0 };
static const unichar_t str_202f[] = { 0x0020, 0 };
static const unichar_t str_2032[] = { 0x0027, 0 };
static const unichar_t str_2033[] = { 0x2032, 0x2032, 0 };
static const unichar_t str_2034[] = { 0x2032, 0x2032, 0x2032, 0 };
static const unichar_t str_2035[] = { 0x0060, 0 };
static const unichar_t str_2036[] = { 0x2035, 0x2035, 0 };
static const unichar_t str_2037[] = { 0x2035, 0x2035, 0x2035, 0 };
static const unichar_t str_2039[] = { 0x003c, 0 };
static const unichar_t str_203a[] = { 0x003e, 0 };
static const unichar_t str_203c[] = { 0x0021, 0x0021, 0 };
static const unichar_t str_203e[] = { 0x0020, 0x0305, 0 };
static const unichar_t str_2047[] = { 0x003f, 0x003f, 0 };
static const unichar_t str_2048[] = { 0x003f, 0x0021, 0 };
static const unichar_t str_2049[] = { 0x0021, 0x003f, 0 };
static const unichar_t str_2057[] = { 0x2032, 0x2032, 0x2032, 0x2032, 0 };
static const unichar_t str_205f[] = { 0x0020, 0 };
static const unichar_t str_2070[] = { 0x0030, 0 };
static const unichar_t str_2071[] = { 0x0069, 0 };
static const unichar_t str_2074[] = { 0x0034, 0 };
static const unichar_t str_2075[] = { 0x0035, 0 };
static const unichar_t str_2076[] = { 0x0036, 0 };
static const unichar_t str_2077[] = { 0x0037, 0 };
static const unichar_t str_2078[] = { 0x0038, 0 };
static const unichar_t str_2079[] = { 0x0039, 0 };
static const unichar_t str_207a[] = { 0x002b, 0 };
static const unichar_t str_207b[] = { 0x2212, 0 };
static const unichar_t str_207c[] = { 0x003d, 0 };
static const unichar_t str_207d[] = { 0x0028, 0 };
static const unichar_t str_207e[] = { 0x0029, 0 };
static const unichar_t str_207f[] = { 0x006e, 0 };
static const unichar_t str_2080[] = { 0x0030, 0 };
static const unichar_t str_2081[] = { 0x0031, 0 };
static const unichar_t str_2082[] = { 0x0032, 0 };
static const unichar_t str_2083[] = { 0x0033, 0 };
static const unichar_t str_2084[] = { 0x0034, 0 };
static const unichar_t str_2085[] = { 0x0035, 0 };
static const unichar_t str_2086[] = { 0x0036, 0 };
static const unichar_t str_2087[] = { 0x0037, 0 };
static const unichar_t str_2088[] = { 0x0038, 0 };
static const unichar_t str_2089[] = { 0x0039, 0 };
static const unichar_t str_208a[] = { 0x002b, 0 };
static const unichar_t str_208b[] = { 0x2212, 0 };
static const unichar_t str_208c[] = { 0x003d, 0 };
static const unichar_t str_208d[] = { 0x0028, 0 };
static const unichar_t str_208e[] = { 0x0029, 0 };
static const unichar_t str_2090[] = { 0x0061, 0 };
static const unichar_t str_2091[] = { 0x0065, 0 };
static const unichar_t str_2092[] = { 0x006f, 0 };
static const unichar_t str_2093[] = { 0x0078, 0 };
static const unichar_t str_2094[] = { 0x0259, 0 };
static const unichar_t str_2095[] = { 0x0068, 0 };
static const unichar_t str_2096[] = { 0x006b, 0 };
static const unichar_t str_2097[] = { 0x006c, 0 };
static const unichar_t str_2098[] = { 0x006d, 0 };
static const unichar_t str_2099[] = { 0x006e, 0 };
static const unichar_t str_209a[] = { 0x0070, 0 };
static const unichar_t str_209b[] = { 0x0073, 0 };
static const unichar_t str_209c[] = { 0x0074, 0 };
static const unichar_t str_20a8[] = { 0x0052, 0x0073, 0 };
static const unichar_t str_2100[] = { 0x0061, 0x002f, 0x0063, 0 };
static const unichar_t str_2101[] = { 0x0061, 0x002f, 0x0073, 0 };
static const unichar_t str_2102[] = { 0x0043, 0 };
static const unichar_t str_2103[] = { 0x00b0, 0x0043, 0 };
static const unichar_t str_2105[] = { 0x0063, 0x002f, 0x006f, 0 };
static const unichar_t str_2106[] = { 0x0063, 0x002f, 0x0075, 0 };
static const unichar_t str_2107[] = { 0x0190, 0 };
static const unichar_t str_2109[] = { 0x00b0, 0x0046, 0 };
static const unichar_t str_210a[] = { 0x0067, 0 };
static const unichar_t str_210b[] = { 0x0048, 0 };
static const unichar_t str_210c[] = { 0x0048, 0 };
static const unichar_t str_210d[] = { 0x0048, 0 };
static const unichar_t str_210e[] = { 0x0068, 0 };
static const unichar_t str_210f[] = { 0x0127, 0 };
static const unichar_t str_2110[] = { 0x0049, 0 };
static const unichar_t str_2111[] = { 0x0049, 0 };
static const unichar_t str_2112[] = { 0x004c, 0 };
static const unichar_t str_2113[] = { 0x006c, 0 };
static const unichar_t str_2115[] = { 0x004e, 0 };
static const unichar_t str_2116[] = { 0x004e, 0x006f, 0 };
static const unichar_t str_2119[] = { 0x0050, 0 };
static const unichar_t str_211a[] = { 0x0051, 0 };
static const unichar_t str_211b[] = { 0x0052, 0 };
static const unichar_t str_211c[] = { 0x0052, 0 };
static const unichar_t str_211d[] = { 0x0052, 0 };
static const unichar_t str_2120[] = { 0x0053, 0x004d, 0 };
static const unichar_t str_2121[] = { 0x0054, 0x0045, 0x004c, 0 };
static const unichar_t str_2122[] = { 0x0054, 0x004d, 0 };
static const unichar_t str_2124[] = { 0x005a, 0 };
static const unichar_t str_2126[] = { 0x03a9, 0 };
static const unichar_t str_2128[] = { 0x005a, 0 };
static const unichar_t str_212a[] = { 0x004b, 0 };
static const unichar_t str_212b[] = { 0x00c5, 0 };
static const unichar_t str_212c[] = { 0x0042, 0 };
static const unichar_t str_212d[] = { 0x0043, 0 };
static const unichar_t str_212f[] = { 0x0065, 0 };
static const unichar_t str_2130[] = { 0x0045, 0 };
static const unichar_t str_2131[] = { 0x0046, 0 };
static const unichar_t str_2133[] = { 0x004d, 0 };
static const unichar_t str_2134[] = { 0x006f, 0 };
static const unichar_t str_2135[] = { 0x05d0, 0 };
static const unichar_t str_2136[] = { 0x05d1, 0 };
static const unichar_t str_2137[] = { 0x05d2, 0 };
static const unichar_t str_2138[] = { 0x05d3, 0 };
static const unichar_t str_2139[] = { 0x0069, 0 };
static const unichar_t str_213b[] = { 0x0046, 0x0041, 0x0058, 0 };
static const unichar_t str_213c[] = { 0x03c0, 0 };
static const unichar_t str_213d[] = { 0x03b3, 0 };
static const unichar_t str_213e[] = { 0x0393, 0 };
static const unichar_t str_213f[] = { 0x03a0, 0 };
static const unichar_t str_2140[] = { 0x2211, 0 };
static const unichar_t str_2145[] = { 0x0044, 0 };
static const unichar_t str_2146[] = { 0x0064, 0 };
static const unichar_t str_2147[] = { 0x0065, 0 };
static const unichar_t str_2148[] = { 0x0069, 0 };
static const unichar_t str_2149[] = { 0x006a, 0 };
static const unichar_t str_2150[] = { 0x0031, 0x2044, 0x0037, 0 };
static const unichar_t str_2151[] = { 0x0031, 0x2044, 0x0039, 0 };
static const unichar_t str_2152[] = { 0x0031, 0x2044, 0x0031, 0x0030, 0 };
static const unichar_t str_2153[] = { 0x0031, 0x2044, 0x0033, 0 };
static const unichar_t str_2154[] = { 0x0032, 0x2044, 0x0033, 0 };
static const unichar_t str_2155[] = { 0x0031, 0x2044, 0x0035, 0 };
static const unichar_t str_2156[] = { 0x0032, 0x2044, 0x0035, 0 };
static const unichar_t str_2157[] = { 0x0033, 0x2044, 0x0035, 0 };
static const unichar_t str_2158[] = { 0x0034, 0x2044, 0x0035, 0 };
static const unichar_t str_2159[] = { 0x0031, 0x2044, 0x0036, 0 };
static const unichar_t str_215a[] = { 0x0035, 0x2044, 0x0036, 0 };
static const unichar_t str_215b[] = { 0x0031, 0x2044, 0x0038, 0 };
static const unichar_t str_215c[] = { 0x0033, 0x2044, 0x0038, 0 };
static const unichar_t str_215d[] = { 0x0035, 0x2044, 0x0038, 0 };
static const unichar_t str_215e[] = { 0x0037, 0x2044, 0x0038, 0 };
static const unichar_t str_215f[] = { 0x0031, 0x2044, 0 };
static const unichar_t str_2160[] = { 0x0049, 0 };
static const unichar_t str_2161[] = { 0x0049, 0x0049, 0 };
static const unichar_t str_2162[] = { 0x0049, 0x0049, 0x0049, 0 };
static const unichar_t str_2163[] = { 0x0049, 0x0056, 0 };
static const unichar_t str_2164[] = { 0x0056, 0 };
static const unichar_t str_2165[] = { 0x0056, 0x0049, 0 };
static const unichar_t str_2166[] = { 0x0056, 0x0049, 0x0049, 0 };
static const unichar_t str_2167[] = { 0x0056, 0x0049, 0x0049, 0x0049, 0 };
static const unichar_t str_2168[] = { 0x0049, 0x0058, 0 };
static const unichar_t str_2169[] = { 0x0058, 0 };
static const unichar_t str_216a[] = { 0x0058, 0x0049, 0 };
static const unichar_t str_216b[] = { 0x0058, 0x0049, 0x0049, 0 };
static const unichar_t str_216c[] = { 0x004c, 0 };
static const unichar_t str_216d[] = { 0x0043, 0 };
static const unichar_t str_216e[] = { 0x0044, 0 };
static const unichar_t str_216f[] = { 0x004d, 0 };
static const unichar_t str_2170[] = { 0x0069, 0 };
static const unichar_t str_2171[] = { 0x0069, 0x0069, 0 };
static const unichar_t str_2172[] = { 0x0069, 0x0069, 0x0069, 0 };
static const unichar_t str_2173[] = { 0x0069, 0x0076, 0 };
static const unichar_t str_2174[] = { 0x0076, 0 };
static const unichar_t str_2175[] = { 0x0076, 0x0069, 0 };
static const unichar_t str_2176[] = { 0x0076, 0x0069, 0x0069, 0 };
static const unichar_t str_2177[] = { 0x0076, 0x0069, 0x0069, 0x0069, 0 };
static const unichar_t str_2178[] = { 0x0069, 0x0078, 0 };
static const unichar_t str_2179[] = { 0x0078, 0 };
static const unichar_t str_217a[] = { 0x0078, 0x0069, 0 };
static const unichar_t str_217b[] = { 0x0078, 0x0069, 0x0069, 0 };
static const unichar_t str_217c[] = { 0x006c, 0 };
static const unichar_t str_217d[] = { 0x0063, 0 };
static const unichar_t str_217e[] = { 0x0064, 0 };
static const unichar_t str_217f[] = { 0x006d, 0 };
static const unichar_t str_2189[] = { 0x0030, 0x2044, 0x0033, 0 };
static const unichar_t str_219a[] = { 0x2190, 0x0338, 0 };
static const unichar_t str_219b[] = { 0x2192, 0x0338, 0 };
static const unichar_t str_21ae[] = { 0x2194, 0x0338, 0 };
static const unichar_t str_21cd[] = { 0x21d0, 0x0338, 0 };
static const unichar_t str_21ce[] = { 0x21d4, 0x0338, 0 };
static const unichar_t str_21cf[] = { 0x21d2, 0x0338, 0 };
static const unichar_t str_2204[] = { 0x2203, 0x0338, 0 };
static const unichar_t str_2205[] = { 0x00d8, 0 };
static const unichar_t str_2206[] = { 0x0394, 0 };
static const unichar_t str_2209[] = { 0x2208, 0x0338, 0 };
static const unichar_t str_220c[] = { 0x220b, 0x0338, 0 };
static const unichar_t str_220f[] = { 0x03a0, 0 };
static const unichar_t str_2211[] = { 0x03a3, 0 };
static const unichar_t str_2212[] = { 0x002d, 0 };
static const unichar_t str_2215[] = { 0x002f, 0 };
static const unichar_t str_2216[] = { 0x005c, 0 };
static const unichar_t str_2217[] = { 0x002a, 0 };
static const unichar_t str_2218[] = { 0x00b0, 0 };
static const unichar_t str_2219[] = { 0x00b7, 0 };
static const unichar_t str_2223[] = { 0x007c, 0 };
static const unichar_t str_2224[] = { 0x2223, 0x0338, 0 };
static const unichar_t str_2225[] = { 0x007c, 0x007c, 0 };
static const unichar_t str_2226[] = { 0x2225, 0x0338, 0 };
static const unichar_t str_222c[] = { 0x222b, 0x222b, 0 };
static const unichar_t str_222d[] = { 0x222b, 0x222b, 0x222b, 0 };
static const unichar_t str_222f[] = { 0x222e, 0x222e, 0 };
static const unichar_t str_2230[] = { 0x222e, 0x222e, 0x222e, 0 };
static const unichar_t str_2236[] = { 0x003a, 0 };
static const unichar_t str_223c[] = { 0x007e, 0 };
static const unichar_t str_2241[] = { 0x223c, 0x0338, 0 };
static const unichar_t str_2244[] = { 0x2243, 0x0338, 0 };
static const unichar_t str_2247[] = { 0x2245, 0x0338, 0 };
static const unichar_t str_2249[] = { 0x2248, 0x0338, 0 };
static const unichar_t str_2260[] = { 0x003d, 0x0338, 0 };
static const unichar_t str_2262[] = { 0x2261, 0x0338, 0 };
static const unichar_t str_226a[] = { 0x00ab, 0 };
static const unichar_t str_226b[] = { 0x00bb, 0 };
static const unichar_t str_226d[] = { 0x224d, 0x0338, 0 };
static const unichar_t str_226e[] = { 0x003c, 0x0338, 0 };
static const unichar_t str_226f[] = { 0x003e, 0x0338, 0 };
static const unichar_t str_2270[] = { 0x2264, 0x0338, 0 };
static const unichar_t str_2271[] = { 0x2265, 0x0338, 0 };
static const unichar_t str_2274[] = { 0x2272, 0x0338, 0 };
static const unichar_t str_2275[] = { 0x2273, 0x0338, 0 };
static const unichar_t str_2278[] = { 0x2276, 0x0338, 0 };
static const unichar_t str_2279[] = { 0x2277, 0x0338, 0 };
static const unichar_t str_2280[] = { 0x227a, 0x0338, 0 };
static const unichar_t str_2281[] = { 0x227b, 0x0338, 0 };
static const unichar_t str_2284[] = { 0x2282, 0x0338, 0 };
static const unichar_t str_2285[] = { 0x2283, 0x0338, 0 };
static const unichar_t str_2288[] = { 0x2286, 0x0338, 0 };
static const unichar_t str_2289[] = { 0x2287, 0x0338, 0 };
static const unichar_t str_2299[] = { 0x0298, 0 };
static const unichar_t str_22ac[] = { 0x22a2, 0x0338, 0 };
static const unichar_t str_22ad[] = { 0x22a8, 0x0338, 0 };
static const unichar_t str_22ae[] = { 0x22a9, 0x0338, 0 };
static const unichar_t str_22af[] = { 0x22ab, 0x0338, 0 };
static const unichar_t str_22c4[] = { 0x25ca, 0 };
static const unichar_t str_22c5[] = { 0x00b7, 0 };
static const unichar_t str_22e0[] = { 0x227c, 0x0338, 0 };
static const unichar_t str_22e1[] = { 0x227d, 0x0338, 0 };
static const unichar_t str_22e2[] = { 0x2291, 0x0338, 0 };
static const unichar_t str_22e3[] = { 0x2292, 0x0338, 0 };
static const unichar_t str_22ea[] = { 0x22b2, 0x0338, 0 };
static const unichar_t str_22eb[] = { 0x22b3, 0x0338, 0 };
static const unichar_t str_22ec[] = { 0x22b4, 0x0338, 0 };
static const unichar_t str_22ed[] = { 0x22b5, 0x0338, 0 };
static const unichar_t str_22ef[] = { 0x00b7, 0x00b7, 0x00b7, 0 };
static const unichar_t str_2303[] = { 0x005e, 0 };
static const unichar_t str_2329[] = { 0x3008, 0 };
static const unichar_t str_232a[] = { 0x3009, 0 };
static const unichar_t str_2373[] = { 0x03b9, 0 };
static const unichar_t str_2374[] = { 0x03c1, 0 };
static const unichar_t str_2375[] = { 0x03c9, 0 };
static const unichar_t str_237a[] = { 0x03b1, 0 };
static const unichar_t str_2400[] = { 0x004e, 0x0055, 0x004c, 0 };
static const unichar_t str_2401[] = { 0x0053, 0x004f, 0x0048, 0 };
static const unichar_t str_2402[] = { 0x0053, 0x0054, 0x0058, 0 };
static const unichar_t str_2403[] = { 0x0045, 0x0054, 0x0058, 0 };
static const unichar_t str_2404[] = { 0x0045, 0x004f, 0x0054, 0 };
static const unichar_t str_2405[] = { 0x0045, 0x004e, 0x0041, 0 };
static const unichar_t str_2406[] = { 0x0041, 0x0043, 0x004b, 0 };
static const unichar_t str_2407[] = { 0x0042, 0x0045, 0x004c, 0 };
static const unichar_t str_2408[] = { 0x0042, 0x0053, 0 };
static const unichar_t str_2409[] = { 0x0048, 0x0054, 0 };
static const unichar_t str_240a[] = { 0x004c, 0x0046, 0 };
static const unichar_t str_240b[] = { 0x0056, 0x0054, 0 };
static const unichar_t str_240c[] = { 0x0046, 0x0046, 0 };
static const unichar_t str_240d[] = { 0x0043, 0x0052, 0 };
static const unichar_t str_240e[] = { 0x0053, 0x004f, 0 };
static const unichar_t str_240f[] = { 0x0053, 0x0049, 0 };
static const unichar_t str_2410[] = { 0x0044, 0x004c, 0x0045, 0 };
static const unichar_t str_2411[] = { 0x0044, 0x0043, 0x0031, 0 };
static const unichar_t str_2412[] = { 0x0044, 0x0043, 0x0032, 0 };
static const unichar_t str_2413[] = { 0x0044, 0x0043, 0x0033, 0 };
static const unichar_t str_2414[] = { 0x0044, 0x0043, 0x0034, 0 };
static const unichar_t str_2415[] = { 0x004e, 0x0041, 0x004b, 0 };
static const unichar_t str_2416[] = { 0x0053, 0x0059, 0x004e, 0 };
static const unichar_t str_2417[] = { 0x0045, 0x0054, 0x0042, 0 };
static const unichar_t str_2418[] = { 0x0043, 0x0041, 0x004e, 0 };
static const unichar_t str_2419[] = { 0x0045, 0x004d, 0 };
static const unichar_t str_241a[] = { 0x0053, 0x0055, 0x0042, 0 };
static const unichar_t str_241b[] = { 0x0045, 0x0053, 0x0043, 0 };
static const unichar_t str_241c[] = { 0x0046, 0x0053, 0 };
static const unichar_t str_241d[] = { 0x0047, 0x0053, 0 };
static const unichar_t str_241e[] = { 0x0052, 0x0053, 0 };
static const unichar_t str_241f[] = { 0x0055, 0x0053, 0 };
static const unichar_t str_2420[] = { 0x0053, 0x0050, 0 };
static const unichar_t str_2421[] = { 0x0044, 0x0045, 0x004c, 0 };
static const unichar_t str_2422[] = { 0x0180, 0 };
static const unichar_t str_2460[] = { 0x0031, 0x20dd, 0 };
static const unichar_t str_2461[] = { 0x0032, 0x20dd, 0 };
static const unichar_t str_2462[] = { 0x0033, 0x20dd, 0 };
static const unichar_t str_2463[] = { 0x0034, 0x20dd, 0 };
static const unichar_t str_2464[] = { 0x0035, 0x20dd, 0 };
static const unichar_t str_2465[] = { 0x0036, 0x20dd, 0 };
static const unichar_t str_2466[] = { 0x0037, 0x20dd, 0 };
static const unichar_t str_2467[] = { 0x0038, 0x20dd, 0 };
static const unichar_t str_2468[] = { 0x0039, 0x20dd, 0 };
static const unichar_t str_2469[] = { 0x0031, 0x0030, 0x20dd, 0 };
static const unichar_t str_246a[] = { 0x0031, 0x0031, 0x20dd, 0 };
static const unichar_t str_246b[] = { 0x0031, 0x0032, 0x20dd, 0 };
static const unichar_t str_246c[] = { 0x0031, 0x0033, 0x20dd, 0 };
static const unichar_t str_246d[] = { 0x0031, 0x0034, 0x20dd, 0 };
static const unichar_t str_246e[] = { 0x0031, 0x0035, 0x20dd, 0 };
static const unichar_t str_246f[] = { 0x0031, 0x0036, 0x20dd, 0 };
static const unichar_t str_2470[] = { 0x0031, 0x0037, 0x20dd, 0 };
static const unichar_t str_2471[] = { 0x0031, 0x0038, 0x20dd, 0 };
static const unichar_t str_2472[] = { 0x0031, 0x0039, 0x20dd, 0 };
static const unichar_t str_2473[] = { 0x0032, 0x0030, 0x20dd, 0 };
static const unichar_t str_2474[] = { 0x0028, 0x0031, 0x0029, 0 };
static const unichar_t str_2475[] = { 0x0028, 0x0032, 0x0029, 0 };
static const unichar_t str_2476[] = { 0x0028, 0x0033, 0x0029, 0 };
static const unichar_t str_2477[] = { 0x0028, 0x0034, 0x0029, 0 };
static const unichar_t str_2478[] = { 0x0028, 0x0035, 0x0029, 0 };
static const unichar_t str_2479[] = { 0x0028, 0x0036, 0x0029, 0 };
static const unichar_t str_247a[] = { 0x0028, 0x0037, 0x0029, 0 };
static const unichar_t str_247b[] = { 0x0028, 0x0038, 0x0029, 0 };
static const unichar_t str_247c[] = { 0x0028, 0x0039, 0x0029, 0 };
static const unichar_t str_247d[] = { 0x0028, 0x0031, 0x0030, 0x0029, 0 };
static const unichar_t str_247e[] = { 0x0028, 0x0031, 0x0031, 0x0029, 0 };
static const unichar_t str_247f[] = { 0x0028, 0x0031, 0x0032, 0x0029, 0 };
static const unichar_t str_2480[] = { 0x0028, 0x0031, 0x0033, 0x0029, 0 };
static const unichar_t str_2481[] = { 0x0028, 0x0031, 0x0034, 0x0029, 0 };
static const unichar_t str_2482[] = { 0x0028, 0x0031, 0x0035, 0x0029, 0 };
static const unichar_t str_2483[] = { 0x0028, 0x0031, 0x0036, 0x0029, 0 };
static const unichar_t str_2484[] = { 0x0028, 0x0031, 0x0037, 0x0029, 0 };
static const unichar_t str_2485[] = { 0x0028, 0x0031, 0x0038, 0x0029, 0 };
static const unichar_t str_2486[] = { 0x0028, 0x0031, 0x0039, 0x0029, 0 };
static const unichar_t str_2487[] = { 0x0028, 0x0032, 0x0030, 0x0029, 0 };
static const unichar_t str_2488[] = { 0x0031, 0x002e, 0 };
static const unichar_t str_2489[] = { 0x0032, 0x002e, 0 };
static const unichar_t str_248a[] = { 0x0033, 0x002e, 0 };
static const unichar_t str_248b[] = { 0x0034, 0x002e, 0 };
static const unichar_t str_248c[] = { 0x0035, 0x002e, 0 };
static const unichar_t str_248d[] = { 0x0036, 0x002e, 0 };
static const unichar_t str_248e[] = { 0x0037, 0x002e, 0 };
static const unichar_t str_248f[] = { 0x0038, 0x002e, 0 };
static const unichar_t str_2490[] = { 0x0039, 0x002e, 0 };
static const unichar_t str_2491[] = { 0x0031, 0x0030, 0x002e, 0 };
static const unichar_t str_2492[] = { 0x0031, 0x0031, 0x002e, 0 };
static const unichar_t str_2493[] = { 0x0031, 0x0032, 0x002e, 0 };
static const unichar_t str_2494[] = { 0x0031, 0x0033, 0x002e, 0 };
static const unichar_t str_2495[] = { 0x0031, 0x0034, 0x002e, 0 };
static const unichar_t str_2496[] = { 0x0031, 0x0035, 0x002e, 0 };
static const unichar_t str_2497[] = { 0x0031, 0x0036, 0x002e, 0 };
static const unichar_t str_2498[] = { 0x0031, 0x0037, 0x002e, 0 };
static const unichar_t str_2499[] = { 0x0031, 0x0038, 0x002e, 0 };
static const unichar_t str_249a[] = { 0x0031, 0x0039, 0x002e, 0 };
static const unichar_t str_249b[] = { 0x0032, 0x0030, 0x002e, 0 };
static const unichar_t str_249c[] = { 0x0028, 0x0061, 0x0029, 0 };
static const unichar_t str_249d[] = { 0x0028, 0x0062, 0x0029, 0 };
static const unichar_t str_249e[] = { 0x0028, 0x0063, 0x0029, 0 };
static const unichar_t str_249f[] = { 0x0028, 0x0064, 0x0029, 0 };
static const unichar_t str_24a0[] = { 0x0028, 0x0065, 0x0029, 0 };
static const unichar_t str_24a1[] = { 0x0028, 0x0066, 0x0029, 0 };
static const unichar_t str_24a2[] = { 0x0028, 0x0067, 0x0029, 0 };
static const unichar_t str_24a3[] = { 0x0028, 0x0068, 0x0029, 0 };
static const unichar_t str_24a4[] = { 0x0028, 0x0069, 0x0029, 0 };
static const unichar_t str_24a5[] = { 0x0028, 0x006a, 0x0029, 0 };
static const unichar_t str_24a6[] = { 0x0028, 0x006b, 0x0029, 0 };
static const unichar_t str_24a7[] = { 0x0028, 0x006c, 0x0029, 0 };
static const unichar_t str_24a8[] = { 0x0028, 0x006d, 0x0029, 0 };
static const unichar_t str_24a9[] = { 0x0028, 0x006e, 0x0029, 0 };
static const unichar_t str_24aa[] = { 0x0028, 0x006f, 0x0029, 0 };
static const unichar_t str_24ab[] = { 0x0028, 0x0070, 0x0029, 0 };
static const unichar_t str_24ac[] = { 0x0028, 0x0071, 0x0029, 0 };
static const unichar_t str_24ad[] = { 0x0028, 0x0072, 0x0029, 0 };
static const unichar_t str_24ae[] = { 0x0028, 0x0073, 0x0029, 0 };
static const unichar_t str_24af[] = { 0x0028, 0x0074, 0x0029, 0 };
static const unichar_t str_24b0[] = { 0x0028, 0x0075, 0x0029, 0 };
static const unichar_t str_24b1[] = { 0x0028, 0x0076, 0x0029, 0 };
static const unichar_t str_24b2[] = { 0x0028, 0x0077, 0x0029, 0 };
static const unichar_t str_24b3[] = { 0x0028, 0x0078, 0x0029, 0 };
static const unichar_t str_24b4[] = { 0x0028, 0x0079, 0x0029, 0 };
static const unichar_t str_24b5[] = { 0x0028, 0x007a, 0x0029, 0 };
static const unichar_t str_24b6[] = { 0x0041, 0x20dd, 0 };
static const unichar_t str_24b7[] = { 0x0042, 0x20dd, 0 };
static const unichar_t str_24b8[] = { 0x0043, 0x20dd, 0 };
static const unichar_t str_24b9[] = { 0x0044, 0x20dd, 0 };
static const unichar_t str_24ba[] = { 0x0045, 0x20dd, 0 };
static const unichar_t str_24bb[] = { 0x0046, 0x20dd, 0 };
static const unichar_t str_24bc[] = { 0x0047, 0x20dd, 0 };
static const unichar_t str_24bd[] = { 0x0048, 0x20dd, 0 };
static const unichar_t str_24be[] = { 0x0049, 0x20dd, 0 };
static const unichar_t str_24bf[] = { 0x004a, 0x20dd, 0 };
static const unichar_t str_24c0[] = { 0x004b, 0x20dd, 0 };
static const unichar_t str_24c1[] = { 0x004c, 0x20dd, 0 };
static const unichar_t str_24c2[] = { 0x004d, 0x20dd, 0 };
static const unichar_t str_24c3[] = { 0x004e, 0x20dd, 0 };
static const unichar_t str_24c4[] = { 0x004f, 0x20dd, 0 };
static const unichar_t str_24c5[] = { 0x0050, 0x20dd, 0 };
static const unichar_t str_24c6[] = { 0x0051, 0x20dd, 0 };
static const unichar_t str_24c7[] = { 0x0052, 0x20dd, 0 };
static const unichar_t str_24c8[] = { 0x0053, 0x20dd, 0 };
static const unichar_t str_24c9[] = { 0x0054, 0x20dd, 0 };
static const unichar_t str_24ca[] = { 0x0055, 0x20dd, 0 };
static const unichar_t str_24cb[] = { 0x0056, 0x20dd, 0 };
static const unichar_t str_24cc[] = { 0x0057, 0x20dd, 0 };
static const unichar_t str_24cd[] = { 0x0058, 0x20dd, 0 };
static const unichar_t str_24ce[] = { 0x0059, 0x20dd, 0 };
static const unichar_t str_24cf[] = { 0x005a, 0x20dd, 0 };
static const unichar_t str_24d0[] = { 0x0061, 0x20dd, 0 };
static const unichar_t str_24d1[] = { 0x0062, 0x20dd, 0 };
static const unichar_t str_24d2[] = { 0x0063, 0x20dd, 0 };
static const unichar_t str_24d3[] = { 0x0064, 0x20dd, 0 };
static const unichar_t str_24d4[] = { 0x0065, 0x20dd, 0 };
static const unichar_t str_24d5[] = { 0x0066, 0x20dd, 0 };
static const unichar_t str_24d6[] = { 0x0067, 0x20dd, 0 };
static const unichar_t str_24d7[] = { 0x0068, 0x20dd, 0 };
static const unichar_t str_24d8[] = { 0x0069, 0x20dd, 0 };
static const unichar_t str_24d9[] = { 0x006a, 0x20dd, 0 };
static const unichar_t str_24da[] = { 0x006b, 0x20dd, 0 };
static const unichar_t str_24db[] = { 0x006c, 0x20dd, 0 };
static const unichar_t str_24dc[] = { 0x006d, 0x20dd, 0 };
static const unichar_t str_24dd[] = { 0x006e, 0x20dd, 0 };
static const unichar_t str_24de[] = { 0x006f, 0x20dd, 0 };
static const unichar_t str_24df[] = { 0x0070, 0x20dd, 0 };
static const unichar_t str_24e0[] = { 0x0071, 0x20dd, 0 };
static const unichar_t str_24e1[] = { 0x0072, 0x20dd, 0 };
static const unichar_t str_24e2[] = { 0x0073, 0x20dd, 0 };
static const unichar_t str_24e3[] = { 0x0074, 0x20dd, 0 };
static const unichar_t str_24e4[] = { 0x0075, 0x20dd, 0 };
static const unichar_t str_24e5[] = { 0x0076, 0x20dd, 0 };
static const unichar_t str_24e6[] = { 0x0077, 0x20dd, 0 };
static const unichar_t str_24e7[] = { 0x0078, 0x20dd, 0 };
static const unichar_t str_24e8[] = { 0x0079, 0x20dd, 0 };
static const unichar_t str_24e9[] = { 0x007a, 0x20dd, 0 };
static const unichar_t str_24ea[] = { 0x0030, 0x20dd, 0 };
static const unichar_t str_2500[] = { 0x2014, 0 };
static const unichar_t str_2502[] = { 0x007c, 0 };
static const unichar_t str_25b3[] = { 0x2206, 0 };
static const unichar_t str_25b8[] = { 0x2023, 0 };
static const unichar_t str_25bd[] = { 0x2207, 0 };
static const unichar_t str_25c7[] = { 0x25ca, 0 };
static const unichar_t str_25e6[] = { 0x00b0, 0 };
static const unichar_t str_2662[] = { 0x25ca, 0 };
static const unichar_t str_2731[] = { 0x002a, 0 };
static const unichar_t str_2758[] = { 0x007c, 0 };
static const unichar_t str_2762[] = { 0x0021, 0 };
static const unichar_t str_2a0c[] = { 0x222b, 0x222b, 0x222b, 0x222b, 0 };
static const unichar_t str_2a74[] = { 0x003a, 0x003a, 0x003d, 0 };
static const unichar_t str_2a75[] = { 0x003d, 0x003d, 0 };
static const unichar_t str_2a76[] = { 0x003d, 0x003d, 0x003d, 0 };
static const unichar_t str_2adc[] = { 0x2add, 0x0338, 0 };
static const unichar_t str_2c7c[] = { 0x006a, 0 };
static const unichar_t str_2c7d[] = { 0x0056, 0 };
static const unichar_t str_2d6f[] = { 0x2d61, 0 };
static const unichar_t str_2e28[] = { 0xff5f, 0 };
static const unichar_t str_2e29[] = { 0xff60, 0 };
static const unichar_t str_2e9f[] = { 0x6bcd, 0 };
static const unichar_t str_2ef3[] = { 0x9f9f, 0 };
static const unichar_t str_2f00[] = { 0x4e00, 0 };
static const unichar_t str_2f01[] = { 0x4e28, 0 };
static const unichar_t str_2f02[] = { 0x4e36, 0 };
static const unichar_t str_2f03[] = { 0x4e3f, 0 };
static const unichar_t str_2f04[] = { 0x4e59, 0 };
static const unichar_t str_2f05[] = { 0x4e85, 0 };
static const unichar_t str_2f06[] = { 0x4e8c, 0 };
static const unichar_t str_2f07[] = { 0x4ea0, 0 };
static const unichar_t str_2f08[] = { 0x4eba, 0 };
static const unichar_t str_2f09[] = { 0x513f, 0 };
static const unichar_t str_2f0a[] = { 0x5165, 0 };
static const unichar_t str_2f0b[] = { 0x516b, 0 };
static const unichar_t str_2f0c[] = { 0x5182, 0 };
static const unichar_t str_2f0d[] = { 0x5196, 0 };
static const unichar_t str_2f0e[] = { 0x51ab, 0 };
static const unichar_t str_2f0f[] = { 0x51e0, 0 };
static const unichar_t str_2f10[] = { 0x51f5, 0 };
static const unichar_t str_2f11[] = { 0x5200, 0 };
static const unichar_t str_2f12[] = { 0x529b, 0 };
static const unichar_t str_2f13[] = { 0x52f9, 0 };
static const unichar_t str_2f14[] = { 0x5315, 0 };
static const unichar_t str_2f15[] = { 0x531a, 0 };
static const unichar_t str_2f16[] = { 0x5338, 0 };
static const unichar_t str_2f17[] = { 0x5341, 0 };
static const unichar_t str_2f18[] = { 0x535c, 0 };
static const unichar_t str_2f19[] = { 0x5369, 0 };
static const unichar_t str_2f1a[] = { 0x5382, 0 };
static const unichar_t str_2f1b[] = { 0x53b6, 0 };
static const unichar_t str_2f1c[] = { 0x53c8, 0 };
static const unichar_t str_2f1d[] = { 0x53e3, 0 };
static const unichar_t str_2f1e[] = { 0x56d7, 0 };
static const unichar_t str_2f1f[] = { 0x571f, 0 };
static const unichar_t str_2f20[] = { 0x58eb, 0 };
static const unichar_t str_2f21[] = { 0x5902, 0 };
static const unichar_t str_2f22[] = { 0x590a, 0 };
static const unichar_t str_2f23[] = { 0x5915, 0 };
static const unichar_t str_2f24[] = { 0x5927, 0 };
static const unichar_t str_2f25[] = { 0x5973, 0 };
static const unichar_t str_2f26[] = { 0x5b50, 0 };
static const unichar_t str_2f27[] = { 0x5b80, 0 };
static const unichar_t str_2f28[] = { 0x5bf8, 0 };
static const unichar_t str_2f29[] = { 0x5c0f, 0 };
static const unichar_t str_2f2a[] = { 0x5c22, 0 };
static const unichar_t str_2f2b[] = { 0x5c38, 0 };
static const unichar_t str_2f2c[] = { 0x5c6e, 0 };
static const unichar_t str_2f2d[] = { 0x5c71, 0 };
static const unichar_t str_2f2e[] = { 0x5ddb, 0 };
static const unichar_t str_2f2f[] = { 0x5de5, 0 };
static const unichar_t str_2f30[] = { 0x5df1, 0 };
static const unichar_t str_2f31[] = { 0x5dfe, 0 };
static const unichar_t str_2f32[] = { 0x5e72, 0 };
static const unichar_t str_2f33[] = { 0x5e7a, 0 };
static const unichar_t str_2f34[] = { 0x5e7f, 0 };
static const unichar_t str_2f35[] = { 0x5ef4, 0 };
static const unichar_t str_2f36[] = { 0x5efe, 0 };
static const unichar_t str_2f37[] = { 0x5f0b, 0 };
static const unichar_t str_2f38[] = { 0x5f13, 0 };
static const unichar_t str_2f39[] = { 0x5f50, 0 };
static const unichar_t str_2f3a[] = { 0x5f61, 0 };
static const unichar_t str_2f3b[] = { 0x5f73, 0 };
static const unichar_t str_2f3c[] = { 0x5fc3, 0 };
static const unichar_t str_2f3d[] = { 0x6208, 0 };
static const unichar_t str_2f3e[] = { 0x6236, 0 };
static const unichar_t str_2f3f[] = { 0x624b, 0 };
static const unichar_t str_2f40[] = { 0x652f, 0 };
static const unichar_t str_2f41[] = { 0x6534, 0 };
static const unichar_t str_2f42[] = { 0x6587, 0 };
static const unichar_t str_2f43[] = { 0x6597, 0 };
static const unichar_t str_2f44[] = { 0x65a4, 0 };
static const unichar_t str_2f45[] = { 0x65b9, 0 };
static const unichar_t str_2f46[] = { 0x65e0, 0 };
static const unichar_t str_2f47[] = { 0x65e5, 0 };
static const unichar_t str_2f48[] = { 0x66f0, 0 };
static const unichar_t str_2f49[] = { 0x6708, 0 };
static const unichar_t str_2f4a[] = { 0x6728, 0 };
static const unichar_t str_2f4b[] = { 0x6b20, 0 };
static const unichar_t str_2f4c[] = { 0x6b62, 0 };
static const unichar_t str_2f4d[] = { 0x6b79, 0 };
static const unichar_t str_2f4e[] = { 0x6bb3, 0 };
static const unichar_t str_2f4f[] = { 0x6bcb, 0 };
static const unichar_t str_2f50[] = { 0x6bd4, 0 };
static const unichar_t str_2f51[] = { 0x6bdb, 0 };
static const unichar_t str_2f52[] = { 0x6c0f, 0 };
static const unichar_t str_2f53[] = { 0x6c14, 0 };
static const unichar_t str_2f54[] = { 0x6c34, 0 };
static const unichar_t str_2f55[] = { 0x706b, 0 };
static const unichar_t str_2f56[] = { 0x722a, 0 };
static const unichar_t str_2f57[] = { 0x7236, 0 };
static const unichar_t str_2f58[] = { 0x723b, 0 };
static const unichar_t str_2f59[] = { 0x723f, 0 };
static const unichar_t str_2f5a[] = { 0x7247, 0 };
static const unichar_t str_2f5b[] = { 0x7259, 0 };
static const unichar_t str_2f5c[] = { 0x725b, 0 };
static const unichar_t str_2f5d[] = { 0x72ac, 0 };
static const unichar_t str_2f5e[] = { 0x7384, 0 };
static const unichar_t str_2f5f[] = { 0x7389, 0 };
static const unichar_t str_2f60[] = { 0x74dc, 0 };
static const unichar_t str_2f61[] = { 0x74e6, 0 };
static const unichar_t str_2f62[] = { 0x7518, 0 };
static const unichar_t str_2f63[] = { 0x751f, 0 };
static const unichar_t str_2f64[] = { 0x7528, 0 };
static const unichar_t str_2f65[] = { 0x7530, 0 };
static const unichar_t str_2f66[] = { 0x758b, 0 };
static const unichar_t str_2f67[] = { 0x7592, 0 };
static const unichar_t str_2f68[] = { 0x7676, 0 };
static const unichar_t str_2f69[] = { 0x767d, 0 };
static const unichar_t str_2f6a[] = { 0x76ae, 0 };
static const unichar_t str_2f6b[] = { 0x76bf, 0 };
static const unichar_t str_2f6c[] = { 0x76ee, 0 };
static const unichar_t str_2f6d[] = { 0x77db, 0 };
static const unichar_t str_2f6e[] = { 0x77e2, 0 };
static const unichar_t str_2f6f[] = { 0x77f3, 0 };
static const unichar_t str_2f70[] = { 0x793a, 0 };
static const unichar_t str_2f71[] = { 0x79b8, 0 };
static const unichar_t str_2f72[] = { 0x79be, 0 };
static const unichar_t str_2f73[] = { 0x7a74, 0 };
static const unichar_t str_2f74[] = { 0x7acb, 0 };
static const unichar_t str_2f75[] = { 0x7af9, 0 };
static const unichar_t str_2f76[] = { 0x7c73, 0 };
static const unichar_t str_2f77[] = { 0x7cf8, 0 };
static const unichar_t str_2f78[] = { 0x7f36, 0 };
static const unichar_t str_2f79[] = { 0x7f51, 0 };
static const unichar_t str_2f7a[] = { 0x7f8a, 0 };
static const unichar_t str_2f7b[] = { 0x7fbd, 0 };
static const unichar_t str_2f7c[] = { 0x8001, 0 };
static const unichar_t str_2f7d[] = { 0x800c, 0 };
static const unichar_t str_2f7e[] = { 0x8012, 0 };
static const unichar_t str_2f7f[] = { 0x8033, 0 };
static const unichar_t str_2f80[] = { 0x807f, 0 };
static const unichar_t str_2f81[] = { 0x8089, 0 };
static const unichar_t str_2f82[] = { 0x81e3, 0 };
static const unichar_t str_2f83[] = { 0x81ea, 0 };
static const unichar_t str_2f84[] = { 0x81f3, 0 };
static const unichar_t str_2f85[] = { 0x81fc, 0 };
static const unichar_t str_2f86[] = { 0x820c, 0 };
static const unichar_t str_2f87[] = { 0x821b, 0 };
static const unichar_t str_2f88[] = { 0x821f, 0 };
static const unichar_t str_2f89[] = { 0x826e, 0 };
static const unichar_t str_2f8a[] = { 0x8272, 0 };
static const unichar_t str_2f8b[] = { 0x8278, 0 };
static const unichar_t str_2f8c[] = { 0x864d, 0 };
static const unichar_t str_2f8d[] = { 0x866b, 0 };
static const unichar_t str_2f8e[] = { 0x8840, 0 };
static const unichar_t str_2f8f[] = { 0x884c, 0 };
static const unichar_t str_2f90[] = { 0x8863, 0 };
static const unichar_t str_2f91[] = { 0x897e, 0 };
static const unichar_t str_2f92[] = { 0x898b, 0 };
static const unichar_t str_2f93[] = { 0x89d2, 0 };
static const unichar_t str_2f94[] = { 0x8a00, 0 };
static const unichar_t str_2f95[] = { 0x8c37, 0 };
static const unichar_t str_2f96[] = { 0x8c46, 0 };
static const unichar_t str_2f97[] = { 0x8c55, 0 };
static const unichar_t str_2f98[] = { 0x8c78, 0 };
static const unichar_t str_2f99[] = { 0x8c9d, 0 };
static const unichar_t str_2f9a[] = { 0x8d64, 0 };
static const unichar_t str_2f9b[] = { 0x8d70, 0 };
static const unichar_t str_2f9c[] = { 0x8db3, 0 };
static const unichar_t str_2f9d[] = { 0x8eab, 0 };
static const unichar_t str_2f9e[] = { 0x8eca, 0 };
static const unichar_t str_2f9f[] = { 0x8f9b, 0 };
static const unichar_t str_2fa0[] = { 0x8fb0, 0 };
static const unichar_t str_2fa1[] = { 0x8fb5, 0 };
static const unichar_t str_2fa2[] = { 0x9091, 0 };
static const unichar_t str_2fa3[] = { 0x9149, 0 };
static const unichar_t str_2fa4[] = { 0x91c6, 0 };
static const unichar_t str_2fa5[] = { 0x91cc, 0 };
static const unichar_t str_2fa6[] = { 0x91d1, 0 };
static const unichar_t str_2fa7[] = { 0x9577, 0 };
static const unichar_t str_2fa8[] = { 0x9580, 0 };
static const unichar_t str_2fa9[] = { 0x961c, 0 };
static const unichar_t str_2faa[] = { 0x96b6, 0 };
static const unichar_t str_2fab[] = { 0x96b9, 0 };
static const unichar_t str_2fac[] = { 0x96e8, 0 };
static const unichar_t str_2fad[] = { 0x9751, 0 };
static const unichar_t str_2fae[] = { 0x975e, 0 };
static const unichar_t str_2faf[] = { 0x9762, 0 };
static const unichar_t str_2fb0[] = { 0x9769, 0 };
static const unichar_t str_2fb1[] = { 0x97cb, 0 };
static const unichar_t str_2fb2[] = { 0x97ed, 0 };
static const unichar_t str_2fb3[] = { 0x97f3, 0 };
static const unichar_t str_2fb4[] = { 0x9801, 0 };
static const unichar_t str_2fb5[] = { 0x98a8, 0 };
static const unichar_t str_2fb6[] = { 0x98db, 0 };
static const unichar_t str_2fb7[] = { 0x98df, 0 };
static const unichar_t str_2fb8[] = { 0x9996, 0 };
static const unichar_t str_2fb9[] = { 0x9999, 0 };
static const unichar_t str_2fba[] = { 0x99ac, 0 };
static const unichar_t str_2fbb[] = { 0x9aa8, 0 };
static const unichar_t str_2fbc[] = { 0x9ad8, 0 };
static const unichar_t str_2fbd[] = { 0x9adf, 0 };
static const unichar_t str_2fbe[] = { 0x9b25, 0 };
static const unichar_t str_2fbf[] = { 0x9b2f, 0 };
static const unichar_t str_2fc0[] = { 0x9b32, 0 };
static const unichar_t str_2fc1[] = { 0x9b3c, 0 };
static const unichar_t str_2fc2[] = { 0x9b5a, 0 };
static const unichar_t str_2fc3[] = { 0x9ce5, 0 };
static const unichar_t str_2fc4[] = { 0x9e75, 0 };
static const unichar_t str_2fc5[] = { 0x9e7f, 0 };
static const unichar_t str_2fc6[] = { 0x9ea5, 0 };
static const unichar_t str_2fc7[] = { 0x9ebb, 0 };
static const unichar_t str_2fc8[] = { 0x9ec3, 0 };
static const unichar_t str_2fc9[] = { 0x9ecd, 0 };
static const unichar_t str_2fca[] = { 0x9ed1, 0 };
static const unichar_t str_2fcb[] = { 0x9ef9, 0 };
static const unichar_t str_2fcc[] = { 0x9efd, 0 };
static const unichar_t str_2fcd[] = { 0x9f0e, 0 };
static const unichar_t str_2fce[] = { 0x9f13, 0 };
static const unichar_t str_2fcf[] = { 0x9f20, 0 };
static const unichar_t str_2fd0[] = { 0x9f3b, 0 };
static const unichar_t str_2fd1[] = { 0x9f4a, 0 };
static const unichar_t str_2fd2[] = { 0x9f52, 0 };
static const unichar_t str_2fd3[] = { 0x9f8d, 0 };
static const unichar_t str_2fd4[] = { 0x9f9c, 0 };
static const unichar_t str_2fd5[] = { 0x9fa0, 0 };
static const unichar_t str_3000[] = { 0x0020, 0 };
static const unichar_t str_3001[] = { 0x002c, 0 };
static const unichar_t str_3008[] = { 0x003c, 0 };
static const unichar_t str_3009[] = { 0x003e, 0 };
static const unichar_t str_300a[] = { 0x00ab, 0 };
static const unichar_t str_300b[] = { 0x00bb, 0 };
static const unichar_t str_3036[] = { 0x3012, 0 };
static const unichar_t str_3038[] = { 0x5341, 0 };
static const unichar_t str_3039[] = { 0x5344, 0 };
static const unichar_t str_303a[] = { 0x5345, 0 };
static const unichar_t str_304c[] = { 0x304b, 0x3099, 0 };
static const unichar_t str_304e[] = { 0x304d, 0x3099, 0 };
static const unichar_t str_3050[] = { 0x304f, 0x3099, 0 };
static const unichar_t str_3052[] = { 0x3051, 0x3099, 0 };
static const unichar_t str_3054[] = { 0x3053, 0x3099, 0 };
static const unichar_t str_3056[] = { 0x3055, 0x3099, 0 };
static const unichar_t str_3058[] = { 0x3057, 0x3099, 0 };
static const unichar_t str_305a[] = { 0x3059, 0x3099, 0 };
static const unichar_t str_305c[] = { 0x305b, 0x3099, 0 };
static const unichar_t str_305e[] = { 0x305d, 0x3099, 0 };
static const unichar_t str_3060[] = { 0x305f, 0x3099, 0 };
static const unichar_t str_3062[] = { 0x3061, 0x3099, 0 };
static const unichar_t str_3065[] = { 0x3064, 0x3099, 0 };
static const unichar_t str_3067[] = { 0x3066, 0x3099, 0 };
static const unichar_t str_3069[] = { 0x3068, 0x3099, 0 };
static const unichar_t str_3070[] = { 0x306f, 0x3099, 0 };
static const unichar_t str_3071[] = { 0x306f, 0x309a, 0 };
static const unichar_t str_3073[] = { 0x3072, 0x3099, 0 };
static const unichar_t str_3074[] = { 0x3072, 0x309a, 0 };
static const unichar_t str_3076[] = { 0x3075, 0x3099, 0 };
static const unichar_t str_3077[] = { 0x3075, 0x309a, 0 };
static const unichar_t str_3079[] = { 0x3078, 0x3099, 0 };
static const unichar_t str_307a[] = { 0x3078, 0x309a, 0 };
static const unichar_t str_307c[] = { 0x307b, 0x3099, 0 };
static const unichar_t str_307d[] = { 0x307b, 0x309a, 0 };
static const unichar_t str_3094[] = { 0x3046, 0x3099, 0 };
static const unichar_t str_309b[] = { 0x0020, 0x3099, 0 };
static const unichar_t str_309c[] = { 0x0020, 0x309a, 0 };
static const unichar_t str_309e[] = { 0x309d, 0x3099, 0 };
static const unichar_t str_309f[] = { 0x3088, 0x308a, 0 };
static const unichar_t str_30ac[] = { 0x30ab, 0x3099, 0 };
static const unichar_t str_30ae[] = { 0x30ad, 0x3099, 0 };
static const unichar_t str_30b0[] = { 0x30af, 0x3099, 0 };
static const unichar_t str_30b2[] = { 0x30b1, 0x3099, 0 };
static const unichar_t str_30b4[] = { 0x30b3, 0x3099, 0 };
static const unichar_t str_30b6[] = { 0x30b5, 0x3099, 0 };
static const unichar_t str_30b8[] = { 0x30b7, 0x3099, 0 };
static const unichar_t str_30ba[] = { 0x30b9, 0x3099, 0 };
static const unichar_t str_30bc[] = { 0x30bb, 0x3099, 0 };
static const unichar_t str_30be[] = { 0x30bd, 0x3099, 0 };
static const unichar_t str_30c0[] = { 0x30bf, 0x3099, 0 };
static const unichar_t str_30c2[] = { 0x30c1, 0x3099, 0 };
static const unichar_t str_30c5[] = { 0x30c4, 0x3099, 0 };
static const unichar_t str_30c7[] = { 0x30c6, 0x3099, 0 };
static const unichar_t str_30c9[] = { 0x30c8, 0x3099, 0 };
static const unichar_t str_30d0[] = { 0x30cf, 0x3099, 0 };
static const unichar_t str_30d1[] = { 0x30cf, 0x309a, 0 };
static const unichar_t str_30d3[] = { 0x30d2, 0x3099, 0 };
static const unichar_t str_30d4[] = { 0x30d2, 0x309a, 0 };
static const unichar_t str_30d6[] = { 0x30d5, 0x3099, 0 };
static const unichar_t str_30d7[] = { 0x30d5, 0x309a, 0 };
static const unichar_t str_30d9[] = { 0x30d8, 0x3099, 0 };
static const unichar_t str_30da[] = { 0x30d8, 0x309a, 0 };
static const unichar_t str_30dc[] = { 0x30db, 0x3099, 0 };
static const unichar_t str_30dd[] = { 0x30db, 0x309a, 0 };
static const unichar_t str_30f4[] = { 0x30a6, 0x3099, 0 };
static const unichar_t str_30f7[] = { 0x30ef, 0x3099, 0 };
static const unichar_t str_30f8[] = { 0x30f0, 0x3099, 0 };
static const unichar_t str_30f9[] = { 0x30f1, 0x3099, 0 };
static const unichar_t str_30fa[] = { 0x30f2, 0x3099, 0 };
static const unichar_t str_30fe[] = { 0x30fd, 0x3099, 0 };
static const unichar_t str_30ff[] = { 0x30b3, 0x30c8, 0 };
static const unichar_t str_3131[] = { 0x1100, 0 };
static const unichar_t str_3132[] = { 0x1101, 0 };
static const unichar_t str_3133[] = { 0x11aa, 0 };
static const unichar_t str_3134[] = { 0x1102, 0 };
static const unichar_t str_3135[] = { 0x11ac, 0 };
static const unichar_t str_3136[] = { 0x11ad, 0 };
static const unichar_t str_3137[] = { 0x1103, 0 };
static const unichar_t str_3138[] = { 0x1104, 0 };
static const unichar_t str_3139[] = { 0x1105, 0 };
static const unichar_t str_313a[] = { 0x11b0, 0 };
static const unichar_t str_313b[] = { 0x11b1, 0 };
static const unichar_t str_313c[] = { 0x11b2, 0 };
static const unichar_t str_313d[] = { 0x11b3, 0 };
static const unichar_t str_313e[] = { 0x11b4, 0 };
static const unichar_t str_313f[] = { 0x11b5, 0 };
static const unichar_t str_3140[] = { 0x111a, 0 };
static const unichar_t str_3141[] = { 0x1106, 0 };
static const unichar_t str_3142[] = { 0x1107, 0 };
static const unichar_t str_3143[] = { 0x1108, 0 };
static const unichar_t str_3144[] = { 0x1121, 0 };
static const unichar_t str_3145[] = { 0x1109, 0 };
static const unichar_t str_3146[] = { 0x110a, 0 };
static const unichar_t str_3147[] = { 0x110b, 0 };
static const unichar_t str_3148[] = { 0x110c, 0 };
static const unichar_t str_3149[] = { 0x110d, 0 };
static const unichar_t str_314a[] = { 0x110e, 0 };
static const unichar_t str_314b[] = { 0x110f, 0 };
static const unichar_t str_314c[] = { 0x1110, 0 };
static const unichar_t str_314d[] = { 0x1111, 0 };
static const unichar_t str_314e[] = { 0x1112, 0 };
static const unichar_t str_314f[] = { 0x1161, 0 };
static const unichar_t str_3150[] = { 0x1162, 0 };
static const unichar_t str_3151[] = { 0x1163, 0 };
static const unichar_t str_3152[] = { 0x1164, 0 };
static const unichar_t str_3153[] = { 0x1165, 0 };
static const unichar_t str_3154[] = { 0x1166, 0 };
static const unichar_t str_3155[] = { 0x1167, 0 };
static const unichar_t str_3156[] = { 0x1168, 0 };
static const unichar_t str_3157[] = { 0x1169, 0 };
static const unichar_t str_3158[] = { 0x116a, 0 };
static const unichar_t str_3159[] = { 0x116b, 0 };
static const unichar_t str_315a[] = { 0x116c, 0 };
static const unichar_t str_315b[] = { 0x116d, 0 };
static const unichar_t str_315c[] = { 0x116e, 0 };
static const unichar_t str_315d[] = { 0x116f, 0 };
static const unichar_t str_315e[] = { 0x1170, 0 };
static const unichar_t str_315f[] = { 0x1171, 0 };
static const unichar_t str_3160[] = { 0x1172, 0 };
static const unichar_t str_3161[] = { 0x1173, 0 };
static const unichar_t str_3162[] = { 0x1174, 0 };
static const unichar_t str_3163[] = { 0x1175, 0 };
static const unichar_t str_3164[] = { 0x1160, 0 };
static const unichar_t str_3165[] = { 0x1114, 0 };
static const unichar_t str_3166[] = { 0x1115, 0 };
static const unichar_t str_3167[] = { 0x11c7, 0 };
static const unichar_t str_3168[] = { 0x11c8, 0 };
static const unichar_t str_3169[] = { 0x11cc, 0 };
static const unichar_t str_316a[] = { 0x11ce, 0 };
static const unichar_t str_316b[] = { 0x11d3, 0 };
static const unichar_t str_316c[] = { 0x11d7, 0 };
static const unichar_t str_316d[] = { 0x11d9, 0 };
static const unichar_t str_316e[] = { 0x111c, 0 };
static const unichar_t str_316f[] = { 0x11dd, 0 };
static const unichar_t str_3170[] = { 0x11df, 0 };
static const unichar_t str_3171[] = { 0x111d, 0 };
static const unichar_t str_3172[] = { 0x111e, 0 };
static const unichar_t str_3173[] = { 0x1120, 0 };
static const unichar_t str_3174[] = { 0x1122, 0 };
static const unichar_t str_3175[] = { 0x1123, 0 };
static const unichar_t str_3176[] = { 0x1127, 0 };
static const unichar_t str_3177[] = { 0x1129, 0 };
static const unichar_t str_3178[] = { 0x112b, 0 };
static const unichar_t str_3179[] = { 0x112c, 0 };
static const unichar_t str_317a[] = { 0x112d, 0 };
static const unichar_t str_317b[] = { 0x112e, 0 };
static const unichar_t str_317c[] = { 0x112f, 0 };
static const unichar_t str_317d[] = { 0x1132, 0 };
static const unichar_t str_317e[] = { 0x1136, 0 };
static const unichar_t str_317f[] = { 0x1140, 0 };
static const unichar_t str_3180[] = { 0x1147, 0 };
static const unichar_t str_3181[] = { 0x114c, 0 };
static const unichar_t str_3182[] = { 0x11f1, 0 };
static const unichar_t str_3183[] = { 0x11f2, 0 };
static const unichar_t str_3184[] = { 0x1157, 0 };
static const unichar_t str_3185[] = { 0x1158, 0 };
static const unichar_t str_3186[] = { 0x1159, 0 };
static const unichar_t str_3187[] = { 0x1184, 0 };
static const unichar_t str_3188[] = { 0x1185, 0 };
static const unichar_t str_3189[] = { 0x1188, 0 };
static const unichar_t str_318a[] = { 0x1191, 0 };
static const unichar_t str_318b[] = { 0x1192, 0 };
static const unichar_t str_318c[] = { 0x1194, 0 };
static const unichar_t str_318d[] = { 0x119e, 0 };
static const unichar_t str_318e[] = { 0x11a1, 0 };
static const unichar_t str_3192[] = { 0x4e00, 0 };
static const unichar_t str_3193[] = { 0x4e8c, 0 };
static const unichar_t str_3194[] = { 0x4e09, 0 };
static const unichar_t str_3195[] = { 0x56db, 0 };
static const unichar_t str_3196[] = { 0x4e0a, 0 };
static const unichar_t str_3197[] = { 0x4e2d, 0 };
static const unichar_t str_3198[] = { 0x4e0b, 0 };
static const unichar_t str_3199[] = { 0x7532, 0 };
static const unichar_t str_319a[] = { 0x4e59, 0 };
static const unichar_t str_319b[] = { 0x4e19, 0 };
static const unichar_t str_319c[] = { 0x4e01, 0 };
static const unichar_t str_319d[] = { 0x5929, 0 };
static const unichar_t str_319e[] = { 0x5730, 0 };
static const unichar_t str_319f[] = { 0x4eba, 0 };
static const unichar_t str_3200[] = { 0x0028, 0x1100, 0x0029, 0 };
static const unichar_t str_3201[] = { 0x0028, 0x1102, 0x0029, 0 };
static const unichar_t str_3202[] = { 0x0028, 0x1103, 0x0029, 0 };
static const unichar_t str_3203[] = { 0x0028, 0x1105, 0x0029, 0 };
static const unichar_t str_3204[] = { 0x0028, 0x1106, 0x0029, 0 };
static const unichar_t str_3205[] = { 0x0028, 0x1107, 0x0029, 0 };
static const unichar_t str_3206[] = { 0x0028, 0x1109, 0x0029, 0 };
static const unichar_t str_3207[] = { 0x0028, 0x110b, 0x0029, 0 };
static const unichar_t str_3208[] = { 0x0028, 0x110c, 0x0029, 0 };
static const unichar_t str_3209[] = { 0x0028, 0x110e, 0x0029, 0 };
static const unichar_t str_320a[] = { 0x0028, 0x110f, 0x0029, 0 };
static const unichar_t str_320b[] = { 0x0028, 0x1110, 0x0029, 0 };
static const unichar_t str_320c[] = { 0x0028, 0x1111, 0x0029, 0 };
static const unichar_t str_320d[] = { 0x0028, 0x1112, 0x0029, 0 };
static const unichar_t str_320e[] = { 0x0028, 0x1100, 0x1161, 0x0029, 0 };
static const unichar_t str_320f[] = { 0x0028, 0x1102, 0x1161, 0x0029, 0 };
static const unichar_t str_3210[] = { 0x0028, 0x1103, 0x1161, 0x0029, 0 };
static const unichar_t str_3211[] = { 0x0028, 0x1105, 0x1161, 0x0029, 0 };
static const unichar_t str_3212[] = { 0x0028, 0x1106, 0x1161, 0x0029, 0 };
static const unichar_t str_3213[] = { 0x0028, 0x1107, 0x1161, 0x0029, 0 };
static const unichar_t str_3214[] = { 0x0028, 0x1109, 0x1161, 0x0029, 0 };
static const unichar_t str_3215[] = { 0x0028, 0x110b, 0x1161, 0x0029, 0 };
static const unichar_t str_3216[] = { 0x0028, 0x110c, 0x1161, 0x0029, 0 };
static const unichar_t str_3217[] = { 0x0028, 0x110e, 0x1161, 0x0029, 0 };
static const unichar_t str_3218[] = { 0x0028, 0x110f, 0x1161, 0x0029, 0 };
static const unichar_t str_3219[] = { 0x0028, 0x1110, 0x1161, 0x0029, 0 };
static const unichar_t str_321a[] = { 0x0028, 0x1111, 0x1161, 0x0029, 0 };
static const unichar_t str_321b[] = { 0x0028, 0x1112, 0x1161, 0x0029, 0 };
static const unichar_t str_321c[] = { 0x0028, 0x110c, 0x116e, 0x0029, 0 };
static const unichar_t str_321d[] = { 0x0028, 0x110b, 0x1169, 0x110c, 0x1165, 0x11ab, 0x0029, 0 };
static const unichar_t str_321e[] = { 0x0028, 0x110b, 0x1169, 0x1112, 0x116e, 0x0029, 0 };
static const unichar_t str_3220[] = { 0x0028, 0x4e00, 0x0029, 0 };
static const unichar_t str_3221[] = { 0x0028, 0x4e8c, 0x0029, 0 };
static const unichar_t str_3222[] = { 0x0028, 0x4e09, 0x0029, 0 };
static const unichar_t str_3223[] = { 0x0028, 0x56db, 0x0029, 0 };
static const unichar_t str_3224[] = { 0x0028, 0x4e94, 0x0029, 0 };
static const unichar_t str_3225[] = { 0x0028, 0x516d, 0x0029, 0 };
static const unichar_t str_3226[] = { 0x0028, 0x4e03, 0x0029, 0 };
static const unichar_t str_3227[] = { 0x0028, 0x516b, 0x0029, 0 };
static const unichar_t str_3228[] = { 0x0028, 0x4e5d, 0x0029, 0 };
static const unichar_t str_3229[] = { 0x0028, 0x5341, 0x0029, 0 };
static const unichar_t str_322a[] = { 0x0028, 0x6708, 0x0029, 0 };
static const unichar_t str_322b[] = { 0x0028, 0x706b, 0x0029, 0 };
static const unichar_t str_322c[] = { 0x0028, 0x6c34, 0x0029, 0 };
static const unichar_t str_322d[] = { 0x0028, 0x6728, 0x0029, 0 };
static const unichar_t str_322e[] = { 0x0028, 0x91d1, 0x0029, 0 };
static const unichar_t str_322f[] = { 0x0028, 0x571f, 0x0029, 0 };
static const unichar_t str_3230[] = { 0x0028, 0x65e5, 0x0029, 0 };
static const unichar_t str_3231[] = { 0x0028, 0x682a, 0x0029, 0 };
static const unichar_t str_3232[] = { 0x0028, 0x6709, 0x0029, 0 };
static const unichar_t str_3233[] = { 0x0028, 0x793e, 0x0029, 0 };
static const unichar_t str_3234[] = { 0x0028, 0x540d, 0x0029, 0 };
static const unichar_t str_3235[] = { 0x0028, 0x7279, 0x0029, 0 };
static const unichar_t str_3236[] = { 0x0028, 0x8ca1, 0x0029, 0 };
static const unichar_t str_3237[] = { 0x0028, 0x795d, 0x0029, 0 };
static const unichar_t str_3238[] = { 0x0028, 0x52b4, 0x0029, 0 };
static const unichar_t str_3239[] = { 0x0028, 0x4ee3, 0x0029, 0 };
static const unichar_t str_323a[] = { 0x0028, 0x547c, 0x0029, 0 };
static const unichar_t str_323b[] = { 0x0028, 0x5b66, 0x0029, 0 };
static const unichar_t str_323c[] = { 0x0028, 0x76e3, 0x0029, 0 };
static const unichar_t str_323d[] = { 0x0028, 0x4f01, 0x0029, 0 };
static const unichar_t str_323e[] = { 0x0028, 0x8cc7, 0x0029, 0 };
static const unichar_t str_323f[] = { 0x0028, 0x5354, 0x0029, 0 };
static const unichar_t str_3240[] = { 0x0028, 0x796d, 0x0029, 0 };
static const unichar_t str_3241[] = { 0x0028, 0x4f11, 0x0029, 0 };
static const unichar_t str_3242[] = { 0x0028, 0x81ea, 0x0029, 0 };
static const unichar_t str_3243[] = { 0x0028, 0x81f3, 0x0029, 0 };
static const unichar_t str_3244[] = { 0x554f, 0x20dd, 0 };
static const unichar_t str_3245[] = { 0x5e7c, 0x20dd, 0 };
static const unichar_t str_3246[] = { 0x6587, 0x20dd, 0 };
static const unichar_t str_3247[] = { 0x7b8f, 0x20dd, 0 };
static const unichar_t str_3250[] = { 0x0050, 0x0054, 0x0045, 0 };
static const unichar_t str_3251[] = { 0x0032, 0x0031, 0x20dd, 0 };
static const unichar_t str_3252[] = { 0x0032, 0x0032, 0x20dd, 0 };
static const unichar_t str_3253[] = { 0x0032, 0x0033, 0x20dd, 0 };
static const unichar_t str_3254[] = { 0x0032, 0x0034, 0x20dd, 0 };
static const unichar_t str_3255[] = { 0x0032, 0x0035, 0x20dd, 0 };
static const unichar_t str_3256[] = { 0x0032, 0x0036, 0x20dd, 0 };
static const unichar_t str_3257[] = { 0x0032, 0x0037, 0x20dd, 0 };
static const unichar_t str_3258[] = { 0x0032, 0x0038, 0x20dd, 0 };
static const unichar_t str_3259[] = { 0x0032, 0x0039, 0x20dd, 0 };
static const unichar_t str_325a[] = { 0x0033, 0x0030, 0x20dd, 0 };
static const unichar_t str_325b[] = { 0x0033, 0x0031, 0x20dd, 0 };
static const unichar_t str_325c[] = { 0x0033, 0x0032, 0x20dd, 0 };
static const unichar_t str_325d[] = { 0x0033, 0x0033, 0x20dd, 0 };
static const unichar_t str_325e[] = { 0x0033, 0x0034, 0x20dd, 0 };
static const unichar_t str_325f[] = { 0x0033, 0x0035, 0x20dd, 0 };
static const unichar_t str_3260[] = { 0x1100, 0x20dd, 0 };
static const unichar_t str_3261[] = { 0x1102, 0x20dd, 0 };
static const unichar_t str_3262[] = { 0x1103, 0x20dd, 0 };
static const unichar_t str_3263[] = { 0x1105, 0x20dd, 0 };
static const unichar_t str_3264[] = { 0x1106, 0x20dd, 0 };
static const unichar_t str_3265[] = { 0x1107, 0x20dd, 0 };
static const unichar_t str_3266[] = { 0x1109, 0x20dd, 0 };
static const unichar_t str_3267[] = { 0x110b, 0x20dd, 0 };
static const unichar_t str_3268[] = { 0x110c, 0x20dd, 0 };
static const unichar_t str_3269[] = { 0x110e, 0x20dd, 0 };
static const unichar_t str_326a[] = { 0x110f, 0x20dd, 0 };
static const unichar_t str_326b[] = { 0x1110, 0x20dd, 0 };
static const unichar_t str_326c[] = { 0x1111, 0x20dd, 0 };
static const unichar_t str_326d[] = { 0x1112, 0x20dd, 0 };
static const unichar_t str_326e[] = { 0x1100, 0x1161, 0x20dd, 0 };
static const unichar_t str_326f[] = { 0x1102, 0x1161, 0x20dd, 0 };
static const unichar_t str_3270[] = { 0x1103, 0x1161, 0x20dd, 0 };
static const unichar_t str_3271[] = { 0x1105, 0x1161, 0x20dd, 0 };
static const unichar_t str_3272[] = { 0x1106, 0x1161, 0x20dd, 0 };
static const unichar_t str_3273[] = { 0x1107, 0x1161, 0x20dd, 0 };
static const unichar_t str_3274[] = { 0x1109, 0x1161, 0x20dd, 0 };
static const unichar_t str_3275[] = { 0x110b, 0x1161, 0x20dd, 0 };
static const unichar_t str_3276[] = { 0x110c, 0x1161, 0x20dd, 0 };
static const unichar_t str_3277[] = { 0x110e, 0x1161, 0x20dd, 0 };
static const unichar_t str_3278[] = { 0x110f, 0x1161, 0x20dd, 0 };
static const unichar_t str_3279[] = { 0x1110, 0x1161, 0x20dd, 0 };
static const unichar_t str_327a[] = { 0x1111, 0x1161, 0x20dd, 0 };
static const unichar_t str_327b[] = { 0x1112, 0x1161, 0x20dd, 0 };
static const unichar_t str_327c[] = { 0x110e, 0x1161, 0x11b7, 0x1100, 0x1169, 0x20dd, 0 };
static const unichar_t str_327d[] = { 0x110c, 0x116e, 0x110b, 0x1174, 0x20dd, 0 };
static const unichar_t str_327e[] = { 0x110b, 0x116e, 0x20dd, 0 };
static const unichar_t str_3280[] = { 0x4e00, 0x20dd, 0 };
static const unichar_t str_3281[] = { 0x4e8c, 0x20dd, 0 };
static const unichar_t str_3282[] = { 0x4e09, 0x20dd, 0 };
static const unichar_t str_3283[] = { 0x56db, 0x20dd, 0 };
static const unichar_t str_3284[] = { 0x4e94, 0x20dd, 0 };
static const unichar_t str_3285[] = { 0x516d, 0x20dd, 0 };
static const unichar_t str_3286[] = { 0x4e03, 0x20dd, 0 };
static const unichar_t str_3287[] = { 0x516b, 0x20dd, 0 };
static const unichar_t str_3288[] = { 0x4e5d, 0x20dd, 0 };
static const unichar_t str_3289[] = { 0x5341, 0x20dd, 0 };
static const unichar_t str_328a[] = { 0x6708, 0x20dd, 0 };
static const unichar_t str_328b[] = { 0x706b, 0x20dd, 0 };
static const unichar_t str_328c[] = { 0x6c34, 0x20dd, 0 };
static const unichar_t str_328d[] = { 0x6728, 0x20dd, 0 };
static const unichar_t str_328e[] = { 0x91d1, 0x20dd, 0 };
static const unichar_t str_328f[] = { 0x571f, 0x20dd, 0 };
static const unichar_t str_3290[] = { 0x65e5, 0x20dd, 0 };
static const unichar_t str_3291[] = { 0x682a, 0x20dd, 0 };
static const unichar_t str_3292[] = { 0x6709, 0x20dd, 0 };
static const unichar_t str_3293[] = { 0x793e, 0x20dd, 0 };
static const unichar_t str_3294[] = { 0x540d, 0x20dd, 0 };
static const unichar_t str_3295[] = { 0x7279, 0x20dd, 0 };
static const unichar_t str_3296[] = { 0x8ca1, 0x20dd, 0 };
static const unichar_t str_3297[] = { 0x795d, 0x20dd, 0 };
static const unichar_t str_3298[] = { 0x52b4, 0x20dd, 0 };
static const unichar_t str_3299[] = { 0x79d8, 0x20dd, 0 };
static const unichar_t str_329a[] = { 0x7537, 0x20dd, 0 };
static const unichar_t str_329b[] = { 0x5973, 0x20dd, 0 };
static const unichar_t str_329c[] = { 0x9069, 0x20dd, 0 };
static const unichar_t str_329d[] = { 0x512a, 0x20dd, 0 };
static const unichar_t str_329e[] = { 0x5370, 0x20dd, 0 };
static const unichar_t str_329f[] = { 0x6ce8, 0x20dd, 0 };
static const unichar_t str_32a0[] = { 0x9805, 0x20dd, 0 };
static const unichar_t str_32a1[] = { 0x4f11, 0x20dd, 0 };
static const unichar_t str_32a2[] = { 0x5199, 0x20dd, 0 };
static const unichar_t str_32a3[] = { 0x6b63, 0x20dd, 0 };
static const unichar_t str_32a4[] = { 0x4e0a, 0x20dd, 0 };
static const unichar_t str_32a5[] = { 0x4e2d, 0x20dd, 0 };
static const unichar_t str_32a6[] = { 0x4e0b, 0x20dd, 0 };
static const unichar_t str_32a7[] = { 0x5de6, 0x20dd, 0 };
static const unichar_t str_32a8[] = { 0x53f3, 0x20dd, 0 };
static const unichar_t str_32a9[] = { 0x533b, 0x20dd, 0 };
static const unichar_t str_32aa[] = { 0x5b97, 0x20dd, 0 };
static const unichar_t str_32ab[] = { 0x5b66, 0x20dd, 0 };
static const unichar_t str_32ac[] = { 0x76e3, 0x20dd, 0 };
static const unichar_t str_32ad[] = { 0x4f01, 0x20dd, 0 };
static const unichar_t str_32ae[] = { 0x8cc7, 0x20dd, 0 };
static const unichar_t str_32af[] = { 0x5354, 0x20dd, 0 };
static const unichar_t str_32b0[] = { 0x591c, 0x20dd, 0 };
static const unichar_t str_32b1[] = { 0x0033, 0x0036, 0x20dd, 0 };
static const unichar_t str_32b2[] = { 0x0033, 0x0037, 0x20dd, 0 };
static const unichar_t str_32b3[] = { 0x0033, 0x0038, 0x20dd, 0 };
static const unichar_t str_32b4[] = { 0x0033, 0x0039, 0x20dd, 0 };
static const unichar_t str_32b5[] = { 0x0034, 0x0030, 0x20dd, 0 };
static const unichar_t str_32b6[] = { 0x0034, 0x0031, 0x20dd, 0 };
static const unichar_t str_32b7[] = { 0x0034, 0x0032, 0x20dd, 0 };
static const unichar_t str_32b8[] = { 0x0034, 0x0033, 0x20dd, 0 };
static const unichar_t str_32b9[] = { 0x0034, 0x0034, 0x20dd, 0 };
static const unichar_t str_32ba[] = { 0x0034, 0x0035, 0x20dd, 0 };
static const unichar_t str_32bb[] = { 0x0034, 0x0036, 0x20dd, 0 };
static const unichar_t str_32bc[] = { 0x0034, 0x0037, 0x20dd, 0 };
static const unichar_t str_32bd[] = { 0x0034, 0x0038, 0x20dd, 0 };
static const unichar_t str_32be[] = { 0x0034, 0x0039, 0x20dd, 0 };
static const unichar_t str_32bf[] = { 0x0035, 0x0030, 0x20dd, 0 };
static const unichar_t str_32c0[] = { 0x0031, 0x6708, 0 };
static const unichar_t str_32c1[] = { 0x0032, 0x6708, 0 };
static const unichar_t str_32c2[] = { 0x0033, 0x6708, 0 };
static const unichar_t str_32c3[] = { 0x0034, 0x6708, 0 };
static const unichar_t str_32c4[] = { 0x0035, 0x6708, 0 };
static const unichar_t str_32c5[] = { 0x0036, 0x6708, 0 };
static const unichar_t str_32c6[] = { 0x0037, 0x6708, 0 };
static const unichar_t str_32c7[] = { 0x0038, 0x6708, 0 };
static const unichar_t str_32c8[] = { 0x0039, 0x6708, 0 };
static const unichar_t str_32c9[] = { 0x0031, 0x0030, 0x6708, 0 };
static const unichar_t str_32ca[] = { 0x0031, 0x0031, 0x6708, 0 };
static const unichar_t str_32cb[] = { 0x0031, 0x0032, 0x6708, 0 };
static const unichar_t str_32cc[] = { 0x0048, 0x0067, 0 };
static const unichar_t str_32cd[] = { 0x0065, 0x0072, 0x0067, 0 };
static const unichar_t str_32ce[] = { 0x0065, 0x0056, 0 };
static const unichar_t str_32cf[] = { 0x004c, 0x0054, 0x0044, 0 };
static const unichar_t str_32d0[] = { 0x30a2, 0x20dd, 0 };
static const unichar_t str_32d1[] = { 0x30a4, 0x20dd, 0 };
static const unichar_t str_32d2[] = { 0x30a6, 0x20dd, 0 };
static const unichar_t str_32d3[] = { 0x30a8, 0x20dd, 0 };
static const unichar_t str_32d4[] = { 0x30aa, 0x20dd, 0 };
static const unichar_t str_32d5[] = { 0x30ab, 0x20dd, 0 };
static const unichar_t str_32d6[] = { 0x30ad, 0x20dd, 0 };
static const unichar_t str_32d7[] = { 0x30af, 0x20dd, 0 };
static const unichar_t str_32d8[] = { 0x30b1, 0x20dd, 0 };
static const unichar_t str_32d9[] = { 0x30b3, 0x20dd, 0 };
static const unichar_t str_32da[] = { 0x30b5, 0x20dd, 0 };
static const unichar_t str_32db[] = { 0x30b7, 0x20dd, 0 };
static const unichar_t str_32dc[] = { 0x30b9, 0x20dd, 0 };
static const unichar_t str_32dd[] = { 0x30bb, 0x20dd, 0 };
static const unichar_t str_32de[] = { 0x30bd, 0x20dd, 0 };
static const unichar_t str_32df[] = { 0x30bf, 0x20dd, 0 };
static const unichar_t str_32e0[] = { 0x30c1, 0x20dd, 0 };
static const unichar_t str_32e1[] = { 0x30c4, 0x20dd, 0 };
static const unichar_t str_32e2[] = { 0x30c6, 0x20dd, 0 };
static const unichar_t str_32e3[] = { 0x30c8, 0x20dd, 0 };
static const unichar_t str_32e4[] = { 0x30ca, 0x20dd, 0 };
static const unichar_t str_32e5[] = { 0x30cb, 0x20dd, 0 };
static const unichar_t str_32e6[] = { 0x30cc, 0x20dd, 0 };
static const unichar_t str_32e7[] = { 0x30cd, 0x20dd, 0 };
static const unichar_t str_32e8[] = { 0x30ce, 0x20dd, 0 };
static const unichar_t str_32e9[] = { 0x30cf, 0x20dd, 0 };
static const unichar_t str_32ea[] = { 0x30d2, 0x20dd, 0 };
static const unichar_t str_32eb[] = { 0x30d5, 0x20dd, 0 };
static const unichar_t str_32ec[] = { 0x30d8, 0x20dd, 0 };
static const unichar_t str_32ed[] = { 0x30db, 0x20dd, 0 };
static const unichar_t str_32ee[] = { 0x30de, 0x20dd, 0 };
static const unichar_t str_32ef[] = { 0x30df, 0x20dd, 0 };
static const unichar_t str_32f0[] = { 0x30e0, 0x20dd, 0 };
static const unichar_t str_32f1[] = { 0x30e1, 0x20dd, 0 };
static const unichar_t str_32f2[] = { 0x30e2, 0x20dd, 0 };
static const unichar_t str_32f3[] = { 0x30e4, 0x20dd, 0 };
static const unichar_t str_32f4[] = { 0x30e6, 0x20dd, 0 };
static const unichar_t str_32f5[] = { 0x30e8, 0x20dd, 0 };
static const unichar_t str_32f6[] = { 0x30e9, 0x20dd, 0 };
static const unichar_t str_32f7[] = { 0x30ea, 0x20dd, 0 };
static const unichar_t str_32f8[] = { 0x30eb, 0x20dd, 0 };
static const unichar_t str_32f9[] = { 0x30ec, 0x20dd, 0 };
static const unichar_t str_32fa[] = { 0x30ed, 0x20dd, 0 };
static const unichar_t str_32fb[] = { 0x30ef, 0x20dd, 0 };
static const unichar_t str_32fc[] = { 0x30f0, 0x20dd, 0 };
static const unichar_t str_32fd[] = { 0x30f1, 0x20dd, 0 };
static const unichar_t str_32fe[] = { 0x30f2, 0x20dd, 0 };
static const unichar_t str_3300[] = { 0x30a2, 0x30d1, 0x30fc, 0x30c8, 0 };
static const unichar_t str_3301[] = { 0x30a2, 0x30eb, 0x30d5, 0x30a1, 0 };
static const unichar_t str_3302[] = { 0x30a2, 0x30f3, 0x30da, 0x30a2, 0 };
static const unichar_t str_3303[] = { 0x30a2, 0x30fc, 0x30eb, 0 };
static const unichar_t str_3304[] = { 0x30a4, 0x30cb, 0x30f3, 0x30b0, 0 };
static const unichar_t str_3305[] = { 0x30a4, 0x30f3, 0x30c1, 0 };
static const unichar_t str_3306[] = { 0x30a6, 0x30a9, 0x30f3, 0 };
static const unichar_t str_3307[] = { 0x30a8, 0x30b9, 0x30af, 0x30fc, 0x30c9, 0 };
static const unichar_t str_3308[] = { 0x30a8, 0x30fc, 0x30ab, 0x30fc, 0 };
static const unichar_t str_3309[] = { 0x30aa, 0x30f3, 0x30b9, 0 };
static const unichar_t str_330a[] = { 0x30aa, 0x30fc, 0x30e0, 0 };
static const unichar_t str_330b[] = { 0x30ab, 0x30a4, 0x30ea, 0 };
static const unichar_t str_330c[] = { 0x30ab, 0x30e9, 0x30c3, 0x30c8, 0 };
static const unichar_t str_330d[] = { 0x30ab, 0x30ed, 0x30ea, 0x30fc, 0 };
static const unichar_t str_330e[] = { 0x30ac, 0x30ed, 0x30f3, 0 };
static const unichar_t str_330f[] = { 0x30ac, 0x30f3, 0x30de, 0 };
static const unichar_t str_3310[] = { 0x30ae, 0x30ac, 0 };
static const unichar_t str_3311[] = { 0x30ae, 0x30cb, 0x30fc, 0 };
static const unichar_t str_3312[] = { 0x30ad, 0x30e5, 0x30ea, 0x30fc, 0 };
static const unichar_t str_3313[] = { 0x30ae, 0x30eb, 0x30c0, 0x30fc, 0 };
static const unichar_t str_3314[] = { 0x30ad, 0x30ed, 0 };
static const unichar_t str_3315[] = { 0x30ad, 0x30ed, 0x30b0, 0x30e9, 0x30e0, 0 };
static const unichar_t str_3316[] = { 0x30ad, 0x30ed, 0x30e1, 0x30fc, 0x30c8, 0x30eb, 0 };
static const unichar_t str_3317[] = { 0x30ad, 0x30ed, 0x30ef, 0x30c3, 0x30c8, 0 };
static const unichar_t str_3318[] = { 0x30b0, 0x30e9, 0x30e0, 0 };
static const unichar_t str_3319[] = { 0x30b0, 0x30e9, 0x30e0, 0x30c8, 0x30f3, 0 };
static const unichar_t str_331a[] = { 0x30af, 0x30eb, 0x30bc, 0x30a4, 0x30ed, 0 };
static const unichar_t str_331b[] = { 0x30af, 0x30ed, 0x30fc, 0x30cd, 0 };
static const unichar_t str_331c[] = { 0x30b1, 0x30fc, 0x30b9, 0 };
static const unichar_t str_331d[] = { 0x30b3, 0x30eb, 0x30ca, 0 };
static const unichar_t str_331e[] = { 0x30b3, 0x30fc, 0x30dd, 0 };
static const unichar_t str_331f[] = { 0x30b5, 0x30a4, 0x30af, 0x30eb, 0 };
static const unichar_t str_3320[] = { 0x30b5, 0x30f3, 0x30c1, 0x30fc, 0x30e0, 0 };
static const unichar_t str_3321[] = { 0x30b7, 0x30ea, 0x30f3, 0x30b0, 0 };
static const unichar_t str_3322[] = { 0x30bb, 0x30f3, 0x30c1, 0 };
static const unichar_t str_3323[] = { 0x30bb, 0x30f3, 0x30c8, 0 };
static const unichar_t str_3324[] = { 0x30c0, 0x30fc, 0x30b9, 0 };
static const unichar_t str_3325[] = { 0x30c7, 0x30b7, 0 };
static const unichar_t str_3326[] = { 0x30c9, 0x30eb, 0 };
static const unichar_t str_3327[] = { 0x30c8, 0x30f3, 0 };
static const unichar_t str_3328[] = { 0x30ca, 0x30ce, 0 };
static const unichar_t str_3329[] = { 0x30ce, 0x30c3, 0x30c8, 0 };
static const unichar_t str_332a[] = { 0x30cf, 0x30a4, 0x30c4, 0 };
static const unichar_t str_332b[] = { 0x30d1, 0x30fc, 0x30bb, 0x30f3, 0x30c8, 0 };
static const unichar_t str_332c[] = { 0x30d1, 0x30fc, 0x30c4, 0 };
static const unichar_t str_332d[] = { 0x30d0, 0x30fc, 0x30ec, 0x30eb, 0 };
static const unichar_t str_332e[] = { 0x30d4, 0x30a2, 0x30b9, 0x30c8, 0x30eb, 0 };
static const unichar_t str_332f[] = { 0x30d4, 0x30af, 0x30eb, 0 };
static const unichar_t str_3330[] = { 0x30d4, 0x30b3, 0 };
static const unichar_t str_3331[] = { 0x30d3, 0x30eb, 0 };
static const unichar_t str_3332[] = { 0x30d5, 0x30a1, 0x30e9, 0x30c3, 0x30c9, 0 };
static const unichar_t str_3333[] = { 0x30d5, 0x30a3, 0x30fc, 0x30c8, 0 };
static const unichar_t str_3334[] = { 0x30d6, 0x30c3, 0x30b7, 0x30a7, 0x30eb, 0 };
static const unichar_t str_3335[] = { 0x30d5, 0x30e9, 0x30f3, 0 };
static const unichar_t str_3336[] = { 0x30d8, 0x30af, 0x30bf, 0x30fc, 0x30eb, 0 };
static const unichar_t str_3337[] = { 0x30da, 0x30bd, 0 };
static const unichar_t str_3338[] = { 0x30da, 0x30cb, 0x30d2, 0 };
static const unichar_t str_3339[] = { 0x30d8, 0x30eb, 0x30c4, 0 };
static const unichar_t str_333a[] = { 0x30da, 0x30f3, 0x30b9, 0 };
static const unichar_t str_333b[] = { 0x30da, 0x30fc, 0x30b8, 0 };
static const unichar_t str_333c[] = { 0x30d9, 0x30fc, 0x30bf, 0 };
static const unichar_t str_333d[] = { 0x30dd, 0x30a4, 0x30f3, 0x30c8, 0 };
static const unichar_t str_333e[] = { 0x30dc, 0x30eb, 0x30c8, 0 };
static const unichar_t str_333f[] = { 0x30db, 0x30f3, 0 };
static const unichar_t str_3340[] = { 0x30dd, 0x30f3, 0x30c9, 0 };
static const unichar_t str_3341[] = { 0x30db, 0x30fc, 0x30eb, 0 };
static const unichar_t str_3342[] = { 0x30db, 0x30fc, 0x30f3, 0 };
static const unichar_t str_3343[] = { 0x30de, 0x30a4, 0x30af, 0x30ed, 0 };
static const unichar_t str_3344[] = { 0x30de, 0x30a4, 0x30eb, 0 };
static const unichar_t str_3345[] = { 0x30de, 0x30c3, 0x30cf, 0 };
static const unichar_t str_3346[] = { 0x30de, 0x30eb, 0x30af, 0 };
static const unichar_t str_3347[] = { 0x30de, 0x30f3, 0x30b7, 0x30e7, 0x30f3, 0 };
static const unichar_t str_3348[] = { 0x30df, 0x30af, 0x30ed, 0x30f3, 0 };
static const unichar_t str_3349[] = { 0x30df, 0x30ea, 0 };
static const unichar_t str_334a[] = { 0x30df, 0x30ea, 0x30d0, 0x30fc, 0x30eb, 0 };
static const unichar_t str_334b[] = { 0x30e1, 0x30ac, 0 };
static const unichar_t str_334c[] = { 0x30e1, 0x30ac, 0x30c8, 0x30f3, 0 };
static const unichar_t str_334d[] = { 0x30e1, 0x30fc, 0x30c8, 0x30eb, 0 };
static const unichar_t str_334e[] = { 0x30e4, 0x30fc, 0x30c9, 0 };
static const unichar_t str_334f[] = { 0x30e4, 0x30fc, 0x30eb, 0 };
static const unichar_t str_3350[] = { 0x30e6, 0x30a2, 0x30f3, 0 };
static const unichar_t str_3351[] = { 0x30ea, 0x30c3, 0x30c8, 0x30eb, 0 };
static const unichar_t str_3352[] = { 0x30ea, 0x30e9, 0 };
static const unichar_t str_3353[] = { 0x30eb, 0x30d4, 0x30fc, 0 };
static const unichar_t str_3354[] = { 0x30eb, 0x30fc, 0x30d6, 0x30eb, 0 };
static const unichar_t str_3355[] = { 0x30ec, 0x30e0, 0 };
static const unichar_t str_3356[] = { 0x30ec, 0x30f3, 0x30c8, 0x30b2, 0x30f3, 0 };
static const unichar_t str_3357[] = { 0x30ef, 0x30c3, 0x30c8, 0 };
static const unichar_t str_3358[] = { 0x0030, 0x70b9, 0 };
static const unichar_t str_3359[] = { 0x0031, 0x70b9, 0 };
static const unichar_t str_335a[] = { 0x0032, 0x70b9, 0 };
static const unichar_t str_335b[] = { 0x0033, 0x70b9, 0 };
static const unichar_t str_335c[] = { 0x0034, 0x70b9, 0 };
static const unichar_t str_335d[] = { 0x0035, 0x70b9, 0 };
static const unichar_t str_335e[] = { 0x0036, 0x70b9, 0 };
static const unichar_t str_335f[] = { 0x0037, 0x70b9, 0 };
static const unichar_t str_3360[] = { 0x0038, 0x70b9, 0 };
static const unichar_t str_3361[] = { 0x0039, 0x70b9, 0 };
static const unichar_t str_3362[] = { 0x0031, 0x0030, 0x70b9, 0 };
static const unichar_t str_3363[] = { 0x0031, 0x0031, 0x70b9, 0 };
static const unichar_t str_3364[] = { 0x0031, 0x0032, 0x70b9, 0 };
static const unichar_t str_3365[] = { 0x0031, 0x0033, 0x70b9, 0 };
static const unichar_t str_3366[] = { 0x0031, 0x0034, 0x70b9, 0 };
static const unichar_t str_3367[] = { 0x0031, 0x0035, 0x70b9, 0 };
static const unichar_t str_3368[] = { 0x0031, 0x0036, 0x70b9, 0 };
static const unichar_t str_3369[] = { 0x0031, 0x0037, 0x70b9, 0 };
static const unichar_t str_336a[] = { 0x0031, 0x0038, 0x70b9, 0 };
static const unichar_t str_336b[] = { 0x0031, 0x0039, 0x70b9, 0 };
static const unichar_t str_336c[] = { 0x0032, 0x0030, 0x70b9, 0 };
static const unichar_t str_336d[] = { 0x0032, 0x0031, 0x70b9, 0 };
static const unichar_t str_336e[] = { 0x0032, 0x0032, 0x70b9, 0 };
static const unichar_t str_336f[] = { 0x0032, 0x0033, 0x70b9, 0 };
static const unichar_t str_3370[] = { 0x0032, 0x0034, 0x70b9, 0 };
static const unichar_t str_3371[] = { 0x0068, 0x0050, 0x0061, 0 };
static const unichar_t str_3372[] = { 0x0064, 0x0061, 0 };
static const unichar_t str_3373[] = { 0x0041, 0x0055, 0 };
static const unichar_t str_3374[] = { 0x0062, 0x0061, 0x0072, 0 };
static const unichar_t str_3375[] = { 0x006f, 0x0056, 0 };
static const unichar_t str_3376[] = { 0x0070, 0x0063, 0 };
static const unichar_t str_3377[] = { 0x0064, 0x006d, 0 };
static const unichar_t str_3378[] = { 0x0064, 0x006d, 0x00b2, 0 };
static const unichar_t str_3379[] = { 0x0064, 0x006d, 0x00b3, 0 };
static const unichar_t str_337a[] = { 0x0049, 0x0055, 0 };
static const unichar_t str_337b[] = { 0x5e73, 0x6210, 0 };
static const unichar_t str_337c[] = { 0x662d, 0x548c, 0 };
static const unichar_t str_337d[] = { 0x5927, 0x6b63, 0 };
static const unichar_t str_337e[] = { 0x660e, 0x6cbb, 0 };
static const unichar_t str_337f[] = { 0x682a, 0x5f0f, 0x4f1a, 0x793e, 0 };
static const unichar_t str_3380[] = { 0x0070, 0x0041, 0 };
static const unichar_t str_3381[] = { 0x006e, 0x0041, 0 };
static const unichar_t str_3382[] = { 0x03bc, 0x0041, 0 };
static const unichar_t str_3383[] = { 0x006d, 0x0041, 0 };
static const unichar_t str_3384[] = { 0x006b, 0x0041, 0 };
static const unichar_t str_3385[] = { 0x004b, 0x0042, 0 };
static const unichar_t str_3386[] = { 0x004d, 0x0042, 0 };
static const unichar_t str_3387[] = { 0x0047, 0x0042, 0 };
static const unichar_t str_3388[] = { 0x0063, 0x0061, 0x006c, 0 };
static const unichar_t str_3389[] = { 0x006b, 0x0063, 0x0061, 0x006c, 0 };
static const unichar_t str_338a[] = { 0x0070, 0x0046, 0 };
static const unichar_t str_338b[] = { 0x006e, 0x0046, 0 };
static const unichar_t str_338c[] = { 0x03bc, 0x0046, 0 };
static const unichar_t str_338d[] = { 0x03bc, 0x0067, 0 };
static const unichar_t str_338e[] = { 0x006d, 0x0067, 0 };
static const unichar_t str_338f[] = { 0x006b, 0x0067, 0 };
static const unichar_t str_3390[] = { 0x0048, 0x007a, 0 };
static const unichar_t str_3391[] = { 0x006b, 0x0048, 0x007a, 0 };
static const unichar_t str_3392[] = { 0x004d, 0x0048, 0x007a, 0 };
static const unichar_t str_3393[] = { 0x0047, 0x0048, 0x007a, 0 };
static const unichar_t str_3394[] = { 0x0054, 0x0048, 0x007a, 0 };
static const unichar_t str_3395[] = { 0x03bc, 0x2113, 0 };
static const unichar_t str_3396[] = { 0x006d, 0x2113, 0 };
static const unichar_t str_3397[] = { 0x0064, 0x2113, 0 };
static const unichar_t str_3398[] = { 0x006b, 0x2113, 0 };
static const unichar_t str_3399[] = { 0x0066, 0x006d, 0 };
static const unichar_t str_339a[] = { 0x006e, 0x006d, 0 };
static const unichar_t str_339b[] = { 0x03bc, 0x006d, 0 };
static const unichar_t str_339c[] = { 0x006d, 0x006d, 0 };
static const unichar_t str_339d[] = { 0x0063, 0x006d, 0 };
static const unichar_t str_339e[] = { 0x006b, 0x006d, 0 };
static const unichar_t str_339f[] = { 0x006d, 0x006d, 0x00b2, 0 };
static const unichar_t str_33a0[] = { 0x0063, 0x006d, 0x00b2, 0 };
static const unichar_t str_33a1[] = { 0x006d, 0x00b2, 0 };
static const unichar_t str_33a2[] = { 0x006b, 0x006d, 0x00b2, 0 };
static const unichar_t str_33a3[] = { 0x006d, 0x006d, 0x00b3, 0 };
static const unichar_t str_33a4[] = { 0x0063, 0x006d, 0x00b3, 0 };
static const unichar_t str_33a5[] = { 0x006d, 0x00b3, 0 };
static const unichar_t str_33a6[] = { 0x006b, 0x006d, 0x00b3, 0 };
static const unichar_t str_33a7[] = { 0x006d, 0x2215, 0x0073, 0 };
static const unichar_t str_33a8[] = { 0x006d, 0x2215, 0x0073, 0x00b2, 0 };
static const unichar_t str_33a9[] = { 0x0050, 0x0061, 0 };
static const unichar_t str_33aa[] = { 0x006b, 0x0050, 0x0061, 0 };
static const unichar_t str_33ab[] = { 0x004d, 0x0050, 0x0061, 0 };
static const unichar_t str_33ac[] = { 0x0047, 0x0050, 0x0061, 0 };
static const unichar_t str_33ad[] = { 0x0072, 0x0061, 0x0064, 0 };
static const unichar_t str_33ae[] = { 0x0072, 0x0061, 0x0064, 0x2215, 0x0073, 0 };
static const unichar_t str_33af[] = { 0x0072, 0x0061, 0x0064, 0x2215, 0x0073, 0x00b2, 0 };
static const unichar_t str_33b0[] = { 0x0070, 0x0073, 0 };
static const unichar_t str_33b1[] = { 0x006e, 0x0073, 0 };
static const unichar_t str_33b2[] = { 0x03bc, 0x0073, 0 };
static const unichar_t str_33b3[] = { 0x006d, 0x0073, 0 };
static const unichar_t str_33b4[] = { 0x0070, 0x0056, 0 };
static const unichar_t str_33b5[] = { 0x006e, 0x0056, 0 };
static const unichar_t str_33b6[] = { 0x03bc, 0x0056, 0 };
static const unichar_t str_33b7[] = { 0x006d, 0x0056, 0 };
static const unichar_t str_33b8[] = { 0x006b, 0x0056, 0 };
static const unichar_t str_33b9[] = { 0x004d, 0x0056, 0 };
static const unichar_t str_33ba[] = { 0x0070, 0x0057, 0 };
static const unichar_t str_33bb[] = { 0x006e, 0x0057, 0 };
static const unichar_t str_33bc[] = { 0x03bc, 0x0057, 0 };
static const unichar_t str_33bd[] = { 0x006d, 0x0057, 0 };
static const unichar_t str_33be[] = { 0x006b, 0x0057, 0 };
static const unichar_t str_33bf[] = { 0x004d, 0x0057, 0 };
static const unichar_t str_33c0[] = { 0x006b, 0x03a9, 0 };
static const unichar_t str_33c1[] = { 0x004d, 0x03a9, 0 };
static const unichar_t str_33c2[] = { 0x0061, 0x002e, 0x006d, 0x002e, 0 };
static const unichar_t str_33c3[] = { 0x0042, 0x0071, 0 };
static const unichar_t str_33c4[] = { 0x0063, 0x0063, 0 };
static const unichar_t str_33c5[] = { 0x0063, 0x0064, 0 };
static const unichar_t str_33c6[] = { 0x0043, 0x2215, 0x006b, 0x0067, 0 };
static const unichar_t str_33c7[] = { 0x0043, 0x006f, 0x002e, 0 };
static const unichar_t str_33c8[] = { 0x0064, 0x0042, 0 };
static const unichar_t str_33c9[] = { 0x0047, 0x0079, 0 };
static const unichar_t str_33ca[] = { 0x0068, 0x0061, 0 };
static const unichar_t str_33cb[] = { 0x0048, 0x0050, 0 };
static const unichar_t str_33cc[] = { 0x0069, 0x006e, 0 };
static const unichar_t str_33cd[] = { 0x004b, 0x004b, 0 };
static const unichar_t str_33ce[] = { 0x004b, 0x004d, 0 };
static const unichar_t str_33cf[] = { 0x006b, 0x0074, 0 };
static const unichar_t str_33d0[] = { 0x006c, 0x006d, 0 };
static const unichar_t str_33d1[] = { 0x006c, 0x006e, 0 };
static const unichar_t str_33d2[] = { 0x006c, 0x006f, 0x0067, 0 };
static const unichar_t str_33d3[] = { 0x006c, 0x0078, 0 };
static const unichar_t str_33d4[] = { 0x006d, 0x0062, 0 };
static const unichar_t str_33d5[] = { 0x006d, 0x0069, 0x006c, 0 };
static const unichar_t str_33d6[] = { 0x006d, 0x006f, 0x006c, 0 };
static const unichar_t str_33d7[] = { 0x0050, 0x0048, 0 };
static const unichar_t str_33d8[] = { 0x0070, 0x002e, 0x006d, 0x002e, 0 };
static const unichar_t str_33d9[] = { 0x0050, 0x0050, 0x004d, 0 };
static const unichar_t str_33da[] = { 0x0050, 0x0052, 0 };
static const unichar_t str_33db[] = { 0x0073, 0x0072, 0 };
static const unichar_t str_33dc[] = { 0x0053, 0x0076, 0 };
static const unichar_t str_33dd[] = { 0x0057, 0x0062, 0 };
static const unichar_t str_33de[] = { 0x0056, 0x2215, 0x006d, 0 };
static const unichar_t str_33df[] = { 0x0041, 0x2215, 0x006d, 0 };
static const unichar_t str_33e0[] = { 0x0031, 0x65e5, 0 };
static const unichar_t str_33e1[] = { 0x0032, 0x65e5, 0 };
static const unichar_t str_33e2[] = { 0x0033, 0x65e5, 0 };
static const unichar_t str_33e3[] = { 0x0034, 0x65e5, 0 };
static const unichar_t str_33e4[] = { 0x0035, 0x65e5, 0 };
static const unichar_t str_33e5[] = { 0x0036, 0x65e5, 0 };
static const unichar_t str_33e6[] = { 0x0037, 0x65e5, 0 };
static const unichar_t str_33e7[] = { 0x0038, 0x65e5, 0 };
static const unichar_t str_33e8[] = { 0x0039, 0x65e5, 0 };
static const unichar_t str_33e9[] = { 0x0031, 0x0030, 0x65e5, 0 };
static const unichar_t str_33ea[] = { 0x0031, 0x0031, 0x65e5, 0 };
static const unichar_t str_33eb[] = { 0x0031, 0x0032, 0x65e5, 0 };
static const unichar_t str_33ec[] = { 0x0031, 0x0033, 0x65e5, 0 };
static const unichar_t str_33ed[] = { 0x0031, 0x0034, 0x65e5, 0 };
static const unichar_t str_33ee[] = { 0x0031, 0x0035, 0x65e5, 0 };
static const unichar_t str_33ef[] = { 0x0031, 0x0036, 0x65e5, 0 };
static const unichar_t str_33f0[] = { 0x0031, 0x0037, 0x65e5, 0 };
static const unichar_t str_33f1[] = { 0x0031, 0x0038, 0x65e5, 0 };
static const unichar_t str_33f2[] = { 0x0031, 0x0039, 0x65e5, 0 };
static const unichar_t str_33f3[] = { 0x0032, 0x0030, 0x65e5, 0 };
static const unichar_t str_33f4[] = { 0x0032, 0x0031, 0x65e5, 0 };
static const unichar_t str_33f5[] = { 0x0032, 0x0032, 0x65e5, 0 };
static const unichar_t str_33f6[] = { 0x0032, 0x0033, 0x65e5, 0 };
static const unichar_t str_33f7[] = { 0x0032, 0x0034, 0x65e5, 0 };
static const unichar_t str_33f8[] = { 0x0032, 0x0035, 0x65e5, 0 };
static const unichar_t str_33f9[] = { 0x0032, 0x0036, 0x65e5, 0 };
static const unichar_t str_33fa[] = { 0x0032, 0x0037, 0x65e5, 0 };
static const unichar_t str_33fb[] = { 0x0032, 0x0038, 0x65e5, 0 };
static const unichar_t str_33fc[] = { 0x0032, 0x0039, 0x65e5, 0 };
static const unichar_t str_33fd[] = { 0x0033, 0x0030, 0x65e5, 0 };
static const unichar_t str_33fe[] = { 0x0033, 0x0031, 0x65e5, 0 };
static const unichar_t str_33ff[] = { 0x0067, 0x0061, 0x006c, 0 };
static const unichar_t str_a69c[] = { 0x044a, 0 };
static const unichar_t str_a69d[] = { 0x044c, 0 };
static const unichar_t str_a770[] = { 0xa76f, 0 };
static const unichar_t str_a7f8[] = { 0x0126, 0 };
static const unichar_t str_a7f9[] = { 0x0153, 0 };
static const unichar_t str_ab5c[] = { 0xa727, 0 };
static const unichar_t str_ab5d[] = { 0xab37, 0 };
static const unichar_t str_ab5e[] = { 0x026b, 0 };
static const unichar_t str_ab5f[] = { 0xab52, 0 };
static const unichar_t str_f900[] = { 0x8c48, 0 };
static const unichar_t str_f901[] = { 0x66f4, 0 };
static const unichar_t str_f902[] = { 0x8eca, 0 };
static const unichar_t str_f903[] = { 0x8cc8, 0 };
static const unichar_t str_f904[] = { 0x6ed1, 0 };
static const unichar_t str_f905[] = { 0x4e32, 0 };
static const unichar_t str_f906[] = { 0x53e5, 0 };
static const unichar_t str_f907[] = { 0x9f9c, 0 };
static const unichar_t str_f908[] = { 0x9f9c, 0 };
static const unichar_t str_f909[] = { 0x5951, 0 };
static const unichar_t str_f90a[] = { 0x91d1, 0 };
static const unichar_t str_f90b[] = { 0x5587, 0 };
static const unichar_t str_f90c[] = { 0x5948, 0 };
static const unichar_t str_f90d[] = { 0x61f6, 0 };
static const unichar_t str_f90e[] = { 0x7669, 0 };
static const unichar_t str_f90f[] = { 0x7f85, 0 };
static const unichar_t str_f910[] = { 0x863f, 0 };
static const unichar_t str_f911[] = { 0x87ba, 0 };
static const unichar_t str_f912[] = { 0x88f8, 0 };
static const unichar_t str_f913[] = { 0x908f, 0 };
static const unichar_t str_f914[] = { 0x6a02, 0 };
static const unichar_t str_f915[] = { 0x6d1b, 0 };
static const unichar_t str_f916[] = { 0x70d9, 0 };
static const unichar_t str_f917[] = { 0x73de, 0 };
static const unichar_t str_f918[] = { 0x843d, 0 };
static const unichar_t str_f919[] = { 0x916a, 0 };
static const unichar_t str_f91a[] = { 0x99f1, 0 };
static const unichar_t str_f91b[] = { 0x4e82, 0 };
static const unichar_t str_f91c[] = { 0x5375, 0 };
static const unichar_t str_f91d[] = { 0x6b04, 0 };
static const unichar_t str_f91e[] = { 0x721b, 0 };
static const unichar_t str_f91f[] = { 0x862d, 0 };
static const unichar_t str_f920[] = { 0x9e1e, 0 };
static const unichar_t str_f921[] = { 0x5d50, 0 };
static const unichar_t str_f922[] = { 0x6feb, 0 };
static const unichar_t str_f923[] = { 0x85cd, 0 };
static const unichar_t str_f924[] = { 0x8964, 0 };
static const unichar_t str_f925[] = { 0x62c9, 0 };
static const unichar_t str_f926[] = { 0x81d8, 0 };
static const unichar_t str_f927[] = { 0x881f, 0 };
static const unichar_t str_f928[] = { 0x5eca, 0 };
static const unichar_t str_f929[] = { 0x6717, 0 };
static const unichar_t str_f92a[] = { 0x6d6a, 0 };
static const unichar_t str_f92b[] = { 0x72fc, 0 };
static const unichar_t str_f92c[] = { 0x90ce, 0 };
static const unichar_t str_f92d[] = { 0x4f86, 0 };
static const unichar_t str_f92e[] = { 0x51b7, 0 };
static const unichar_t str_f92f[] = { 0x52de, 0 };
static const unichar_t str_f930[] = { 0x64c4, 0 };
static const unichar_t str_f931[] = { 0x6ad3, 0 };
static const unichar_t str_f932[] = { 0x7210, 0 };
static const unichar_t str_f933[] = { 0x76e7, 0 };
static const unichar_t str_f934[] = { 0x8001, 0 };
static const unichar_t str_f935[] = { 0x8606, 0 };
static const unichar_t str_f936[] = { 0x865c, 0 };
static const unichar_t str_f937[] = { 0x8def, 0 };
static const unichar_t str_f938[] = { 0x9732, 0 };
static const unichar_t str_f939[] = { 0x9b6f, 0 };
static const unichar_t str_f93a[] = { 0x9dfa, 0 };
static const unichar_t str_f93b[] = { 0x788c, 0 };
static const unichar_t str_f93c[] = { 0x797f, 0 };
static const unichar_t str_f93d[] = { 0x7da0, 0 };
static const unichar_t str_f93e[] = { 0x83c9, 0 };
static const unichar_t str_f93f[] = { 0x9304, 0 };
static const unichar_t str_f940[] = { 0x9e7f, 0 };
static const unichar_t str_f941[] = { 0x8ad6, 0 };
static const unichar_t str_f942[] = { 0x58df, 0 };
static const unichar_t str_f943[] = { 0x5f04, 0 };
static const unichar_t str_f944[] = { 0x7c60, 0 };
static const unichar_t str_f945[] = { 0x807e, 0 };
static const unichar_t str_f946[] = { 0x7262, 0 };
static const unichar_t str_f947[] = { 0x78ca, 0 };
static const unichar_t str_f948[] = { 0x8cc2, 0 };
static const unichar_t str_f949[] = { 0x96f7, 0 };
static const unichar_t str_f94a[] = { 0x58d8, 0 };
static const unichar_t str_f94b[] = { 0x5c62, 0 };
static const unichar_t str_f94c[] = { 0x6a13, 0 };
static const unichar_t str_f94d[] = { 0x6dda, 0 };
static const unichar_t str_f94e[] = { 0x6f0f, 0 };
static const unichar_t str_f94f[] = { 0x7d2f, 0 };
static const unichar_t str_f950[] = { 0x7e37, 0 };
static const unichar_t str_f951[] = { 0x964b, 0 };
static const unichar_t str_f952[] = { 0x52d2, 0 };
static const unichar_t str_f953[] = { 0x808b, 0 };
static const unichar_t str_f954[] = { 0x51dc, 0 };
static const unichar_t str_f955[] = { 0x51cc, 0 };
static const unichar_t str_f956[] = { 0x7a1c, 0 };
static const unichar_t str_f957[] = { 0x7dbe, 0 };
static const unichar_t str_f958[] = { 0x83f1, 0 };
static const unichar_t str_f959[] = { 0x9675, 0 };
static const unichar_t str_f95a[] = { 0x8b80, 0 };
static const unichar_t str_f95b[] = { 0x62cf, 0 };
static const unichar_t str_f95c[] = { 0x6a02, 0 };
static const unichar_t str_f95d[] = { 0x8afe, 0 };
static const unichar_t str_f95e[] = { 0x4e39, 0 };
static const unichar_t str_f95f[] = { 0x5be7, 0 };
static const unichar_t str_f960[] = { 0x6012, 0 };
static const unichar_t str_f961[] = { 0x7387, 0 };
static const unichar_t str_f962[] = { 0x7570, 0 };
static const unichar_t str_f963[] = { 0x5317, 0 };
static const unichar_t str_f964[] = { 0x78fb, 0 };
static const unichar_t str_f965[] = { 0x4fbf, 0 };
static const unichar_t str_f966[] = { 0x5fa9, 0 };
static const unichar_t str_f967[] = { 0x4e0d, 0 };
static const unichar_t str_f968[] = { 0x6ccc, 0 };
static const unichar_t str_f969[] = { 0x6578, 0 };
static const unichar_t str_f96a[] = { 0x7d22, 0 };
static const unichar_t str_f96b[] = { 0x53c3, 0 };
static const unichar_t str_f96c[] = { 0x585e, 0 };
static const unichar_t str_f96d[] = { 0x7701, 0 };
static const unichar_t str_f96e[] = { 0x8449, 0 };
static const unichar_t str_f96f[] = { 0x8aaa, 0 };
static const unichar_t str_f970[] = { 0x6bba, 0 };
static const unichar_t str_f971[] = { 0x8fb0, 0 };
static const unichar_t str_f972[] = { 0x6c88, 0 };
static const unichar_t str_f973[] = { 0x62fe, 0 };
static const unichar_t str_f974[] = { 0x82e5, 0 };
static const unichar_t str_f975[] = { 0x63a0, 0 };
static const unichar_t str_f976[] = { 0x7565, 0 };
static const unichar_t str_f977[] = { 0x4eae, 0 };
static const unichar_t str_f978[] = { 0x5169, 0 };
static const unichar_t str_f979[] = { 0x51c9, 0 };
static const unichar_t str_f97a[] = { 0x6881, 0 };
static const unichar_t str_f97b[] = { 0x7ce7, 0 };
static const unichar_t str_f97c[] = { 0x826f, 0 };
static const unichar_t str_f97d[] = { 0x8ad2, 0 };
static const unichar_t str_f97e[] = { 0x91cf, 0 };
static const unichar_t str_f97f[] = { 0x52f5, 0 };
static const unichar_t str_f980[] = { 0x5442, 0 };
static const unichar_t str_f981[] = { 0x5973, 0 };
static const unichar_t str_f982[] = { 0x5eec, 0 };
static const unichar_t str_f983[] = { 0x65c5, 0 };
static const unichar_t str_f984[] = { 0x6ffe, 0 };
static const unichar_t str_f985[] = { 0x792a, 0 };
static const unichar_t str_f986[] = { 0x95ad, 0 };
static const unichar_t str_f987[] = { 0x9a6a, 0 };
static const unichar_t str_f988[] = { 0x9e97, 0 };
static const unichar_t str_f989[] = { 0x9ece, 0 };
static const unichar_t str_f98a[] = { 0x529b, 0 };
static const unichar_t str_f98b[] = { 0x66c6, 0 };
static const unichar_t str_f98c[] = { 0x6b77, 0 };
static const unichar_t str_f98d[] = { 0x8f62, 0 };
static const unichar_t str_f98e[] = { 0x5e74, 0 };
static const unichar_t str_f98f[] = { 0x6190, 0 };
static const unichar_t str_f990[] = { 0x6200, 0 };
static const unichar_t str_f991[] = { 0x649a, 0 };
static const unichar_t str_f992[] = { 0x6f23, 0 };
static const unichar_t str_f993[] = { 0x7149, 0 };
static const unichar_t str_f994[] = { 0x7489, 0 };
static const unichar_t str_f995[] = { 0x79ca, 0 };
static const unichar_t str_f996[] = { 0x7df4, 0 };
static const unichar_t str_f997[] = { 0x806f, 0 };
static const unichar_t str_f998[] = { 0x8f26, 0 };
static const unichar_t str_f999[] = { 0x84ee, 0 };
static const unichar_t str_f99a[] = { 0x9023, 0 };
static const unichar_t str_f99b[] = { 0x934a, 0 };
static const unichar_t str_f99c[] = { 0x5217, 0 };
static const unichar_t str_f99d[] = { 0x52a3, 0 };
static const unichar_t str_f99e[] = { 0x54bd, 0 };
static const unichar_t str_f99f[] = { 0x70c8, 0 };
static const unichar_t str_f9a0[] = { 0x88c2, 0 };
static const unichar_t str_f9a1[] = { 0x8aaa, 0 };
static const unichar_t str_f9a2[] = { 0x5ec9, 0 };
static const unichar_t str_f9a3[] = { 0x5ff5, 0 };
static const unichar_t str_f9a4[] = { 0x637b, 0 };
static const unichar_t str_f9a5[] = { 0x6bae, 0 };
static const unichar_t str_f9a6[] = { 0x7c3e, 0 };
static const unichar_t str_f9a7[] = { 0x7375, 0 };
static const unichar_t str_f9a8[] = { 0x4ee4, 0 };
static const unichar_t str_f9a9[] = { 0x56f9, 0 };
static const unichar_t str_f9aa[] = { 0x5be7, 0 };
static const unichar_t str_f9ab[] = { 0x5dba, 0 };
static const unichar_t str_f9ac[] = { 0x601c, 0 };
static const unichar_t str_f9ad[] = { 0x73b2, 0 };
static const unichar_t str_f9ae[] = { 0x7469, 0 };
static const unichar_t str_f9af[] = { 0x7f9a, 0 };
static const unichar_t str_f9b0[] = { 0x8046, 0 };
static const unichar_t str_f9b1[] = { 0x9234, 0 };
static const unichar_t str_f9b2[] = { 0x96f6, 0 };
static const unichar_t str_f9b3[] = { 0x9748, 0 };
static const unichar_t str_f9b4[] = { 0x9818, 0 };
static const unichar_t str_f9b5[] = { 0x4f8b, 0 };
static const unichar_t str_f9b6[] = { 0x79ae, 0 };
static const unichar_t str_f9b7[] = { 0x91b4, 0 };
static const unichar_t str_f9b8[] = { 0x96b8, 0 };
static const unichar_t str_f9b9[] = { 0x60e1, 0 };
static const unichar_t str_f9ba[] = { 0x4e86, 0 };
static const unichar_t str_f9bb[] = { 0x50da, 0 };
static const unichar_t str_f9bc[] = { 0x5bee, 0 };
static const unichar_t str_f9bd[] = { 0x5c3f, 0 };
static const unichar_t str_f9be[] = { 0x6599, 0 };
static const unichar_t str_f9bf[] = { 0x6a02, 0 };
static const unichar_t str_f9c0[] = { 0x71ce, 0 };
static const unichar_t str_f9c1[] = { 0x7642, 0 };
static const unichar_t str_f9c2[] = { 0x84fc, 0 };
static const unichar_t str_f9c3[] = { 0x907c, 0 };
static const unichar_t str_f9c4[] = { 0x9f8d, 0 };
static const unichar_t str_f9c5[] = { 0x6688, 0 };
static const unichar_t str_f9c6[] = { 0x962e, 0 };
static const unichar_t str_f9c7[] = { 0x5289, 0 };
static const unichar_t str_f9c8[] = { 0x677b, 0 };
static const unichar_t str_f9c9[] = { 0x67f3, 0 };
static const unichar_t str_f9ca[] = { 0x6d41, 0 };
static const unichar_t str_f9cb[] = { 0x6e9c, 0 };
static const unichar_t str_f9cc[] = { 0x7409, 0 };
static const unichar_t str_f9cd[] = { 0x7559, 0 };
static const unichar_t str_f9ce[] = { 0x786b, 0 };
static const unichar_t str_f9cf[] = { 0x7d10, 0 };
static const unichar_t str_f9d0[] = { 0x985e, 0 };
static const unichar_t str_f9d1[] = { 0x516d, 0 };
static const unichar_t str_f9d2[] = { 0x622e, 0 };
static const unichar_t str_f9d3[] = { 0x9678, 0 };
static const unichar_t str_f9d4[] = { 0x502b, 0 };
static const unichar_t str_f9d5[] = { 0x5d19, 0 };
static const unichar_t str_f9d6[] = { 0x6dea, 0 };
static const unichar_t str_f9d7[] = { 0x8f2a, 0 };
static const unichar_t str_f9d8[] = { 0x5f8b, 0 };
static const unichar_t str_f9d9[] = { 0x6144, 0 };
static const unichar_t str_f9da[] = { 0x6817, 0 };
static const unichar_t str_f9db[] = { 0x7387, 0 };
static const unichar_t str_f9dc[] = { 0x9686, 0 };
static const unichar_t str_f9dd[] = { 0x5229, 0 };
static const unichar_t str_f9de[] = { 0x540f, 0 };
static const unichar_t str_f9df[] = { 0x5c65, 0 };
static const unichar_t str_f9e0[] = { 0x6613, 0 };
static const unichar_t str_f9e1[] = { 0x674e, 0 };
static const unichar_t str_f9e2[] = { 0x68a8, 0 };
static const unichar_t str_f9e3[] = { 0x6ce5, 0 };
static const unichar_t str_f9e4[] = { 0x7406, 0 };
static const unichar_t str_f9e5[] = { 0x75e2, 0 };
static const unichar_t str_f9e6[] = { 0x7f79, 0 };
static const unichar_t str_f9e7[] = { 0x88cf, 0 };
static const unichar_t str_f9e8[] = { 0x88e1, 0 };
static const unichar_t str_f9e9[] = { 0x91cc, 0 };
static const unichar_t str_f9ea[] = { 0x96e2, 0 };
static const unichar_t str_f9eb[] = { 0x533f, 0 };
static const unichar_t str_f9ec[] = { 0x6eba, 0 };
static const unichar_t str_f9ed[] = { 0x541d, 0 };
static const unichar_t str_f9ee[] = { 0x71d0, 0 };
static const unichar_t str_f9ef[] = { 0x7498, 0 };
static const unichar_t str_f9f0[] = { 0x85fa, 0 };
static const unichar_t str_f9f1[] = { 0x96a3, 0 };
static const unichar_t str_f9f2[] = { 0x9c57, 0 };
static const unichar_t str_f9f3[] = { 0x9e9f, 0 };
static const unichar_t str_f9f4[] = { 0x6797, 0 };
static const unichar_t str_f9f5[] = { 0x6dcb, 0 };
static const unichar_t str_f9f6[] = { 0x81e8, 0 };
static const unichar_t str_f9f7[] = { 0x7acb, 0 };
static const unichar_t str_f9f8[] = { 0x7b20, 0 };
static const unichar_t str_f9f9[] = { 0x7c92, 0 };
static const unichar_t str_f9fa[] = { 0x72c0, 0 };
static const unichar_t str_f9fb[] = { 0x7099, 0 };
static const unichar_t str_f9fc[] = { 0x8b58, 0 };
static const unichar_t str_f9fd[] = { 0x4ec0, 0 };
static const unichar_t str_f9fe[] = { 0x8336, 0 };
static const unichar_t str_f9ff[] = { 0x523a, 0 };
static const unichar_t str_fa00[] = { 0x5207, 0 };
static const unichar_t str_fa01[] = { 0x5ea6, 0 };
static const unichar_t str_fa02[] = { 0x62d3, 0 };
static const unichar_t str_fa03[] = { 0x7cd6, 0 };
static const unichar_t str_fa04[] = { 0x5b85, 0 };
static const unichar_t str_fa05[] = { 0x6d1e, 0 };
static const unichar_t str_fa06[] = { 0x66b4, 0 };
static const unichar_t str_fa07[] = { 0x8f3b, 0 };
static const unichar_t str_fa08[] = { 0x884c, 0 };
static const unichar_t str_fa09[] = { 0x964d, 0 };
static const unichar_t str_fa0a[] = { 0x898b, 0 };
static const unichar_t str_fa0b[] = { 0x5ed3, 0 };
static const unichar_t str_fa0c[] = { 0x5140, 0 };
static const unichar_t str_fa0d[] = { 0x55c0, 0 };
static const unichar_t str_fa10[] = { 0x585a, 0 };
static const unichar_t str_fa12[] = { 0x6674, 0 };
static const unichar_t str_fa15[] = { 0x51de, 0 };
static const unichar_t str_fa16[] = { 0x732a, 0 };
static const unichar_t str_fa17[] = { 0x76ca, 0 };
static const unichar_t str_fa18[] = { 0x793c, 0 };
static const unichar_t str_fa19[] = { 0x795e, 0 };
static const unichar_t str_fa1a[] = { 0x7965, 0 };
static const unichar_t str_fa1b[] = { 0x798f, 0 };
static const unichar_t str_fa1c[] = { 0x9756, 0 };
static const unichar_t str_fa1d[] = { 0x7cbe, 0 };
static const unichar_t str_fa1e[] = { 0x7fbd, 0 };
static const unichar_t str_fa20[] = { 0x8612, 0 };
static const unichar_t str_fa22[] = { 0x8af8, 0 };
static const unichar_t str_fa25[] = { 0x9038, 0 };
static const unichar_t str_fa26[] = { 0x90fd, 0 };
static const unichar_t str_fa2a[] = { 0x98ef, 0 };
static const unichar_t str_fa2b[] = { 0x98fc, 0 };
static const unichar_t str_fa2c[] = { 0x9928, 0 };
static const unichar_t str_fa2d[] = { 0x9db4, 0 };
static const unichar_t str_fa2e[] = { 0x90de, 0 };
static const unichar_t str_fa2f[] = { 0x96b7, 0 };
static const unichar_t str_fa30[] = { 0x4fae, 0 };
static const unichar_t str_fa31[] = { 0x50e7, 0 };
static const unichar_t str_fa32[] = { 0x514d, 0 };
static const unichar_t str_fa33[] = { 0x52c9, 0 };
static const unichar_t str_fa34[] = { 0x52e4, 0 };
static const unichar_t str_fa35[] = { 0x5351, 0 };
static const unichar_t str_fa36[] = { 0x559d, 0 };
static const unichar_t str_fa37[] = { 0x5606, 0 };
static const unichar_t str_fa38[] = { 0x5668, 0 };
static const unichar_t str_fa39[] = { 0x5840, 0 };
static const unichar_t str_fa3a[] = { 0x58a8, 0 };
static const unichar_t str_fa3b[] = { 0x5c64, 0 };
static const unichar_t str_fa3c[] = { 0x5c6e, 0 };
static const unichar_t str_fa3d[] = { 0x6094, 0 };
static const unichar_t str_fa3e[] = { 0x6168, 0 };
static const unichar_t str_fa3f[] = { 0x618e, 0 };
static const unichar_t str_fa40[] = { 0x61f2, 0 };
static const unichar_t str_fa41[] = { 0x654f, 0 };
static const unichar_t str_fa42[] = { 0x65e2, 0 };
static const unichar_t str_fa43[] = { 0x6691, 0 };
static const unichar_t str_fa44[] = { 0x6885, 0 };
static const unichar_t str_fa45[] = { 0x6d77, 0 };
static const unichar_t str_fa46[] = { 0x6e1a, 0 };
static const unichar_t str_fa47[] = { 0x6f22, 0 };
static const unichar_t str_fa48[] = { 0x716e, 0 };
static const unichar_t str_fa49[] = { 0x722b, 0 };
static const unichar_t str_fa4a[] = { 0x7422, 0 };
static const unichar_t str_fa4b[] = { 0x7891, 0 };
static const unichar_t str_fa4c[] = { 0x793e, 0 };
static const unichar_t str_fa4d[] = { 0x7949, 0 };
static const unichar_t str_fa4e[] = { 0x7948, 0 };
static const unichar_t str_fa4f[] = { 0x7950, 0 };
static const unichar_t str_fa50[] = { 0x7956, 0 };
static const unichar_t str_fa51[] = { 0x795d, 0 };
static const unichar_t str_fa52[] = { 0x798d, 0 };
static const unichar_t str_fa53[] = { 0x798e, 0 };
static const unichar_t str_fa54[] = { 0x7a40, 0 };
static const unichar_t str_fa55[] = { 0x7a81, 0 };
static const unichar_t str_fa56[] = { 0x7bc0, 0 };
static const unichar_t str_fa57[] = { 0x7df4, 0 };
static const unichar_t str_fa58[] = { 0x7e09, 0 };
static const unichar_t str_fa59[] = { 0x7e41, 0 };
static const unichar_t str_fa5a[] = { 0x7f72, 0 };
static const unichar_t str_fa5b[] = { 0x8005, 0 };
static const unichar_t str_fa5c[] = { 0x81ed, 0 };
static const unichar_t str_fa5d[] = { 0x8279, 0 };
static const unichar_t str_fa5e[] = { 0x8279, 0 };
static const unichar_t str_fa5f[] = { 0x8457, 0 };
static const unichar_t str_fa60[] = { 0x8910, 0 };
static const unichar_t str_fa61[] = { 0x8996, 0 };
static const unichar_t str_fa62[] = { 0x8b01, 0 };
static const unichar_t str_fa63[] = { 0x8b39, 0 };
static const unichar_t str_fa64[] = { 0x8cd3, 0 };
static const unichar_t str_fa65[] = { 0x8d08, 0 };
static const unichar_t str_fa66[] = { 0x8fb6, 0 };
static const unichar_t str_fa67[] = { 0x9038, 0 };
static const unichar_t str_fa68[] = { 0x96e3, 0 };
static const unichar_t str_fa69[] = { 0x97ff, 0 };
static const unichar_t str_fa6a[] = { 0x983b, 0 };
static const unichar_t str_fa6b[] = { 0x6075, 0 };
static const unichar_t str_fa6c[] = { 0x242ee, 0 };
static const unichar_t str_fa6d[] = { 0x8218, 0 };
static const unichar_t str_fa70[] = { 0x4e26, 0 };
static const unichar_t str_fa71[] = { 0x51b5, 0 };
static const unichar_t str_fa72[] = { 0x5168, 0 };
static const unichar_t str_fa73[] = { 0x4f80, 0 };
static const unichar_t str_fa74[] = { 0x5145, 0 };
static const unichar_t str_fa75[] = { 0x5180, 0 };
static const unichar_t str_fa76[] = { 0x52c7, 0 };
static const unichar_t str_fa77[] = { 0x52fa, 0 };
static const unichar_t str_fa78[] = { 0x559d, 0 };
static const unichar_t str_fa79[] = { 0x5555, 0 };
static const unichar_t str_fa7a[] = { 0x5599, 0 };
static const unichar_t str_fa7b[] = { 0x55e2, 0 };
static const unichar_t str_fa7c[] = { 0x585a, 0 };
static const unichar_t str_fa7d[] = { 0x58b3, 0 };
static const unichar_t str_fa7e[] = { 0x5944, 0 };
static const unichar_t str_fa7f[] = { 0x5954, 0 };
static const unichar_t str_fa80[] = { 0x5a62, 0 };
static const unichar_t str_fa81[] = { 0x5b28, 0 };
static const unichar_t str_fa82[] = { 0x5ed2, 0 };
static const unichar_t str_fa83[] = { 0x5ed9, 0 };
static const unichar_t str_fa84[] = { 0x5f69, 0 };
static const unichar_t str_fa85[] = { 0x5fad, 0 };
static const unichar_t str_fa86[] = { 0x60d8, 0 };
static const unichar_t str_fa87[] = { 0x614e, 0 };
static const unichar_t str_fa88[] = { 0x6108, 0 };
static const unichar_t str_fa89[] = { 0x618e, 0 };
static const unichar_t str_fa8a[] = { 0x6160, 0 };
static const unichar_t str_fa8b[] = { 0x61f2, 0 };
static const unichar_t str_fa8c[] = { 0x6234, 0 };
static const unichar_t str_fa8d[] = { 0x63c4, 0 };
static const unichar_t str_fa8e[] = { 0x641c, 0 };
static const unichar_t str_fa8f[] = { 0x6452, 0 };
static const unichar_t str_fa90[] = { 0x6556, 0 };
static const unichar_t str_fa91[] = { 0x6674, 0 };
static const unichar_t str_fa92[] = { 0x6717, 0 };
static const unichar_t str_fa93[] = { 0x671b, 0 };
static const unichar_t str_fa94[] = { 0x6756, 0 };
static const unichar_t str_fa95[] = { 0x6b79, 0 };
static const unichar_t str_fa96[] = { 0x6bba, 0 };
static const unichar_t str_fa97[] = { 0x6d41, 0 };
static const unichar_t str_fa98[] = { 0x6edb, 0 };
static const unichar_t str_fa99[] = { 0x6ecb, 0 };
static const unichar_t str_fa9a[] = { 0x6f22, 0 };
static const unichar_t str_fa9b[] = { 0x701e, 0 };
static const unichar_t str_fa9c[] = { 0x716e, 0 };
static const unichar_t str_fa9d[] = { 0x77a7, 0 };
static const unichar_t str_fa9e[] = { 0x7235, 0 };
static const unichar_t str_fa9f[] = { 0x72af, 0 };
static const unichar_t str_faa0[] = { 0x732a, 0 };
static const unichar_t str_faa1[] = { 0x7471, 0 };
static const unichar_t str_faa2[] = { 0x7506, 0 };
static const unichar_t str_faa3[] = { 0x753b, 0 };
static const unichar_t str_faa4[] = { 0x761d, 0 };
static const unichar_t str_faa5[] = { 0x761f, 0 };
static const unichar_t str_faa6[] = { 0x76ca, 0 };
static const unichar_t str_faa7[] = { 0x76db, 0 };
static const unichar_t str_faa8[] = { 0x76f4, 0 };
static const unichar_t str_faa9[] = { 0x774a, 0 };
static const unichar_t str_faaa[] = { 0x7740, 0 };
static const unichar_t str_faab[] = { 0x78cc, 0 };
static const unichar_t str_faac[] = { 0x7ab1, 0 };
static const unichar_t str_faad[] = { 0x7bc0, 0 };
static const unichar_t str_faae[] = { 0x7c7b, 0 };
static const unichar_t str_faaf[] = { 0x7d5b, 0 };
static const unichar_t str_fab0[] = { 0x7df4, 0 };
static const unichar_t str_fab1[] = { 0x7f3e, 0 };
static const unichar_t str_fab2[] = { 0x8005, 0 };
static const unichar_t str_fab3[] = { 0x8352, 0 };
static const unichar_t str_fab4[] = { 0x83ef, 0 };
static const unichar_t str_fab5[] = { 0x8779, 0 };
static const unichar_t str_fab6[] = { 0x8941, 0 };
static const unichar_t str_fab7[] = { 0x8986, 0 };
static const unichar_t str_fab8[] = { 0x8996, 0 };
static const unichar_t str_fab9[] = { 0x8abf, 0 };
static const unichar_t str_faba[] = { 0x8af8, 0 };
static const unichar_t str_fabb[] = { 0x8acb, 0 };
static const unichar_t str_fabc[] = { 0x8b01, 0 };
static const unichar_t str_fabd[] = { 0x8afe, 0 };
static const unichar_t str_fabe[] = { 0x8aed, 0 };
static const unichar_t str_fabf[] = { 0x8b39, 0 };
static const unichar_t str_fac0[] = { 0x8b8a, 0 };
static const unichar_t str_fac1[] = { 0x8d08, 0 };
static const unichar_t str_fac2[] = { 0x8f38, 0 };
static const unichar_t str_fac3[] = { 0x9072, 0 };
static const unichar_t str_fac4[] = { 0x9199, 0 };
static const unichar_t str_fac5[] = { 0x9276, 0 };
static const unichar_t str_fac6[] = { 0x967c, 0 };
static const unichar_t str_fac7[] = { 0x96e3, 0 };
static const unichar_t str_fac8[] = { 0x9756, 0 };
static const unichar_t str_fac9[] = { 0x97db, 0 };
static const unichar_t str_faca[] = { 0x97ff, 0 };
static const unichar_t str_facb[] = { 0x980b, 0 };
static const unichar_t str_facc[] = { 0x983b, 0 };
static const unichar_t str_facd[] = { 0x9b12, 0 };
static const unichar_t str_face[] = { 0x9f9c, 0 };
static const unichar_t str_facf[] = { 0x2284a, 0 };
static const unichar_t str_fad0[] = { 0x22844, 0 };
static const unichar_t str_fad1[] = { 0x233d5, 0 };
static const unichar_t str_fad2[] = { 0x3b9d, 0 };
static const unichar_t str_fad3[] = { 0x4018, 0 };
static const unichar_t str_fad4[] = { 0x4039, 0 };
static const unichar_t str_fad5[] = { 0x25249, 0 };
static const unichar_t str_fad6[] = { 0x25cd0, 0 };
static const unichar_t str_fad7[] = { 0x27ed3, 0 };
static const unichar_t str_fad8[] = { 0x9f43, 0 };
static const unichar_t str_fad9[] = { 0x9f8e, 0 };
static const unichar_t str_fb00[] = { 0x0066, 0x0066, 0 };
static const unichar_t str_fb01[] = { 0x0066, 0x0069, 0 };
static const unichar_t str_fb02[] = { 0x0066, 0x006c, 0 };
static const unichar_t str_fb03[] = { 0x0066, 0x0066, 0x0069, 0 };
static const unichar_t str_fb04[] = { 0x0066, 0x0066, 0x006c, 0 };
static const unichar_t str_fb05[] = { 0x017f, 0x0074, 0 };
static const unichar_t str_fb06[] = { 0x0073, 0x0074, 0 };
static const unichar_t str_fb13[] = { 0x0574, 0x0576, 0 };
static const unichar_t str_fb14[] = { 0x0574, 0x0565, 0 };
static const unichar_t str_fb15[] = { 0x0574, 0x056b, 0 };
static const unichar_t str_fb16[] = { 0x057e, 0x0576, 0 };
static const unichar_t str_fb17[] = { 0x0574, 0x056d, 0 };
static const unichar_t str_fb1d[] = { 0x05d9, 0x05b4, 0 };
static const unichar_t str_fb1f[] = { 0x05f2, 0x05b7, 0 };
static const unichar_t str_fb20[] = { 0x05e2, 0 };
static const unichar_t str_fb21[] = { 0x05d0, 0 };
static const unichar_t str_fb22[] = { 0x05d3, 0 };
static const unichar_t str_fb23[] = { 0x05d4, 0 };
static const unichar_t str_fb24[] = { 0x05db, 0 };
static const unichar_t str_fb25[] = { 0x05dc, 0 };
static const unichar_t str_fb26[] = { 0x05dd, 0 };
static const unichar_t str_fb27[] = { 0x05e8, 0 };
static const unichar_t str_fb28[] = { 0x05ea, 0 };
static const unichar_t str_fb29[] = { 0x002b, 0 };
static const unichar_t str_fb2a[] = { 0x05e9, 0x05c1, 0 };
static const unichar_t str_fb2b[] = { 0x05e9, 0x05c2, 0 };
static const unichar_t str_fb2c[] = { 0xfb49, 0x05c1, 0 };
static const unichar_t str_fb2d[] = { 0xfb49, 0x05c2, 0 };
static const unichar_t str_fb2e[] = { 0x05d0, 0x05b7, 0 };
static const unichar_t str_fb2f[] = { 0x05d0, 0x05b8, 0 };
static const unichar_t str_fb30[] = { 0x05d0, 0x05bc, 0 };
static const unichar_t str_fb31[] = { 0x05d1, 0x05bc, 0 };
static const unichar_t str_fb32[] = { 0x05d2, 0x05bc, 0 };
static const unichar_t str_fb33[] = { 0x05d3, 0x05bc, 0 };
static const unichar_t str_fb34[] = { 0x05d4, 0x05bc, 0 };
static const unichar_t str_fb35[] = { 0x05d5, 0x05bc, 0 };
static const unichar_t str_fb36[] = { 0x05d6, 0x05bc, 0 };
static const unichar_t str_fb38[] = { 0x05d8, 0x05bc, 0 };
static const unichar_t str_fb39[] = { 0x05d9, 0x05bc, 0 };
static const unichar_t str_fb3a[] = { 0x05da, 0x05bc, 0 };
static const unichar_t str_fb3b[] = { 0x05db, 0x05bc, 0 };
static const unichar_t str_fb3c[] = { 0x05dc, 0x05bc, 0 };
static const unichar_t str_fb3e[] = { 0x05de, 0x05bc, 0 };
static const unichar_t str_fb40[] = { 0x05e0, 0x05bc, 0 };
static const unichar_t str_fb41[] = { 0x05e1, 0x05bc, 0 };
static const unichar_t str_fb43[] = { 0x05e3, 0x05bc, 0 };
static const unichar_t str_fb44[] = { 0x05e4, 0x05bc, 0 };
static const unichar_t str_fb46[] = { 0x05e6, 0x05bc, 0 };
static const unichar_t str_fb47[] = { 0x05e7, 0x05bc, 0 };
static const unichar_t str_fb48[] = { 0x05e8, 0x05bc, 0 };
static const unichar_t str_fb49[] = { 0x05e9, 0x05bc, 0 };
static const unichar_t str_fb4a[] = { 0x05ea, 0x05bc, 0 };
static const unichar_t str_fb4b[] = { 0x05d5, 0x05b9, 0 };
static const unichar_t str_fb4c[] = { 0x05d1, 0x05bf, 0 };
static const unichar_t str_fb4d[] = { 0x05db, 0x05bf, 0 };
static const unichar_t str_fb4e[] = { 0x05e4, 0x05bf, 0 };
static const unichar_t str_fb4f[] = { 0x05d0, 0x05dc, 0 };
static const unichar_t str_fb50[] = { 0x0671, 0 };
static const unichar_t str_fb51[] = { 0x0671, 0 };
static const unichar_t str_fb52[] = { 0x067b, 0 };
static const unichar_t str_fb53[] = { 0x067b, 0 };
static const unichar_t str_fb54[] = { 0x067b, 0 };
static const unichar_t str_fb55[] = { 0x067b, 0 };
static const unichar_t str_fb56[] = { 0x067e, 0 };
static const unichar_t str_fb57[] = { 0x067e, 0 };
static const unichar_t str_fb58[] = { 0x067e, 0 };
static const unichar_t str_fb59[] = { 0x067e, 0 };
static const unichar_t str_fb5a[] = { 0x0680, 0 };
static const unichar_t str_fb5b[] = { 0x0680, 0 };
static const unichar_t str_fb5c[] = { 0x0680, 0 };
static const unichar_t str_fb5d[] = { 0x0680, 0 };
static const unichar_t str_fb5e[] = { 0x067a, 0 };
static const unichar_t str_fb5f[] = { 0x067a, 0 };
static const unichar_t str_fb60[] = { 0x067a, 0 };
static const unichar_t str_fb61[] = { 0x067a, 0 };
static const unichar_t str_fb62[] = { 0x067f, 0 };
static const unichar_t str_fb63[] = { 0x067f, 0 };
static const unichar_t str_fb64[] = { 0x067f, 0 };
static const unichar_t str_fb65[] = { 0x067f, 0 };
static const unichar_t str_fb66[] = { 0x0679, 0 };
static const unichar_t str_fb67[] = { 0x0679, 0 };
static const unichar_t str_fb68[] = { 0x0679, 0 };
static const unichar_t str_fb69[] = { 0x0679, 0 };
static const unichar_t str_fb6a[] = { 0x06a4, 0 };
static const unichar_t str_fb6b[] = { 0x06a4, 0 };
static const unichar_t str_fb6c[] = { 0x06a4, 0 };
static const unichar_t str_fb6d[] = { 0x06a4, 0 };
static const unichar_t str_fb6e[] = { 0x06a6, 0 };
static const unichar_t str_fb6f[] = { 0x06a6, 0 };
static const unichar_t str_fb70[] = { 0x06a6, 0 };
static const unichar_t str_fb71[] = { 0x06a6, 0 };
static const unichar_t str_fb72[] = { 0x0684, 0 };
static const unichar_t str_fb73[] = { 0x0684, 0 };
static const unichar_t str_fb74[] = { 0x0684, 0 };
static const unichar_t str_fb75[] = { 0x0684, 0 };
static const unichar_t str_fb76[] = { 0x0683, 0 };
static const unichar_t str_fb77[] = { 0x0683, 0 };
static const unichar_t str_fb78[] = { 0x0683, 0 };
static const unichar_t str_fb79[] = { 0x0683, 0 };
static const unichar_t str_fb7a[] = { 0x0686, 0 };
static const unichar_t str_fb7b[] = { 0x0686, 0 };
static const unichar_t str_fb7c[] = { 0x0686, 0 };
static const unichar_t str_fb7d[] = { 0x0686, 0 };
static const unichar_t str_fb7e[] = { 0x0687, 0 };
static const unichar_t str_fb7f[] = { 0x0687, 0 };
static const unichar_t str_fb80[] = { 0x0687, 0 };
static const unichar_t str_fb81[] = { 0x0687, 0 };
static const unichar_t str_fb82[] = { 0x068d, 0 };
static const unichar_t str_fb83[] = { 0x068d, 0 };
static const unichar_t str_fb84[] = { 0x068c, 0 };
static const unichar_t str_fb85[] = { 0x068c, 0 };
static const unichar_t str_fb86[] = { 0x068e, 0 };
static const unichar_t str_fb87[] = { 0x068e, 0 };
static const unichar_t str_fb88[] = { 0x0688, 0 };
static const unichar_t str_fb89[] = { 0x0688, 0 };
static const unichar_t str_fb8a[] = { 0x0698, 0 };
static const unichar_t str_fb8b[] = { 0x0698, 0 };
static const unichar_t str_fb8c[] = { 0x0691, 0 };
static const unichar_t str_fb8d[] = { 0x0691, 0 };
static const unichar_t str_fb8e[] = { 0x06a9, 0 };
static const unichar_t str_fb8f[] = { 0x06a9, 0 };
static const unichar_t str_fb90[] = { 0x06a9, 0 };
static const unichar_t str_fb91[] = { 0x06a9, 0 };
static const unichar_t str_fb92[] = { 0x06af, 0 };
static const unichar_t str_fb93[] = { 0x06af, 0 };
static const unichar_t str_fb94[] = { 0x06af, 0 };
static const unichar_t str_fb95[] = { 0x06af, 0 };
static const unichar_t str_fb96[] = { 0x06b3, 0 };
static const unichar_t str_fb97[] = { 0x06b3, 0 };
static const unichar_t str_fb98[] = { 0x06b3, 0 };
static const unichar_t str_fb99[] = { 0x06b3, 0 };
static const unichar_t str_fb9a[] = { 0x06b1, 0 };
static const unichar_t str_fb9b[] = { 0x06b1, 0 };
static const unichar_t str_fb9c[] = { 0x06b1, 0 };
static const unichar_t str_fb9d[] = { 0x06b1, 0 };
static const unichar_t str_fb9e[] = { 0x06ba, 0 };
static const unichar_t str_fb9f[] = { 0x06ba, 0 };
static const unichar_t str_fba0[] = { 0x06bb, 0 };
static const unichar_t str_fba1[] = { 0x06bb, 0 };
static const unichar_t str_fba2[] = { 0x06bb, 0 };
static const unichar_t str_fba3[] = { 0x06bb, 0 };
static const unichar_t str_fba4[] = { 0x06c0, 0 };
static const unichar_t str_fba5[] = { 0x06c0, 0 };
static const unichar_t str_fba6[] = { 0x06c1, 0 };
static const unichar_t str_fba7[] = { 0x06c1, 0 };
static const unichar_t str_fba8[] = { 0x06c1, 0 };
static const unichar_t str_fba9[] = { 0x06c1, 0 };
static const unichar_t str_fbaa[] = { 0x06be, 0 };
static const unichar_t str_fbab[] = { 0x06be, 0 };
static const unichar_t str_fbac[] = { 0x06be, 0 };
static const unichar_t str_fbad[] = { 0x06be, 0 };
static const unichar_t str_fbae[] = { 0x06d2, 0 };
static const unichar_t str_fbaf[] = { 0x06d2, 0 };
static const unichar_t str_fbb0[] = { 0x06d3, 0 };
static const unichar_t str_fbb1[] = { 0x06d3, 0 };
static const unichar_t str_fbd3[] = { 0x06ad, 0 };
static const unichar_t str_fbd4[] = { 0x06ad, 0 };
static const unichar_t str_fbd5[] = { 0x06ad, 0 };
static const unichar_t str_fbd6[] = { 0x06ad, 0 };
static const unichar_t str_fbd7[] = { 0x06c7, 0 };
static const unichar_t str_fbd8[] = { 0x06c7, 0 };
static const unichar_t str_fbd9[] = { 0x06c6, 0 };
static const unichar_t str_fbda[] = { 0x06c6, 0 };
static const unichar_t str_fbdb[] = { 0x06c8, 0 };
static const unichar_t str_fbdc[] = { 0x06c8, 0 };
static const unichar_t str_fbdd[] = { 0x0677, 0 };
static const unichar_t str_fbde[] = { 0x06cb, 0 };
static const unichar_t str_fbdf[] = { 0x06cb, 0 };
static const unichar_t str_fbe0[] = { 0x06c5, 0 };
static const unichar_t str_fbe1[] = { 0x06c5, 0 };
static const unichar_t str_fbe2[] = { 0x06c9, 0 };
static const unichar_t str_fbe3[] = { 0x06c9, 0 };
static const unichar_t str_fbe4[] = { 0x06d0, 0 };
static const unichar_t str_fbe5[] = { 0x06d0, 0 };
static const unichar_t str_fbe6[] = { 0x06d0, 0 };
static const unichar_t str_fbe7[] = { 0x06d0, 0 };
static const unichar_t str_fbe8[] = { 0x0649, 0 };
static const unichar_t str_fbe9[] = { 0x0649, 0 };
static const unichar_t str_fbea[] = { 0x0626, 0x0627, 0 };
static const unichar_t str_fbeb[] = { 0x0626, 0x0627, 0 };
static const unichar_t str_fbec[] = { 0x0626, 0x06d5, 0 };
static const unichar_t str_fbed[] = { 0x0626, 0x06d5, 0 };
static const unichar_t str_fbee[] = { 0x0626, 0x0648, 0 };
static const unichar_t str_fbef[] = { 0x0626, 0x0648, 0 };
static const unichar_t str_fbf0[] = { 0x0626, 0x06c7, 0 };
static const unichar_t str_fbf1[] = { 0x0626, 0x06c7, 0 };
static const unichar_t str_fbf2[] = { 0x0626, 0x06c6, 0 };
static const unichar_t str_fbf3[] = { 0x0626, 0x06c6, 0 };
static const unichar_t str_fbf4[] = { 0x0626, 0x06c8, 0 };
static const unichar_t str_fbf5[] = { 0x0626, 0x06c8, 0 };
static const unichar_t str_fbf6[] = { 0x0626, 0x06d0, 0 };
static const unichar_t str_fbf7[] = { 0x0626, 0x06d0, 0 };
static const unichar_t str_fbf8[] = { 0x0626, 0x06d0, 0 };
static const unichar_t str_fbf9[] = { 0x0626, 0x0649, 0 };
static const unichar_t str_fbfa[] = { 0x0626, 0x0649, 0 };
static const unichar_t str_fbfb[] = { 0x0626, 0x0649, 0 };
static const unichar_t str_fbfc[] = { 0x06cc, 0 };
static const unichar_t str_fbfd[] = { 0x06cc, 0 };
static const unichar_t str_fbfe[] = { 0x06cc, 0 };
static const unichar_t str_fbff[] = { 0x06cc, 0 };
static const unichar_t str_fc00[] = { 0x0626, 0x062c, 0 };
static const unichar_t str_fc01[] = { 0x0626, 0x062d, 0 };
static const unichar_t str_fc02[] = { 0x0626, 0x0645, 0 };
static const unichar_t str_fc03[] = { 0x0626, 0x0649, 0 };
static const unichar_t str_fc04[] = { 0x0626, 0x064a, 0 };
static const unichar_t str_fc05[] = { 0x0628, 0x062c, 0 };
static const unichar_t str_fc06[] = { 0x0628, 0x062d, 0 };
static const unichar_t str_fc07[] = { 0x0628, 0x062e, 0 };
static const unichar_t str_fc08[] = { 0x0628, 0x0645, 0 };
static const unichar_t str_fc09[] = { 0x0628, 0x0649, 0 };
static const unichar_t str_fc0a[] = { 0x0628, 0x064a, 0 };
static const unichar_t str_fc0b[] = { 0x062a, 0x062c, 0 };
static const unichar_t str_fc0c[] = { 0x062a, 0x062d, 0 };
static const unichar_t str_fc0d[] = { 0x062a, 0x062e, 0 };
static const unichar_t str_fc0e[] = { 0x062a, 0x0645, 0 };
static const unichar_t str_fc0f[] = { 0x062a, 0x0649, 0 };
static const unichar_t str_fc10[] = { 0x062a, 0x064a, 0 };
static const unichar_t str_fc11[] = { 0x062b, 0x062c, 0 };
static const unichar_t str_fc12[] = { 0x062b, 0x0645, 0 };
static const unichar_t str_fc13[] = { 0x062b, 0x0649, 0 };
static const unichar_t str_fc14[] = { 0x062b, 0x064a, 0 };
static const unichar_t str_fc15[] = { 0x062c, 0x062d, 0 };
static const unichar_t str_fc16[] = { 0x062c, 0x0645, 0 };
static const unichar_t str_fc17[] = { 0x062d, 0x062c, 0 };
static const unichar_t str_fc18[] = { 0x062d, 0x0645, 0 };
static const unichar_t str_fc19[] = { 0x062e, 0x062c, 0 };
static const unichar_t str_fc1a[] = { 0x062e, 0x062d, 0 };
static const unichar_t str_fc1b[] = { 0x062e, 0x0645, 0 };
static const unichar_t str_fc1c[] = { 0x0633, 0x062c, 0 };
static const unichar_t str_fc1d[] = { 0x0633, 0x062d, 0 };
static const unichar_t str_fc1e[] = { 0x0633, 0x062e, 0 };
static const unichar_t str_fc1f[] = { 0x0633, 0x0645, 0 };
static const unichar_t str_fc20[] = { 0x0635, 0x062d, 0 };
static const unichar_t str_fc21[] = { 0x0635, 0x0645, 0 };
static const unichar_t str_fc22[] = { 0x0636, 0x062c, 0 };
static const unichar_t str_fc23[] = { 0x0636, 0x062d, 0 };
static const unichar_t str_fc24[] = { 0x0636, 0x062e, 0 };
static const unichar_t str_fc25[] = { 0x0636, 0x0645, 0 };
static const unichar_t str_fc26[] = { 0x0637, 0x062d, 0 };
static const unichar_t str_fc27[] = { 0x0637, 0x0645, 0 };
static const unichar_t str_fc28[] = { 0x0638, 0x0645, 0 };
static const unichar_t str_fc29[] = { 0x0639, 0x062c, 0 };
static const unichar_t str_fc2a[] = { 0x0639, 0x0645, 0 };
static const unichar_t str_fc2b[] = { 0x063a, 0x062c, 0 };
static const unichar_t str_fc2c[] = { 0x063a, 0x0645, 0 };
static const unichar_t str_fc2d[] = { 0x0641, 0x062c, 0 };
static const unichar_t str_fc2e[] = { 0x0641, 0x062d, 0 };
static const unichar_t str_fc2f[] = { 0x0641, 0x062e, 0 };
static const unichar_t str_fc30[] = { 0x0641, 0x0645, 0 };
static const unichar_t str_fc31[] = { 0x0641, 0x0649, 0 };
static const unichar_t str_fc32[] = { 0x0641, 0x064a, 0 };
static const unichar_t str_fc33[] = { 0x0642, 0x062d, 0 };
static const unichar_t str_fc34[] = { 0x0642, 0x0645, 0 };
static const unichar_t str_fc35[] = { 0x0642, 0x0649, 0 };
static const unichar_t str_fc36[] = { 0x0642, 0x064a, 0 };
static const unichar_t str_fc37[] = { 0x0643, 0x0627, 0 };
static const unichar_t str_fc38[] = { 0x0643, 0x062c, 0 };
static const unichar_t str_fc39[] = { 0x0643, 0x062d, 0 };
static const unichar_t str_fc3a[] = { 0x0643, 0x062e, 0 };
static const unichar_t str_fc3b[] = { 0x0643, 0x0644, 0 };
static const unichar_t str_fc3c[] = { 0x0643, 0x0645, 0 };
static const unichar_t str_fc3d[] = { 0x0643, 0x0649, 0 };
static const unichar_t str_fc3e[] = { 0x0643, 0x064a, 0 };
static const unichar_t str_fc3f[] = { 0x0644, 0x062c, 0 };
static const unichar_t str_fc40[] = { 0x0644, 0x062d, 0 };
static const unichar_t str_fc41[] = { 0x0644, 0x062e, 0 };
static const unichar_t str_fc42[] = { 0x0644, 0x0645, 0 };
static const unichar_t str_fc43[] = { 0x0644, 0x0649, 0 };
static const unichar_t str_fc44[] = { 0x0644, 0x064a, 0 };
static const unichar_t str_fc45[] = { 0x0645, 0x062c, 0 };
static const unichar_t str_fc46[] = { 0x0645, 0x062d, 0 };
static const unichar_t str_fc47[] = { 0x0645, 0x062e, 0 };
static const unichar_t str_fc48[] = { 0x0645, 0x0645, 0 };
static const unichar_t str_fc49[] = { 0x0645, 0x0649, 0 };
static const unichar_t str_fc4a[] = { 0x0645, 0x064a, 0 };
static const unichar_t str_fc4b[] = { 0x0646, 0x062c, 0 };
static const unichar_t str_fc4c[] = { 0x0646, 0x062d, 0 };
static const unichar_t str_fc4d[] = { 0x0646, 0x062e, 0 };
static const unichar_t str_fc4e[] = { 0x0646, 0x0645, 0 };
static const unichar_t str_fc4f[] = { 0x0646, 0x0649, 0 };
static const unichar_t str_fc50[] = { 0x0646, 0x064a, 0 };
static const unichar_t str_fc51[] = { 0x0647, 0x062c, 0 };
static const unichar_t str_fc52[] = { 0x0647, 0x0645, 0 };
static const unichar_t str_fc53[] = { 0x0647, 0x0649, 0 };
static const unichar_t str_fc54[] = { 0x0647, 0x064a, 0 };
static const unichar_t str_fc55[] = { 0x064a, 0x062c, 0 };
static const unichar_t str_fc56[] = { 0x064a, 0x062d, 0 };
static const unichar_t str_fc57[] = { 0x064a, 0x062e, 0 };
static const unichar_t str_fc58[] = { 0x064a, 0x0645, 0 };
static const unichar_t str_fc59[] = { 0x064a, 0x0649, 0 };
static const unichar_t str_fc5a[] = { 0x064a, 0x064a, 0 };
static const unichar_t str_fc5b[] = { 0x0630, 0x0670, 0 };
static const unichar_t str_fc5c[] = { 0x0631, 0x0670, 0 };
static const unichar_t str_fc5d[] = { 0x0649, 0x0670, 0 };
static const unichar_t str_fc5e[] = { 0x0020, 0x064c, 0x0651, 0 };
static const unichar_t str_fc5f[] = { 0x0020, 0x064d, 0x0651, 0 };
static const unichar_t str_fc60[] = { 0x0020, 0x064e, 0x0651, 0 };
static const unichar_t str_fc61[] = { 0x0020, 0x064f, 0x0651, 0 };
static const unichar_t str_fc62[] = { 0x0020, 0x0650, 0x0651, 0 };
static const unichar_t str_fc63[] = { 0x0020, 0x0651, 0x0670, 0 };
static const unichar_t str_fc64[] = { 0x0626, 0x0631, 0 };
static const unichar_t str_fc65[] = { 0x0626, 0x0632, 0 };
static const unichar_t str_fc66[] = { 0x0626, 0x0645, 0 };
static const unichar_t str_fc67[] = { 0x0626, 0x0646, 0 };
static const unichar_t str_fc68[] = { 0x0626, 0x0649, 0 };
static const unichar_t str_fc69[] = { 0x0626, 0x064a, 0 };
static const unichar_t str_fc6a[] = { 0x0628, 0x0631, 0 };
static const unichar_t str_fc6b[] = { 0x0628, 0x0632, 0 };
static const unichar_t str_fc6c[] = { 0x0628, 0x0645, 0 };
static const unichar_t str_fc6d[] = { 0x0628, 0x0646, 0 };
static const unichar_t str_fc6e[] = { 0x0628, 0x0649, 0 };
static const unichar_t str_fc6f[] = { 0x0628, 0x064a, 0 };
static const unichar_t str_fc70[] = { 0x062a, 0x0631, 0 };
static const unichar_t str_fc71[] = { 0x062a, 0x0632, 0 };
static const unichar_t str_fc72[] = { 0x062a, 0x0645, 0 };
static const unichar_t str_fc73[] = { 0x062a, 0x0646, 0 };
static const unichar_t str_fc74[] = { 0x062a, 0x0649, 0 };
static const unichar_t str_fc75[] = { 0x062a, 0x064a, 0 };
static const unichar_t str_fc76[] = { 0x062b, 0x0631, 0 };
static const unichar_t str_fc77[] = { 0x062b, 0x0632, 0 };
static const unichar_t str_fc78[] = { 0x062b, 0x0645, 0 };
static const unichar_t str_fc79[] = { 0x062b, 0x0646, 0 };
static const unichar_t str_fc7a[] = { 0x062b, 0x0649, 0 };
static const unichar_t str_fc7b[] = { 0x062b, 0x064a, 0 };
static const unichar_t str_fc7c[] = { 0x0641, 0x0649, 0 };
static const unichar_t str_fc7d[] = { 0x0641, 0x064a, 0 };
static const unichar_t str_fc7e[] = { 0x0642, 0x0649, 0 };
static const unichar_t str_fc7f[] = { 0x0642, 0x064a, 0 };
static const unichar_t str_fc80[] = { 0x0643, 0x0627, 0 };
static const unichar_t str_fc81[] = { 0x0643, 0x0644, 0 };
static const unichar_t str_fc82[] = { 0x0643, 0x0645, 0 };
static const unichar_t str_fc83[] = { 0x0643, 0x0649, 0 };
static const unichar_t str_fc84[] = { 0x0643, 0x064a, 0 };
static const unichar_t str_fc85[] = { 0x0644, 0x0645, 0 };
static const unichar_t str_fc86[] = { 0x0644, 0x0649, 0 };
static const unichar_t str_fc87[] = { 0x0644, 0x064a, 0 };
static const unichar_t str_fc88[] = { 0x0645, 0x0627, 0 };
static const unichar_t str_fc89[] = { 0x0645, 0x0645, 0 };
static const unichar_t str_fc8a[] = { 0x0646, 0x0631, 0 };
static const unichar_t str_fc8b[] = { 0x0646, 0x0632, 0 };
static const unichar_t str_fc8c[] = { 0x0646, 0x0645, 0 };
static const unichar_t str_fc8d[] = { 0x0646, 0x0646, 0 };
static const unichar_t str_fc8e[] = { 0x0646, 0x0649, 0 };
static const unichar_t str_fc8f[] = { 0x0646, 0x064a, 0 };
static const unichar_t str_fc90[] = { 0x0649, 0x0670, 0 };
static const unichar_t str_fc91[] = { 0x064a, 0x0631, 0 };
static const unichar_t str_fc92[] = { 0x064a, 0x0632, 0 };
static const unichar_t str_fc93[] = { 0x064a, 0x0645, 0 };
static const unichar_t str_fc94[] = { 0x064a, 0x0646, 0 };
static const unichar_t str_fc95[] = { 0x064a, 0x0649, 0 };
static const unichar_t str_fc96[] = { 0x064a, 0x064a, 0 };
static const unichar_t str_fc97[] = { 0x0626, 0x062c, 0 };
static const unichar_t str_fc98[] = { 0x0626, 0x062d, 0 };
static const unichar_t str_fc99[] = { 0x0626, 0x062e, 0 };
static const unichar_t str_fc9a[] = { 0x0626, 0x0645, 0 };
static const unichar_t str_fc9b[] = { 0x0626, 0x0647, 0 };
static const unichar_t str_fc9c[] = { 0x0628, 0x062c, 0 };
static const unichar_t str_fc9d[] = { 0x0628, 0x062d, 0 };
static const unichar_t str_fc9e[] = { 0x0628, 0x062e, 0 };
static const unichar_t str_fc9f[] = { 0x0628, 0x0645, 0 };
static const unichar_t str_fca0[] = { 0x0628, 0x0647, 0 };
static const unichar_t str_fca1[] = { 0x062a, 0x062c, 0 };
static const unichar_t str_fca2[] = { 0x062a, 0x062d, 0 };
static const unichar_t str_fca3[] = { 0x062a, 0x062e, 0 };
static const unichar_t str_fca4[] = { 0x062a, 0x0645, 0 };
static const unichar_t str_fca5[] = { 0x062a, 0x0647, 0 };
static const unichar_t str_fca6[] = { 0x062b, 0x0645, 0 };
static const unichar_t str_fca7[] = { 0x062c, 0x062d, 0 };
static const unichar_t str_fca8[] = { 0x062c, 0x0645, 0 };
static const unichar_t str_fca9[] = { 0x062d, 0x062c, 0 };
static const unichar_t str_fcaa[] = { 0x062d, 0x0645, 0 };
static const unichar_t str_fcab[] = { 0x062e, 0x062c, 0 };
static const unichar_t str_fcac[] = { 0x062e, 0x0645, 0 };
static const unichar_t str_fcad[] = { 0x0633, 0x062c, 0 };
static const unichar_t str_fcae[] = { 0x0633, 0x062d, 0 };
static const unichar_t str_fcaf[] = { 0x0633, 0x062e, 0 };
static const unichar_t str_fcb0[] = { 0x0633, 0x0645, 0 };
static const unichar_t str_fcb1[] = { 0x0635, 0x062d, 0 };
static const unichar_t str_fcb2[] = { 0x0635, 0x062e, 0 };
static const unichar_t str_fcb3[] = { 0x0635, 0x0645, 0 };
static const unichar_t str_fcb4[] = { 0x0636, 0x062c, 0 };
static const unichar_t str_fcb5[] = { 0x0636, 0x062d, 0 };
static const unichar_t str_fcb6[] = { 0x0636, 0x062e, 0 };
static const unichar_t str_fcb7[] = { 0x0636, 0x0645, 0 };
static const unichar_t str_fcb8[] = { 0x0637, 0x062d, 0 };
static const unichar_t str_fcb9[] = { 0x0638, 0x0645, 0 };
static const unichar_t str_fcba[] = { 0x0639, 0x062c, 0 };
static const unichar_t str_fcbb[] = { 0x0639, 0x0645, 0 };
static const unichar_t str_fcbc[] = { 0x063a, 0x062c, 0 };
static const unichar_t str_fcbd[] = { 0x063a, 0x0645, 0 };
static const unichar_t str_fcbe[] = { 0x0641, 0x062c, 0 };
static const unichar_t str_fcbf[] = { 0x0641, 0x062d, 0 };
static const unichar_t str_fcc0[] = { 0x0641, 0x062e, 0 };
static const unichar_t str_fcc1[] = { 0x0641, 0x0645, 0 };
static const unichar_t str_fcc2[] = { 0x0642, 0x062d, 0 };
static const unichar_t str_fcc3[] = { 0x0642, 0x0645, 0 };
static const unichar_t str_fcc4[] = { 0x0643, 0x062c, 0 };
static const unichar_t str_fcc5[] = { 0x0643, 0x062d, 0 };
static const unichar_t str_fcc6[] = { 0x0643, 0x062e, 0 };
static const unichar_t str_fcc7[] = { 0x0643, 0x0644, 0 };
static const unichar_t str_fcc8[] = { 0x0643, 0x0645, 0 };
static const unichar_t str_fcc9[] = { 0x0644, 0x062c, 0 };
static const unichar_t str_fcca[] = { 0x0644, 0x062d, 0 };
static const unichar_t str_fccb[] = { 0x0644, 0x062e, 0 };
static const unichar_t str_fccc[] = { 0x0644, 0x0645, 0 };
static const unichar_t str_fccd[] = { 0x0644, 0x0647, 0 };
static const unichar_t str_fcce[] = { 0x0645, 0x062c, 0 };
static const unichar_t str_fccf[] = { 0x0645, 0x062d, 0 };
static const unichar_t str_fcd0[] = { 0x0645, 0x062e, 0 };
static const unichar_t str_fcd1[] = { 0x0645, 0x0645, 0 };
static const unichar_t str_fcd2[] = { 0x0646, 0x062c, 0 };
static const unichar_t str_fcd3[] = { 0x0646, 0x062d, 0 };
static const unichar_t str_fcd4[] = { 0x0646, 0x062e, 0 };
static const unichar_t str_fcd5[] = { 0x0646, 0x0645, 0 };
static const unichar_t str_fcd6[] = { 0x0646, 0x0647, 0 };
static const unichar_t str_fcd7[] = { 0x0647, 0x062c, 0 };
static const unichar_t str_fcd8[] = { 0x0647, 0x0645, 0 };
static const unichar_t str_fcd9[] = { 0x0647, 0x0670, 0 };
static const unichar_t str_fcda[] = { 0x064a, 0x062c, 0 };
static const unichar_t str_fcdb[] = { 0x064a, 0x062d, 0 };
static const unichar_t str_fcdc[] = { 0x064a, 0x062e, 0 };
static const unichar_t str_fcdd[] = { 0x064a, 0x0645, 0 };
static const unichar_t str_fcde[] = { 0x064a, 0x0647, 0 };
static const unichar_t str_fcdf[] = { 0x0626, 0x0645, 0 };
static const unichar_t str_fce0[] = { 0x0626, 0x0647, 0 };
static const unichar_t str_fce1[] = { 0x0628, 0x0645, 0 };
static const unichar_t str_fce2[] = { 0x0628, 0x0647, 0 };
static const unichar_t str_fce3[] = { 0x062a, 0x0645, 0 };
static const unichar_t str_fce4[] = { 0x062a, 0x0647, 0 };
static const unichar_t str_fce5[] = { 0x062b, 0x0645, 0 };
static const unichar_t str_fce6[] = { 0x062b, 0x0647, 0 };
static const unichar_t str_fce7[] = { 0x0633, 0x0645, 0 };
static const unichar_t str_fce8[] = { 0x0633, 0x0647, 0 };
static const unichar_t str_fce9[] = { 0x0634, 0x0645, 0 };
static const unichar_t str_fcea[] = { 0x0634, 0x0647, 0 };
static const unichar_t str_fceb[] = { 0x0643, 0x0644, 0 };
static const unichar_t str_fcec[] = { 0x0643, 0x0645, 0 };
static const unichar_t str_fced[] = { 0x0644, 0x0645, 0 };
static const unichar_t str_fcee[] = { 0x0646, 0x0645, 0 };
static const unichar_t str_fcef[] = { 0x0646, 0x0647, 0 };
static const unichar_t str_fcf0[] = { 0x064a, 0x0645, 0 };
static const unichar_t str_fcf1[] = { 0x064a, 0x0647, 0 };
static const unichar_t str_fcf2[] = { 0x0640, 0x064e, 0x0651, 0 };
static const unichar_t str_fcf3[] = { 0x0640, 0x064f, 0x0651, 0 };
static const unichar_t str_fcf4[] = { 0x0640, 0x0650, 0x0651, 0 };
static const unichar_t str_fcf5[] = { 0x0637, 0x0649, 0 };
static const unichar_t str_fcf6[] = { 0x0637, 0x064a, 0 };
static const unichar_t str_fcf7[] = { 0x0639, 0x0649, 0 };
static const unichar_t str_fcf8[] = { 0x0639, 0x064a, 0 };
static const unichar_t str_fcf9[] = { 0x063a, 0x0649, 0 };
static const unichar_t str_fcfa[] = { 0x063a, 0x064a, 0 };
static const unichar_t str_fcfb[] = { 0x0633, 0x0649, 0 };
static const unichar_t str_fcfc[] = { 0x0633, 0x064a, 0 };
static const unichar_t str_fcfd[] = { 0x0634, 0x0649, 0 };
static const unichar_t str_fcfe[] = { 0x0634, 0x064a, 0 };
static const unichar_t str_fcff[] = { 0x062d, 0x0649, 0 };
static const unichar_t str_fd00[] = { 0x062d, 0x064a, 0 };
static const unichar_t str_fd01[] = { 0x062c, 0x0649, 0 };
static const unichar_t str_fd02[] = { 0x062c, 0x064a, 0 };
static const unichar_t str_fd03[] = { 0x062e, 0x0649, 0 };
static const unichar_t str_fd04[] = { 0x062e, 0x064a, 0 };
static const unichar_t str_fd05[] = { 0x0635, 0x0649, 0 };
static const unichar_t str_fd06[] = { 0x0635, 0x064a, 0 };
static const unichar_t str_fd07[] = { 0x0636, 0x0649, 0 };
static const unichar_t str_fd08[] = { 0x0636, 0x064a, 0 };
static const unichar_t str_fd09[] = { 0x0634, 0x062c, 0 };
static const unichar_t str_fd0a[] = { 0x0634, 0x062d, 0 };
static const unichar_t str_fd0b[] = { 0x0634, 0x062e, 0 };
static const unichar_t str_fd0c[] = { 0x0634, 0x0645, 0 };
static const unichar_t str_fd0d[] = { 0x0634, 0x0631, 0 };
static const unichar_t str_fd0e[] = { 0x0633, 0x0631, 0 };
static const unichar_t str_fd0f[] = { 0x0635, 0x0631, 0 };
static const unichar_t str_fd10[] = { 0x0636, 0x0631, 0 };
static const unichar_t str_fd11[] = { 0x0637, 0x0649, 0 };
static const unichar_t str_fd12[] = { 0x0637, 0x064a, 0 };
static const unichar_t str_fd13[] = { 0x0639, 0x0649, 0 };
static const unichar_t str_fd14[] = { 0x0639, 0x064a, 0 };
static const unichar_t str_fd15[] = { 0x063a, 0x0649, 0 };
static const unichar_t str_fd16[] = { 0x063a, 0x064a, 0 };
static const unichar_t str_fd17[] = { 0x0633, 0x0649, 0 };
static const unichar_t str_fd18[] = { 0x0633, 0x064a, 0 };
static const unichar_t str_fd19[] = { 0x0634, 0x0649, 0 };
static const unichar_t str_fd1a[] = { 0x0634, 0x064a, 0 };
static const unichar_t str_fd1b[] = { 0x062d, 0x0649, 0 };
static const unichar_t str_fd1c[] = { 0x062d, 0x064a, 0 };
static const unichar_t str_fd1d[] = { 0x062c, 0x0649, 0 };
static const unichar_t str_fd1e[] = { 0x062c, 0x064a, 0 };
static const unichar_t str_fd1f[] = { 0x062e, 0x0649, 0 };
static const unichar_t str_fd20[] = { 0x062e, 0x064a, 0 };
static const unichar_t str_fd21[] = { 0x0635, 0x0649, 0 };
static const unichar_t str_fd22[] = { 0x0635, 0x064a, 0 };
static const unichar_t str_fd23[] = { 0x0636, 0x0649, 0 };
static const unichar_t str_fd24[] = { 0x0636, 0x064a, 0 };
static const unichar_t str_fd25[] = { 0x0634, 0x062c, 0 };
static const unichar_t str_fd26[] = { 0x0634, 0x062d, 0 };
static const unichar_t str_fd27[] = { 0x0634, 0x062e, 0 };
static const unichar_t str_fd28[] = { 0x0634, 0x0645, 0 };
static const unichar_t str_fd29[] = { 0x0634, 0x0631, 0 };
static const unichar_t str_fd2a[] = { 0x0633, 0x0631, 0 };
static const unichar_t str_fd2b[] = { 0x0635, 0x0631, 0 };
static const unichar_t str_fd2c[] = { 0x0636, 0x0631, 0 };
static const unichar_t str_fd2d[] = { 0x0634, 0x062c, 0 };
static const unichar_t str_fd2e[] = { 0x0634, 0x062d, 0 };
static const unichar_t str_fd2f[] = { 0x0634, 0x062e, 0 };
static const unichar_t str_fd30[] = { 0x0634, 0x0645, 0 };
static const unichar_t str_fd31[] = { 0x0633, 0x0647, 0 };
static const unichar_t str_fd32[] = { 0x0634, 0x0647, 0 };
static const unichar_t str_fd33[] = { 0x0637, 0x0645, 0 };
static const unichar_t str_fd34[] = { 0x0633, 0x062c, 0 };
static const unichar_t str_fd35[] = { 0x0633, 0x062d, 0 };
static const unichar_t str_fd36[] = { 0x0633, 0x062e, 0 };
static const unichar_t str_fd37[] = { 0x0634, 0x062c, 0 };
static const unichar_t str_fd38[] = { 0x0634, 0x062d, 0 };
static const unichar_t str_fd39[] = { 0x0634, 0x062e, 0 };
static const unichar_t str_fd3a[] = { 0x0637, 0x0645, 0 };
static const unichar_t str_fd3b[] = { 0x0638, 0x0645, 0 };
static const unichar_t str_fd3c[] = { 0x0627, 0x064b, 0 };
static const unichar_t str_fd3d[] = { 0x0627, 0x064b, 0 };
static const unichar_t str_fd50[] = { 0x062a, 0x062c, 0x0645, 0 };
static const unichar_t str_fd51[] = { 0x062a, 0x062d, 0x062c, 0 };
static const unichar_t str_fd52[] = { 0x062a, 0x062d, 0x062c, 0 };
static const unichar_t str_fd53[] = { 0x062a, 0x062d, 0x0645, 0 };
static const unichar_t str_fd54[] = { 0x062a, 0x062e, 0x0645, 0 };
static const unichar_t str_fd55[] = { 0x062a, 0x0645, 0x062c, 0 };
static const unichar_t str_fd56[] = { 0x062a, 0x0645, 0x062d, 0 };
static const unichar_t str_fd57[] = { 0x062a, 0x0645, 0x062e, 0 };
static const unichar_t str_fd58[] = { 0x062c, 0x0645, 0x062d, 0 };
static const unichar_t str_fd59[] = { 0x062c, 0x0645, 0x062d, 0 };
static const unichar_t str_fd5a[] = { 0x062d, 0x0645, 0x064a, 0 };
static const unichar_t str_fd5b[] = { 0x062d, 0x0645, 0x0649, 0 };
static const unichar_t str_fd5c[] = { 0x0633, 0x062d, 0x062c, 0 };
static const unichar_t str_fd5d[] = { 0x0633, 0x062c, 0x062d, 0 };
static const unichar_t str_fd5e[] = { 0x0633, 0x062c, 0x0649, 0 };
static const unichar_t str_fd5f[] = { 0x0633, 0x0645, 0x062d, 0 };
static const unichar_t str_fd60[] = { 0x0633, 0x0645, 0x062d, 0 };
static const unichar_t str_fd61[] = { 0x0633, 0x0645, 0x062c, 0 };
static const unichar_t str_fd62[] = { 0x0633, 0x0645, 0x0645, 0 };
static const unichar_t str_fd63[] = { 0x0633, 0x0645, 0x0645, 0 };
static const unichar_t str_fd64[] = { 0x0635, 0x062d, 0x062d, 0 };
static const unichar_t str_fd65[] = { 0x0635, 0x062d, 0x062d, 0 };
static const unichar_t str_fd66[] = { 0x0635, 0x0645, 0x0645, 0 };
static const unichar_t str_fd67[] = { 0x0634, 0x062d, 0x0645, 0 };
static const unichar_t str_fd68[] = { 0x0634, 0x062d, 0x0645, 0 };
static const unichar_t str_fd69[] = { 0x0634, 0x062c, 0x064a, 0 };
static const unichar_t str_fd6a[] = { 0x0634, 0x0645, 0x062e, 0 };
static const unichar_t str_fd6b[] = { 0x0634, 0x0645, 0x062e, 0 };
static const unichar_t str_fd6c[] = { 0x0634, 0x0645, 0x0645, 0 };
static const unichar_t str_fd6d[] = { 0x0634, 0x0645, 0x0645, 0 };
static const unichar_t str_fd6e[] = { 0x0636, 0x062d, 0x0649, 0 };
static const unichar_t str_fd6f[] = { 0x0636, 0x062e, 0x0645, 0 };
static const unichar_t str_fd70[] = { 0x0636, 0x062e, 0x0645, 0 };
static const unichar_t str_fd71[] = { 0x0637, 0x0645, 0x062d, 0 };
static const unichar_t str_fd72[] = { 0x0637, 0x0645, 0x062d, 0 };
static const unichar_t str_fd73[] = { 0x0637, 0x0645, 0x0645, 0 };
static const unichar_t str_fd74[] = { 0x0637, 0x0645, 0x064a, 0 };
static const unichar_t str_fd75[] = { 0x0639, 0x062c, 0x0645, 0 };
static const unichar_t str_fd76[] = { 0x0639, 0x0645, 0x0645, 0 };
static const unichar_t str_fd77[] = { 0x0639, 0x0645, 0x0645, 0 };
static const unichar_t str_fd78[] = { 0x0639, 0x0645, 0x0649, 0 };
static const unichar_t str_fd79[] = { 0x063a, 0x0645, 0x0645, 0 };
static const unichar_t str_fd7a[] = { 0x063a, 0x0645, 0x064a, 0 };
static const unichar_t str_fd7b[] = { 0x063a, 0x0645, 0x0649, 0 };
static const unichar_t str_fd7c[] = { 0x0641, 0x062e, 0x0645, 0 };
static const unichar_t str_fd7d[] = { 0x0641, 0x062e, 0x0645, 0 };
static const unichar_t str_fd7e[] = { 0x0642, 0x0645, 0x062d, 0 };
static const unichar_t str_fd7f[] = { 0x0642, 0x0645, 0x0645, 0 };
static const unichar_t str_fd80[] = { 0x0644, 0x062d, 0x0645, 0 };
static const unichar_t str_fd81[] = { 0x0644, 0x062d, 0x064a, 0 };
static const unichar_t str_fd82[] = { 0x0644, 0x062d, 0x0649, 0 };
static const unichar_t str_fd83[] = { 0x0644, 0x062c, 0x062c, 0 };
static const unichar_t str_fd84[] = { 0x0644, 0x062c, 0x062c, 0 };
static const unichar_t str_fd85[] = { 0x0644, 0x062e, 0x0645, 0 };
static const unichar_t str_fd86[] = { 0x0644, 0x062e, 0x0645, 0 };
static const unichar_t str_fd87[] = { 0x0644, 0x0645, 0x062d, 0 };
static const unichar_t str_fd88[] = { 0x0644, 0x0645, 0x062d, 0 };
static const unichar_t str_fd89[] = { 0x0645, 0x062d, 0x062c, 0 };
static const unichar_t str_fd8a[] = { 0x0645, 0x062d, 0x0645, 0 };
static const unichar_t str_fd8b[] = { 0x0645, 0x062d, 0x064a, 0 };
static const unichar_t str_fd8c[] = { 0x0645, 0x062c, 0x062d, 0 };
static const unichar_t str_fd8d[] = { 0x0645, 0x062c, 0x0645, 0 };
static const unichar_t str_fd8e[] = { 0x0645, 0x062e, 0x062c, 0 };
static const unichar_t str_fd8f[] = { 0x0645, 0x062e, 0x0645, 0 };
static const unichar_t str_fd92[] = { 0x0645, 0x062c, 0x062e, 0 };
static const unichar_t str_fd93[] = { 0x0647, 0x0645, 0x062c, 0 };
static const unichar_t str_fd94[] = { 0x0647, 0x0645, 0x0645, 0 };
static const unichar_t str_fd95[] = { 0x0646, 0x062d, 0x0645, 0 };
static const unichar_t str_fd96[] = { 0x0646, 0x062d, 0x0649, 0 };
static const unichar_t str_fd97[] = { 0x0646, 0x062c, 0x0645, 0 };
static const unichar_t str_fd98[] = { 0x0646, 0x062c, 0x0645, 0 };
static const unichar_t str_fd99[] = { 0x0646, 0x062c, 0x0649, 0 };
static const unichar_t str_fd9a[] = { 0x0646, 0x0645, 0x064a, 0 };
static const unichar_t str_fd9b[] = { 0x0646, 0x0645, 0x0649, 0 };
static const unichar_t str_fd9c[] = { 0x064a, 0x0645, 0x0645, 0 };
static const unichar_t str_fd9d[] = { 0x064a, 0x0645, 0x0645, 0 };
static const unichar_t str_fd9e[] = { 0x0628, 0x062e, 0x064a, 0 };
static const unichar_t str_fd9f[] = { 0x062a, 0x062c, 0x064a, 0 };
static const unichar_t str_fda0[] = { 0x062a, 0x062c, 0x0649, 0 };
static const unichar_t str_fda1[] = { 0x062a, 0x062e, 0x064a, 0 };
static const unichar_t str_fda2[] = { 0x062a, 0x062e, 0x0649, 0 };
static const unichar_t str_fda3[] = { 0x062a, 0x0645, 0x064a, 0 };
static const unichar_t str_fda4[] = { 0x062a, 0x0645, 0x0649, 0 };
static const unichar_t str_fda5[] = { 0x062c, 0x0645, 0x064a, 0 };
static const unichar_t str_fda6[] = { 0x062c, 0x062d, 0x0649, 0 };
static const unichar_t str_fda7[] = { 0x062c, 0x0645, 0x0649, 0 };
static const unichar_t str_fda8[] = { 0x0633, 0x062e, 0x0649, 0 };
static const unichar_t str_fda9[] = { 0x0635, 0x062d, 0x064a, 0 };
static const unichar_t str_fdaa[] = { 0x0634, 0x062d, 0x064a, 0 };
static const unichar_t str_fdab[] = { 0x0636, 0x062d, 0x064a, 0 };
static const unichar_t str_fdac[] = { 0x0644, 0x062c, 0x064a, 0 };
static const unichar_t str_fdad[] = { 0x0644, 0x0645, 0x064a, 0 };
static const unichar_t str_fdae[] = { 0x064a, 0x062d, 0x064a, 0 };
static const unichar_t str_fdaf[] = { 0x064a, 0x062c, 0x064a, 0 };
static const unichar_t str_fdb0[] = { 0x064a, 0x0645, 0x064a, 0 };
static const unichar_t str_fdb1[] = { 0x0645, 0x0645, 0x064a, 0 };
static const unichar_t str_fdb2[] = { 0x0642, 0x0645, 0x064a, 0 };
static const unichar_t str_fdb3[] = { 0x0646, 0x062d, 0x064a, 0 };
static const unichar_t str_fdb4[] = { 0x0642, 0x0645, 0x062d, 0 };
static const unichar_t str_fdb5[] = { 0x0644, 0x062d, 0x0645, 0 };
static const unichar_t str_fdb6[] = { 0x0639, 0x0645, 0x064a, 0 };
static const unichar_t str_fdb7[] = { 0x0643, 0x0645, 0x064a, 0 };
static const unichar_t str_fdb8[] = { 0x0646, 0x062c, 0x062d, 0 };
static const unichar_t str_fdb9[] = { 0x0645, 0x062e, 0x064a, 0 };
static const unichar_t str_fdba[] = { 0x0644, 0x062c, 0x0645, 0 };
static const unichar_t str_fdbb[] = { 0x0643, 0x0645, 0x0645, 0 };
static const unichar_t str_fdbc[] = { 0x0644, 0x062c, 0x0645, 0 };
static const unichar_t str_fdbd[] = { 0x0646, 0x062c, 0x062d, 0 };
static const unichar_t str_fdbe[] = { 0x062c, 0x062d, 0x064a, 0 };
static const unichar_t str_fdbf[] = { 0x062d, 0x062c, 0x064a, 0 };
static const unichar_t str_fdc0[] = { 0x0645, 0x062c, 0x064a, 0 };
static const unichar_t str_fdc1[] = { 0x0641, 0x0645, 0x064a, 0 };
static const unichar_t str_fdc2[] = { 0x0628, 0x062d, 0x064a, 0 };
static const unichar_t str_fdc3[] = { 0x0643, 0x0645, 0x0645, 0 };
static const unichar_t str_fdc4[] = { 0x0639, 0x062c, 0x0645, 0 };
static const unichar_t str_fdc5[] = { 0x0635, 0x0645, 0x0645, 0 };
static const unichar_t str_fdc6[] = { 0x0633, 0x062e, 0x064a, 0 };
static const unichar_t str_fdc7[] = { 0x0646, 0x062c, 0x064a, 0 };
static const unichar_t str_fdf0[] = { 0x0635, 0x0644, 0x06d2, 0 };
static const unichar_t str_fdf1[] = { 0x0642, 0x0644, 0x06d2, 0 };
static const unichar_t str_fdf2[] = { 0x0627, 0x0644, 0x0644, 0x0647, 0 };
static const unichar_t str_fdf3[] = { 0x0627, 0x0643, 0x0628, 0x0631, 0 };
static const unichar_t str_fdf4[] = { 0x0645, 0x062d, 0x0645, 0x062f, 0 };
static const unichar_t str_fdf5[] = { 0x0635, 0x0644, 0x0639, 0x0645, 0 };
static const unichar_t str_fdf6[] = { 0x0631, 0x0633, 0x0648, 0x0644, 0 };
static const unichar_t str_fdf7[] = { 0x0639, 0x0644, 0x064a, 0x0647, 0 };
static const unichar_t str_fdf8[] = { 0x0648, 0x0633, 0x0644, 0x0645, 0 };
static const unichar_t str_fdf9[] = { 0x0635, 0x0644, 0x0649, 0 };
static const unichar_t str_fdfa[] = { 0x0635, 0x0644, 0x0649, 0x0020, 0x0627, 0x0644, 0x0644, 0x0647, 0x0020, 0x0639, 0x0644, 0x064a, 0x0647, 0x0020, 0x0648, 0x0633, 0x0644, 0x0645, 0 };
static const unichar_t str_fdfb[] = { 0x062c, 0x0644, 0x0020, 0x062c, 0x0644, 0x0627, 0x0644, 0x0647, 0 };
static const unichar_t str_fdfc[] = { 0x0631, 0x06cc, 0x0627, 0x0644, 0 };
static const unichar_t str_fe10[] = { 0x002c, 0 };
static const unichar_t str_fe11[] = { 0x3001, 0 };
static const unichar_t str_fe12[] = { 0x3002, 0 };
static const unichar_t str_fe13[] = { 0x003a, 0 };
static const unichar_t str_fe14[] = { 0x003b, 0 };
static const unichar_t str_fe15[] = { 0x0021, 0 };
static const unichar_t str_fe16[] = { 0x003f, 0 };
static const unichar_t str_fe17[] = { 0x3016, 0 };
static const unichar_t str_fe18[] = { 0x3017, 0 };
static const unichar_t str_fe19[] = { 0x2026, 0 };
static const unichar_t str_fe30[] = { 0x2025, 0 };
static const unichar_t str_fe31[] = { 0x2014, 0 };
static const unichar_t str_fe32[] = { 0x2013, 0 };
static const unichar_t str_fe33[] = { 0x005f, 0 };
static const unichar_t str_fe34[] = { 0x005f, 0 };
static const unichar_t str_fe35[] = { 0x0028, 0 };
static const unichar_t str_fe36[] = { 0x0029, 0 };
static const unichar_t str_fe37[] = { 0x007b, 0 };
static const unichar_t str_fe38[] = { 0x007d, 0 };
static const unichar_t str_fe39[] = { 0x3014, 0 };
static const unichar_t str_fe3a[] = { 0x3015, 0 };
static const unichar_t str_fe3b[] = { 0x3010, 0 };
static const unichar_t str_fe3c[] = { 0x3011, 0 };
static const unichar_t str_fe3d[] = { 0x300a, 0 };
static const unichar_t str_fe3e[] = { 0x300b, 0 };
static const unichar_t str_fe3f[] = { 0x3008, 0 };
static const unichar_t str_fe40[] = { 0x3009, 0 };
static const unichar_t str_fe41[] = { 0x300c, 0 };
static const unichar_t str_fe42[] = { 0x300d, 0 };
static const unichar_t str_fe43[] = { 0x300e, 0 };
static const unichar_t str_fe44[] = { 0x300f, 0 };
static const unichar_t str_fe47[] = { 0x005b, 0 };
static const unichar_t str_fe48[] = { 0x005d, 0 };
static const unichar_t str_fe49[] = { 0x203e, 0 };
static const unichar_t str_fe4a[] = { 0x203e, 0 };
static const unichar_t str_fe4b[] = { 0x203e, 0 };
static const unichar_t str_fe4c[] = { 0x203e, 0 };
static const unichar_t str_fe4d[] = { 0x005f, 0 };
static const unichar_t str_fe4e[] = { 0x005f, 0 };
static const unichar_t str_fe4f[] = { 0x005f, 0 };
static const unichar_t str_fe50[] = { 0x002c, 0 };
static const unichar_t str_fe51[] = { 0x3001, 0 };
static const unichar_t str_fe52[] = { 0x002e, 0 };
static const unichar_t str_fe54[] = { 0x003b, 0 };
static const unichar_t str_fe55[] = { 0x003a, 0 };
static const unichar_t str_fe56[] = { 0x003f, 0 };
static const unichar_t str_fe57[] = { 0x0021, 0 };
static const unichar_t str_fe58[] = { 0x2014, 0 };
static const unichar_t str_fe59[] = { 0x0028, 0 };
static const unichar_t str_fe5a[] = { 0x0029, 0 };
static const unichar_t str_fe5b[] = { 0x007b, 0 };
static const unichar_t str_fe5c[] = { 0x007d, 0 };
static const unichar_t str_fe5d[] = { 0x3014, 0 };
static const unichar_t str_fe5e[] = { 0x3015, 0 };
static const unichar_t str_fe5f[] = { 0x0023, 0 };
static const unichar_t str_fe60[] = { 0x0026, 0 };
static const unichar_t str_fe61[] = { 0x002a, 0 };
static const unichar_t str_fe62[] = { 0x002b, 0 };
static const unichar_t str_fe63[] = { 0x002d, 0 };
static const unichar_t str_fe64[] = { 0x003c, 0 };
static const unichar_t str_fe65[] = { 0x003e, 0 };
static const unichar_t str_fe66[] = { 0x003d, 0 };
static const unichar_t str_fe68[] = { 0x005c, 0 };
static const unichar_t str_fe69[] = { 0x0024, 0 };
static const unichar_t str_fe6a[] = { 0x0025, 0 };
static const unichar_t str_fe6b[] = { 0x0040, 0 };
static const unichar_t str_fe70[] = { 0x0020, 0x064b, 0 };
static const unichar_t str_fe71[] = { 0x0640, 0x064b, 0 };
static const unichar_t str_fe72[] = { 0x0020, 0x064c, 0 };
static const unichar_t str_fe74[] = { 0x0020, 0x064d, 0 };
static const unichar_t str_fe76[] = { 0x0020, 0x064e, 0 };
static const unichar_t str_fe77[] = { 0x0640, 0x064e, 0 };
static const unichar_t str_fe78[] = { 0x0020, 0x064f, 0 };
static const unichar_t str_fe79[] = { 0x0640, 0x064f, 0 };
static const unichar_t str_fe7a[] = { 0x0020, 0x0650, 0 };
static const unichar_t str_fe7b[] = { 0x0640, 0x0650, 0 };
static const unichar_t str_fe7c[] = { 0x0020, 0x0651, 0 };
static const unichar_t str_fe7d[] = { 0x0640, 0x0651, 0 };
static const unichar_t str_fe7e[] = { 0x0020, 0x0652, 0 };
static const unichar_t str_fe7f[] = { 0x0640, 0x0652, 0 };
static const unichar_t str_fe80[] = { 0x0621, 0 };
static const unichar_t str_fe81[] = { 0x0622, 0 };
static const unichar_t str_fe82[] = { 0x0622, 0 };
static const unichar_t str_fe83[] = { 0x0623, 0 };
static const unichar_t str_fe84[] = { 0x0623, 0 };
static const unichar_t str_fe85[] = { 0x0624, 0 };
static const unichar_t str_fe86[] = { 0x0624, 0 };
static const unichar_t str_fe87[] = { 0x0625, 0 };
static const unichar_t str_fe88[] = { 0x0625, 0 };
static const unichar_t str_fe89[] = { 0x0626, 0 };
static const unichar_t str_fe8a[] = { 0x0626, 0 };
static const unichar_t str_fe8b[] = { 0x0626, 0 };
static const unichar_t str_fe8c[] = { 0x0626, 0 };
static const unichar_t str_fe8d[] = { 0x0627, 0 };
static const unichar_t str_fe8e[] = { 0x0627, 0 };
static const unichar_t str_fe8f[] = { 0x0628, 0 };
static const unichar_t str_fe90[] = { 0x0628, 0 };
static const unichar_t str_fe91[] = { 0x0628, 0 };
static const unichar_t str_fe92[] = { 0x0628, 0 };
static const unichar_t str_fe93[] = { 0x0629, 0 };
static const unichar_t str_fe94[] = { 0x0629, 0 };
static const unichar_t str_fe95[] = { 0x062a, 0 };
static const unichar_t str_fe96[] = { 0x062a, 0 };
static const unichar_t str_fe97[] = { 0x062a, 0 };
static const unichar_t str_fe98[] = { 0x062a, 0 };
static const unichar_t str_fe99[] = { 0x062b, 0 };
static const unichar_t str_fe9a[] = { 0x062b, 0 };
static const unichar_t str_fe9b[] = { 0x062b, 0 };
static const unichar_t str_fe9c[] = { 0x062b, 0 };
static const unichar_t str_fe9d[] = { 0x062c, 0 };
static const unichar_t str_fe9e[] = { 0x062c, 0 };
static const unichar_t str_fe9f[] = { 0x062c, 0 };
static const unichar_t str_fea0[] = { 0x062c, 0 };
static const unichar_t str_fea1[] = { 0x062d, 0 };
static const unichar_t str_fea2[] = { 0x062d, 0 };
static const unichar_t str_fea3[] = { 0x062d, 0 };
static const unichar_t str_fea4[] = { 0x062d, 0 };
static const unichar_t str_fea5[] = { 0x062e, 0 };
static const unichar_t str_fea6[] = { 0x062e, 0 };
static const unichar_t str_fea7[] = { 0x062e, 0 };
static const unichar_t str_fea8[] = { 0x062e, 0 };
static const unichar_t str_fea9[] = { 0x062f, 0 };
static const unichar_t str_feaa[] = { 0x062f, 0 };
static const unichar_t str_feab[] = { 0x0630, 0 };
static const unichar_t str_feac[] = { 0x0630, 0 };
static const unichar_t str_fead[] = { 0x0631, 0 };
static const unichar_t str_feae[] = { 0x0631, 0 };
static const unichar_t str_feaf[] = { 0x0632, 0 };
static const unichar_t str_feb0[] = { 0x0632, 0 };
static const unichar_t str_feb1[] = { 0x0633, 0 };
static const unichar_t str_feb2[] = { 0x0633, 0 };
static const unichar_t str_feb3[] = { 0x0633, 0 };
static const unichar_t str_feb4[] = { 0x0633, 0 };
static const unichar_t str_feb5[] = { 0x0634, 0 };
static const unichar_t str_feb6[] = { 0x0634, 0 };
static const unichar_t str_feb7[] = { 0x0634, 0 };
static const unichar_t str_feb8[] = { 0x0634, 0 };
static const unichar_t str_feb9[] = { 0x0635, 0 };
static const unichar_t str_feba[] = { 0x0635, 0 };
static const unichar_t str_febb[] = { 0x0635, 0 };
static const unichar_t str_febc[] = { 0x0635, 0 };
static const unichar_t str_febd[] = { 0x0636, 0 };
static const unichar_t str_febe[] = { 0x0636, 0 };
static const unichar_t str_febf[] = { 0x0636, 0 };
static const unichar_t str_fec0[] = { 0x0636, 0 };
static const unichar_t str_fec1[] = { 0x0637, 0 };
static const unichar_t str_fec2[] = { 0x0637, 0 };
static const unichar_t str_fec3[] = { 0x0637, 0 };
static const unichar_t str_fec4[] = { 0x0637, 0 };
static const unichar_t str_fec5[] = { 0x0638, 0 };
static const unichar_t str_fec6[] = { 0x0638, 0 };
static const unichar_t str_fec7[] = { 0x0638, 0 };
static const unichar_t str_fec8[] = { 0x0638, 0 };
static const unichar_t str_fec9[] = { 0x0639, 0 };
static const unichar_t str_feca[] = { 0x0639, 0 };
static const unichar_t str_fecb[] = { 0x0639, 0 };
static const unichar_t str_fecc[] = { 0x0639, 0 };
static const unichar_t str_fecd[] = { 0x063a, 0 };
static const unichar_t str_fece[] = { 0x063a, 0 };
static const unichar_t str_fecf[] = { 0x063a, 0 };
static const unichar_t str_fed0[] = { 0x063a, 0 };
static const unichar_t str_fed1[] = { 0x0641, 0 };
static const unichar_t str_fed2[] = { 0x0641, 0 };
static const unichar_t str_fed3[] = { 0x0641, 0 };
static const unichar_t str_fed4[] = { 0x0641, 0 };
static const unichar_t str_fed5[] = { 0x0642, 0 };
static const unichar_t str_fed6[] = { 0x0642, 0 };
static const unichar_t str_fed7[] = { 0x0642, 0 };
static const unichar_t str_fed8[] = { 0x0642, 0 };
static const unichar_t str_fed9[] = { 0x0643, 0 };
static const unichar_t str_feda[] = { 0x0643, 0 };
static const unichar_t str_fedb[] = { 0x0643, 0 };
static const unichar_t str_fedc[] = { 0x0643, 0 };
static const unichar_t str_fedd[] = { 0x0644, 0 };
static const unichar_t str_fede[] = { 0x0644, 0 };
static const unichar_t str_fedf[] = { 0x0644, 0 };
static const unichar_t str_fee0[] = { 0x0644, 0 };
static const unichar_t str_fee1[] = { 0x0645, 0 };
static const unichar_t str_fee2[] = { 0x0645, 0 };
static const unichar_t str_fee3[] = { 0x0645, 0 };
static const unichar_t str_fee4[] = { 0x0645, 0 };
static const unichar_t str_fee5[] = { 0x0646, 0 };
static const unichar_t str_fee6[] = { 0x0646, 0 };
static const unichar_t str_fee7[] = { 0x0646, 0 };
static const unichar_t str_fee8[] = { 0x0646, 0 };
static const unichar_t str_fee9[] = { 0x0647, 0 };
static const unichar_t str_feea[] = { 0x0647, 0 };
static const unichar_t str_feeb[] = { 0x0647, 0 };
static const unichar_t str_feec[] = { 0x0647, 0 };
static const unichar_t str_feed[] = { 0x0648, 0 };
static const unichar_t str_feee[] = { 0x0648, 0 };
static const unichar_t str_feef[] = { 0x0649, 0 };
static const unichar_t str_fef0[] = { 0x0649, 0 };
static const unichar_t str_fef1[] = { 0x064a, 0 };
static const unichar_t str_fef2[] = { 0x064a, 0 };
static const unichar_t str_fef3[] = { 0x064a, 0 };
static const unichar_t str_fef4[] = { 0x064a, 0 };
static const unichar_t str_fef5[] = { 0x0644, 0x0622, 0 };
static const unichar_t str_fef6[] = { 0x0644, 0x0622, 0 };
static const unichar_t str_fef7[] = { 0x0644, 0x0623, 0 };
static const unichar_t str_fef8[] = { 0x0644, 0x0623, 0 };
static const unichar_t str_fef9[] = { 0x0644, 0x0625, 0 };
static const unichar_t str_fefa[] = { 0x0644, 0x0625, 0 };
static const unichar_t str_fefb[] = { 0x0644, 0x0627, 0 };
static const unichar_t str_fefc[] = { 0x0644, 0x0627, 0 };
static const unichar_t str_ff01[] = { 0x0021, 0 };
static const unichar_t str_ff02[] = { 0x0022, 0 };
static const unichar_t str_ff03[] = { 0x0023, 0 };
static const unichar_t str_ff04[] = { 0x0024, 0 };
static const unichar_t str_ff05[] = { 0x0025, 0 };
static const unichar_t str_ff06[] = { 0x0026, 0 };
static const unichar_t str_ff07[] = { 0x0027, 0 };
static const unichar_t str_ff08[] = { 0x0028, 0 };
static const unichar_t str_ff09[] = { 0x0029, 0 };
static const unichar_t str_ff0a[] = { 0x002a, 0 };
static const unichar_t str_ff0b[] = { 0x002b, 0 };
static const unichar_t str_ff0c[] = { 0x002c, 0 };
static const unichar_t str_ff0d[] = { 0x002d, 0 };
static const unichar_t str_ff0e[] = { 0x002e, 0 };
static const unichar_t str_ff0f[] = { 0x002f, 0 };
static const unichar_t str_ff10[] = { 0x0030, 0 };
static const unichar_t str_ff11[] = { 0x0031, 0 };
static const unichar_t str_ff12[] = { 0x0032, 0 };
static const unichar_t str_ff13[] = { 0x0033, 0 };
static const unichar_t str_ff14[] = { 0x0034, 0 };
static const unichar_t str_ff15[] = { 0x0035, 0 };
static const unichar_t str_ff16[] = { 0x0036, 0 };
static const unichar_t str_ff17[] = { 0x0037, 0 };
static const unichar_t str_ff18[] = { 0x0038, 0 };
static const unichar_t str_ff19[] = { 0x0039, 0 };
static const unichar_t str_ff1a[] = { 0x003a, 0 };
static const unichar_t str_ff1b[] = { 0x003b, 0 };
static const unichar_t str_ff1c[] = { 0x003c, 0 };
static const unichar_t str_ff1d[] = { 0x003d, 0 };
static const unichar_t str_ff1e[] = { 0x003e, 0 };
static const unichar_t str_ff1f[] = { 0x003f, 0 };
static const unichar_t str_ff20[] = { 0x0040, 0 };
static const unichar_t str_ff21[] = { 0x0041, 0 };
static const unichar_t str_ff22[] = { 0x0042, 0 };
static const unichar_t str_ff23[] = { 0x0043, 0 };
static const unichar_t str_ff24[] = { 0x0044, 0 };
static const unichar_t str_ff25[] = { 0x0045, 0 };
static const unichar_t str_ff26[] = { 0x0046, 0 };
static const unichar_t str_ff27[] = { 0x0047, 0 };
static const unichar_t str_ff28[] = { 0x0048, 0 };
static const unichar_t str_ff29[] = { 0x0049, 0 };
static const unichar_t str_ff2a[] = { 0x004a, 0 };
static const unichar_t str_ff2b[] = { 0x004b, 0 };
static const unichar_t str_ff2c[] = { 0x004c, 0 };
static const unichar_t str_ff2d[] = { 0x004d, 0 };
static const unichar_t str_ff2e[] = { 0x004e, 0 };
static const unichar_t str_ff2f[] = { 0x004f, 0 };
static const unichar_t str_ff30[] = { 0x0050, 0 };
static const unichar_t str_ff31[] = { 0x0051, 0 };
static const unichar_t str_ff32[] = { 0x0052, 0 };
static const unichar_t str_ff33[] = { 0x0053, 0 };
static const unichar_t str_ff34[] = { 0x0054, 0 };
static const unichar_t str_ff35[] = { 0x0055, 0 };
static const unichar_t str_ff36[] = { 0x0056, 0 };
static const unichar_t str_ff37[] = { 0x0057, 0 };
static const unichar_t str_ff38[] = { 0x0058, 0 };
static const unichar_t str_ff39[] = { 0x0059, 0 };
static const unichar_t str_ff3a[] = { 0x005a, 0 };
static const unichar_t str_ff3b[] = { 0x005b, 0 };
static const unichar_t str_ff3c[] = { 0x005c, 0 };
static const unichar_t str_ff3d[] = { 0x005d, 0 };
static const unichar_t str_ff3e[] = { 0x005e, 0 };
static const unichar_t str_ff3f[] = { 0x005f, 0 };
static const unichar_t str_ff40[] = { 0x0060, 0 };
static const unichar_t str_ff41[] = { 0x0061, 0 };
static const unichar_t str_ff42[] = { 0x0062, 0 };
static const unichar_t str_ff43[] = { 0x0063, 0 };
static const unichar_t str_ff44[] = { 0x0064, 0 };
static const unichar_t str_ff45[] = { 0x0065, 0 };
static const unichar_t str_ff46[] = { 0x0066, 0 };
static const unichar_t str_ff47[] = { 0x0067, 0 };
static const unichar_t str_ff48[] = { 0x0068, 0 };
static const unichar_t str_ff49[] = { 0x0069, 0 };
static const unichar_t str_ff4a[] = { 0x006a, 0 };
static const unichar_t str_ff4b[] = { 0x006b, 0 };
static const unichar_t str_ff4c[] = { 0x006c, 0 };
static const unichar_t str_ff4d[] = { 0x006d, 0 };
static const unichar_t str_ff4e[] = { 0x006e, 0 };
static const unichar_t str_ff4f[] = { 0x006f, 0 };
static const unichar_t str_ff50[] = { 0x0070, 0 };
static const unichar_t str_ff51[] = { 0x0071, 0 };
static const unichar_t str_ff52[] = { 0x0072, 0 };
static const unichar_t str_ff53[] = { 0x0073, 0 };
static const unichar_t str_ff54[] = { 0x0074, 0 };
static const unichar_t str_ff55[] = { 0x0075, 0 };
static const unichar_t str_ff56[] = { 0x0076, 0 };
static const unichar_t str_ff57[] = { 0x0077, 0 };
static const unichar_t str_ff58[] = { 0x0078, 0 };
static const unichar_t str_ff59[] = { 0x0079, 0 };
static const unichar_t str_ff5a[] = { 0x007a, 0 };
static const unichar_t str_ff5b[] = { 0x007b, 0 };
static const unichar_t str_ff5c[] = { 0x007c, 0 };
static const unichar_t str_ff5d[] = { 0x007d, 0 };
static const unichar_t str_ff5e[] = { 0x007e, 0 };
static const unichar_t str_ff5f[] = { 0x2985, 0 };
static const unichar_t str_ff60[] = { 0x2986, 0 };
static const unichar_t str_ff61[] = { 0x3002, 0 };
static const unichar_t str_ff62[] = { 0x300c, 0 };
static const unichar_t str_ff63[] = { 0x300d, 0 };
static const unichar_t str_ff64[] = { 0x3001, 0 };
static const unichar_t str_ff65[] = { 0x30fb, 0 };
static const unichar_t str_ff66[] = { 0x30f2, 0 };
static const unichar_t str_ff67[] = { 0x30a1, 0 };
static const unichar_t str_ff68[] = { 0x30a3, 0 };
static const unichar_t str_ff69[] = { 0x30a5, 0 };
static const unichar_t str_ff6a[] = { 0x30a7, 0 };
static const unichar_t str_ff6b[] = { 0x30a9, 0 };
static const unichar_t str_ff6c[] = { 0x30e3, 0 };
static const unichar_t str_ff6d[] = { 0x30e5, 0 };
static const unichar_t str_ff6e[] = { 0x30e7, 0 };
static const unichar_t str_ff6f[] = { 0x30c3, 0 };
static const unichar_t str_ff70[] = { 0x30fc, 0 };
static const unichar_t str_ff71[] = { 0x30a2, 0 };
static const unichar_t str_ff72[] = { 0x30a4, 0 };
static const unichar_t str_ff73[] = { 0x30a6, 0 };
static const unichar_t str_ff74[] = { 0x30a8, 0 };
static const unichar_t str_ff75[] = { 0x30aa, 0 };
static const unichar_t str_ff76[] = { 0x30ab, 0 };
static const unichar_t str_ff77[] = { 0x30ad, 0 };
static const unichar_t str_ff78[] = { 0x30af, 0 };
static const unichar_t str_ff79[] = { 0x30b1, 0 };
static const unichar_t str_ff7a[] = { 0x30b3, 0 };
static const unichar_t str_ff7b[] = { 0x30b5, 0 };
static const unichar_t str_ff7c[] = { 0x30b7, 0 };
static const unichar_t str_ff7d[] = { 0x30b9, 0 };
static const unichar_t str_ff7e[] = { 0x30bb, 0 };
static const unichar_t str_ff7f[] = { 0x30bd, 0 };
static const unichar_t str_ff80[] = { 0x30bf, 0 };
static const unichar_t str_ff81[] = { 0x30c1, 0 };
static const unichar_t str_ff82[] = { 0x30c4, 0 };
static const unichar_t str_ff83[] = { 0x30c6, 0 };
static const unichar_t str_ff84[] = { 0x30c8, 0 };
static const unichar_t str_ff85[] = { 0x30ca, 0 };
static const unichar_t str_ff86[] = { 0x30cb, 0 };
static const unichar_t str_ff87[] = { 0x30cc, 0 };
static const unichar_t str_ff88[] = { 0x30cd, 0 };
static const unichar_t str_ff89[] = { 0x30ce, 0 };
static const unichar_t str_ff8a[] = { 0x30cf, 0 };
static const unichar_t str_ff8b[] = { 0x30d2, 0 };
static const unichar_t str_ff8c[] = { 0x30d5, 0 };
static const unichar_t str_ff8d[] = { 0x30d8, 0 };
static const unichar_t str_ff8e[] = { 0x30db, 0 };
static const unichar_t str_ff8f[] = { 0x30de, 0 };
static const unichar_t str_ff90[] = { 0x30df, 0 };
static const unichar_t str_ff91[] = { 0x30e0, 0 };
static const unichar_t str_ff92[] = { 0x30e1, 0 };
static const unichar_t str_ff93[] = { 0x30e2, 0 };
static const unichar_t str_ff94[] = { 0x30e4, 0 };
static const unichar_t str_ff95[] = { 0x30e6, 0 };
static const unichar_t str_ff96[] = { 0x30e8, 0 };
static const unichar_t str_ff97[] = { 0x30e9, 0 };
static const unichar_t str_ff98[] = { 0x30ea, 0 };
static const unichar_t str_ff99[] = { 0x30eb, 0 };
static const unichar_t str_ff9a[] = { 0x30ec, 0 };
static const unichar_t str_ff9b[] = { 0x30ed, 0 };
static const unichar_t str_ff9c[] = { 0x30ef, 0 };
static const unichar_t str_ff9d[] = { 0x30f3, 0 };
static const unichar_t str_ff9e[] = { 0x3099, 0 };
static const unichar_t str_ff9f[] = { 0x309a, 0 };
static const unichar_t str_ffa0[] = { 0x3164, 0 };
static const unichar_t str_ffa1[] = { 0x3131, 0 };
static const unichar_t str_ffa2[] = { 0x3132, 0 };
static const unichar_t str_ffa3[] = { 0x3133, 0 };
static const unichar_t str_ffa4[] = { 0x3134, 0 };
static const unichar_t str_ffa5[] = { 0x3135, 0 };
static const unichar_t str_ffa6[] = { 0x3136, 0 };
static const unichar_t str_ffa7[] = { 0x3137, 0 };
static const unichar_t str_ffa8[] = { 0x3138, 0 };
static const unichar_t str_ffa9[] = { 0x3139, 0 };
static const unichar_t str_ffaa[] = { 0x313a, 0 };
static const unichar_t str_ffab[] = { 0x313b, 0 };
static const unichar_t str_ffac[] = { 0x313c, 0 };
static const unichar_t str_ffad[] = { 0x313d, 0 };
static const unichar_t str_ffae[] = { 0x313e, 0 };
static const unichar_t str_ffaf[] = { 0x313f, 0 };
static const unichar_t str_ffb0[] = { 0x3140, 0 };
static const unichar_t str_ffb1[] = { 0x3141, 0 };
static const unichar_t str_ffb2[] = { 0x3142, 0 };
static const unichar_t str_ffb3[] = { 0x3143, 0 };
static const unichar_t str_ffb4[] = { 0x3144, 0 };
static const unichar_t str_ffb5[] = { 0x3145, 0 };
static const unichar_t str_ffb6[] = { 0x3146, 0 };
static const unichar_t str_ffb7[] = { 0x3147, 0 };
static const unichar_t str_ffb8[] = { 0x3148, 0 };
static const unichar_t str_ffb9[] = { 0x3149, 0 };
static const unichar_t str_ffba[] = { 0x314a, 0 };
static const unichar_t str_ffbb[] = { 0x314b, 0 };
static const unichar_t str_ffbc[] = { 0x314c, 0 };
static const unichar_t str_ffbd[] = { 0x314d, 0 };
static const unichar_t str_ffbe[] = { 0x314e, 0 };
static const unichar_t str_ffc2[] = { 0x314f, 0 };
static const unichar_t str_ffc3[] = { 0x3150, 0 };
static const unichar_t str_ffc4[] = { 0x3151, 0 };
static const unichar_t str_ffc5[] = { 0x3152, 0 };
static const unichar_t str_ffc6[] = { 0x3153, 0 };
static const unichar_t str_ffc7[] = { 0x3154, 0 };
static const unichar_t str_ffca[] = { 0x3155, 0 };
static const unichar_t str_ffcb[] = { 0x3156, 0 };
static const unichar_t str_ffcc[] = { 0x3157, 0 };
static const unichar_t str_ffcd[] = { 0x3158, 0 };
static const unichar_t str_ffce[] = { 0x3159, 0 };
static const unichar_t str_ffcf[] = { 0x315a, 0 };
static const unichar_t str_ffd2[] = { 0x315b, 0 };
static const unichar_t str_ffd3[] = { 0x315c, 0 };
static const unichar_t str_ffd4[] = { 0x315d, 0 };
static const unichar_t str_ffd5[] = { 0x315e, 0 };
static const unichar_t str_ffd6[] = { 0x315f, 0 };
static const unichar_t str_ffd7[] = { 0x3160, 0 };
static const unichar_t str_ffda[] = { 0x3161, 0 };
static const unichar_t str_ffdb[] = { 0x3162, 0 };
static const unichar_t str_ffdc[] = { 0x3163, 0 };
static const unichar_t str_ffe0[] = { 0x00a2, 0 };
static const unichar_t str_ffe1[] = { 0x00a3, 0 };
static const unichar_t str_ffe2[] = { 0x00ac, 0 };
static const unichar_t str_ffe3[] = { 0x00af, 0 };
static const unichar_t str_ffe4[] = { 0x00a6, 0 };
static const unichar_t str_ffe5[] = { 0x00a5, 0 };
static const unichar_t str_ffe6[] = { 0x20a9, 0 };
static const unichar_t str_ffe8[] = { 0x2502, 0 };
static const unichar_t str_ffe9[] = { 0x2190, 0 };
static const unichar_t str_ffea[] = { 0x2191, 0 };
static const unichar_t str_ffeb[] = { 0x2192, 0 };
static const unichar_t str_ffec[] = { 0x2193, 0 };
static const unichar_t str_ffed[] = { 0x25a0, 0 };
static const unichar_t str_ffee[] = { 0x25cb, 0 };

static const unichar_t *const up_allzeros[256] = { NULL };

static const unichar_t * const tab_0[] = {
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_a0,
0, 0, 0, 0, 0, 0, 0, str_a8,
0, str_aa,
0, 0, 0, 0, str_af,
0, 0, str_b2,
str_b3,
str_b4,
str_b5,
0, 0, str_b8,
str_b9,
str_ba,
0, str_bc,
str_bd,
str_be,
0, str_c0,
str_c1,
str_c2,
str_c3,
str_c4,
str_c5,
0, str_c7,
str_c8,
str_c9,
str_ca,
str_cb,
str_cc,
str_cd,
str_ce,
str_cf,
0, str_d1,
str_d2,
str_d3,
str_d4,
str_d5,
str_d6,
0, 0, str_d9,
str_da,
str_db,
str_dc,
str_dd,
0, 0, str_e0,
str_e1,
str_e2,
str_e3,
str_e4,
str_e5,
0, str_e7,
str_e8,
str_e9,
str_ea,
str_eb,
str_ec,
str_ed,
str_ee,
str_ef,
0, str_f1,
str_f2,
str_f3,
str_f4,
str_f5,
str_f6,
0, 0, str_f9,
str_fa,
str_fb,
str_fc,
str_fd,
0, str_ff,
0};

static const unichar_t * const tab_1[] = {
str_100,
str_101,
str_102,
str_103,
str_104,
str_105,
str_106,
str_107,
str_108,
str_109,
str_10a,
str_10b,
str_10c,
str_10d,
str_10e,
str_10f,
str_110,
0, str_112,
str_113,
str_114,
str_115,
str_116,
str_117,
str_118,
str_119,
str_11a,
str_11b,
str_11c,
str_11d,
str_11e,
str_11f,
str_120,
str_121,
str_122,
str_123,
str_124,
str_125,
0, 0, str_128,
str_129,
str_12a,
str_12b,
str_12c,
str_12d,
str_12e,
str_12f,
str_130,
0, str_132,
str_133,
str_134,
str_135,
str_136,
str_137,
str_138,
str_139,
str_13a,
str_13b,
str_13c,
str_13d,
str_13e,
str_13f,
str_140,
0, 0, str_143,
str_144,
str_145,
str_146,
str_147,
str_148,
str_149,
0, 0, str_14c,
str_14d,
str_14e,
str_14f,
str_150,
str_151,
str_152,
str_153,
str_154,
str_155,
str_156,
str_157,
str_158,
str_159,
str_15a,
str_15b,
str_15c,
str_15d,
str_15e,
str_15f,
str_160,
str_161,
str_162,
str_163,
str_164,
str_165,
0, 0, str_168,
str_169,
str_16a,
str_16b,
str_16c,
str_16d,
str_16e,
str_16f,
str_170,
str_171,
str_172,
str_173,
str_174,
str_175,
str_176,
str_177,
str_178,
str_179,
str_17a,
str_17b,
str_17c,
str_17d,
str_17e,
str_17f,
0, 0, str_182,
0, 0, 0, 0, 0, 0, str_189,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_19e,
str_19f,
str_1a0,
str_1a1,
0, 0, 0, 0, 0, 0, 0, str_1a9,
0, 0, 0, 0, 0, str_1af,
str_1b0,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_1c0,
str_1c1,
0, 0, str_1c4,
str_1c5,
str_1c6,
str_1c7,
str_1c8,
str_1c9,
str_1ca,
str_1cb,
str_1cc,
str_1cd,
str_1ce,
str_1cf,
str_1d0,
str_1d1,
str_1d2,
str_1d3,
str_1d4,
str_1d5,
str_1d6,
str_1d7,
str_1d8,
str_1d9,
str_1da,
str_1db,
str_1dc,
0, str_1de,
str_1df,
str_1e0,
str_1e1,
str_1e2,
str_1e3,
0, 0, str_1e6,
str_1e7,
str_1e8,
str_1e9,
str_1ea,
str_1eb,
str_1ec,
str_1ed,
str_1ee,
str_1ef,
str_1f0,
str_1f1,
str_1f2,
str_1f3,
str_1f4,
str_1f5,
0, 0, str_1f8,
str_1f9,
str_1fa,
str_1fb,
str_1fc,
str_1fd,
str_1fe,
str_1ff,
0};

static const unichar_t * const tab_2[] = {
str_200,
str_201,
str_202,
str_203,
str_204,
str_205,
str_206,
str_207,
str_208,
str_209,
str_20a,
str_20b,
str_20c,
str_20d,
str_20e,
str_20f,
str_210,
str_211,
str_212,
str_213,
str_214,
str_215,
str_216,
str_217,
str_218,
str_219,
str_21a,
str_21b,
0, 0, str_21e,
str_21f,
0, 0, 0, 0, 0, 0, str_226,
str_227,
str_228,
str_229,
str_22a,
str_22b,
str_22c,
str_22d,
str_22e,
str_22f,
str_230,
str_231,
str_232,
str_233,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_269,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_278,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_292,
0, 0, 0, 0, 0, 0, str_299,
0, 0, str_29c,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_2b0,
str_2b1,
str_2b2,
str_2b3,
str_2b4,
str_2b5,
str_2b6,
str_2b7,
str_2b8,
str_2b9,
str_2ba,
0, str_2bc,
0, 0, 0, 0, 0, 0, 0, str_2c4,
0, str_2c6,
0, str_2c8,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_2d8,
str_2d9,
str_2da,
str_2db,
str_2dc,
str_2dd,
0, 0, str_2e0,
str_2e1,
str_2e2,
str_2e3,
str_2e4,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

static const unichar_t * const tab_3[] = {
0, str_301,
str_302,
str_303,
0, 0, 0, 0, str_308,
0, str_30a,
str_30b,
0, 0, str_30e,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_327,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_340,
str_341,
0, str_343,
str_344,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_374,
str_375,
0, 0, 0, 0, str_37a,
0, 0, 0, str_37e,
0, 0, 0, 0, 0, str_384,
str_385,
str_386,
str_387,
str_388,
str_389,
str_38a,
0, str_38c,
0, str_38e,
str_38f,
str_390,
str_391,
str_392,
str_393,
0, str_395,
str_396,
str_397,
0, str_399,
str_39a,
0, str_39c,
str_39d,
0, str_39f,
0, str_3a1,
0, 0, str_3a4,
str_3a5,
0, str_3a7,
0, 0, str_3aa,
str_3ab,
str_3ac,
str_3ad,
str_3ae,
str_3af,
str_3b0,
0, 0, 0, 0, 0, 0, 0, 0, 0, str_3ba,
0, 0, 0, 0, str_3bf,
0, str_3c1,
0, 0, 0, 0, 0, str_3c7,
0, 0, str_3ca,
str_3cb,
str_3cc,
str_3cd,
str_3ce,
0, str_3d0,
str_3d1,
str_3d2,
str_3d3,
str_3d4,
str_3d5,
str_3d6,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_3f0,
str_3f1,
str_3f2,
0, str_3f4,
str_3f5,
0, 0, 0, str_3f9,
0, 0, 0, 0, 0, 0, 0};

static const unichar_t * const tab_4[] = {
str_400,
str_401,
0, str_403,
0, str_405,
str_406,
str_407,
str_408,
0, 0, 0, str_40c,
str_40d,
str_40e,
0, str_410,
0, str_412,
str_413,
0, str_415,
0, 0, 0, str_419,
str_41a,
0, str_41c,
str_41d,
str_41e,
str_41f,
str_420,
str_421,
str_422,
0, str_424,
str_425,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_430,
0, 0, 0, 0, str_435,
0, 0, 0, str_439,
str_43a,
0, 0, 0, str_43e,
str_43f,
str_440,
str_441,
0, str_443,
0, str_445,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_450,
str_451,
0, str_453,
0, str_455,
str_456,
str_457,
str_458,
0, 0, 0, str_45c,
str_45d,
str_45e,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_470,
str_471,
0, 0, 0, 0, str_476,
str_477,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_4ae,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_4c0,
str_4c1,
str_4c2,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_4d0,
str_4d1,
str_4d2,
str_4d3,
str_4d4,
str_4d5,
str_4d6,
str_4d7,
0, 0, str_4da,
str_4db,
str_4dc,
str_4dd,
str_4de,
str_4df,
str_4e0,
str_4e1,
str_4e2,
str_4e3,
str_4e4,
str_4e5,
str_4e6,
str_4e7,
str_4e8,
str_4e9,
str_4ea,
str_4eb,
str_4ec,
str_4ed,
str_4ee,
str_4ef,
str_4f0,
str_4f1,
str_4f2,
str_4f3,
str_4f4,
str_4f5,
0, 0, str_4f8,
str_4f9,
0, 0, 0, 0, 0, 0, 0};

static const unichar_t * const tab_5[] = {
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_54f,
0, 0, 0, 0, 0, str_555,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_570,
0, 0, 0, 0, 0, 0, 0, str_578,
0, str_57a,
0, 0, str_57d,
0, 0, 0, str_581,
str_582,
0, str_584,
str_585,
0, str_587,
0, str_589,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_5f0,
str_5f1,
str_5f2,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

static const unichar_t * const tab_6[] = {
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_60c,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_621,
str_622,
str_623,
str_624,
str_625,
str_626,
str_627,
str_628,
str_629,
str_62a,
str_62b,
str_62c,
str_62d,
str_62e,
str_62f,
str_630,
str_631,
str_632,
str_633,
str_634,
str_635,
str_636,
str_637,
str_638,
str_639,
str_63a,
0, 0, 0, 0, 0, 0, str_641,
str_642,
str_643,
str_644,
str_645,
str_646,
str_647,
str_648,
str_649,
str_64a,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_66a,
0, str_66c,
str_66d,
0, 0, 0, str_671,
0, 0, 0, str_675,
str_676,
str_677,
str_678,
str_679,
str_67a,
str_67b,
0, 0, str_67e,
str_67f,
str_680,
0, 0, str_683,
str_684,
0, str_686,
str_687,
str_688,
0, 0, 0, str_68c,
str_68d,
str_68e,
0, 0, str_691,
0, 0, 0, 0, 0, 0, str_698,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_6a4,
0, str_6a6,
0, 0, str_6a9,
0, 0, 0, str_6ad,
0, str_6af,
0, str_6b1,
0, str_6b3,
0, 0, 0, 0, 0, 0, str_6ba,
str_6bb,
0, 0, str_6be,
0, str_6c0,
str_6c1,
str_6c2,
0, 0, str_6c5,
str_6c6,
str_6c7,
str_6c8,
str_6c9,
0, str_6cb,
str_6cc,
0, 0, 0, str_6d0,
0, str_6d2,
str_6d3,
str_6d4,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

static const unichar_t * const tab_9[] = {
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_929,
0, 0, 0, 0, 0, 0, 0, str_931,
0, 0, str_934,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_958,
str_959,
str_95a,
str_95b,
str_95c,
str_95d,
str_95e,
str_95f,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_9cb,
str_9cc,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_9dc,
str_9dd,
0, str_9df,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

static const unichar_t * const tab_a[] = {
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_a33,
0, 0, str_a36,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_a59,
str_a5a,
str_a5b,
0, 0, str_a5e,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

static const unichar_t * const tab_b[] = {
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_b48,
0, 0, str_b4b,
str_b4c,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_b5c,
str_b5d,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_b94,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_bca,
str_bcb,
str_bcc,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

static const unichar_t * const tab_c[] = {
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_c48,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_cc0,
0, 0, 0, 0, 0, 0, str_cc7,
str_cc8,
0, str_cca,
str_ccb,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

static const unichar_t * const tab_d[] = {
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_d4a,
str_d4b,
str_d4c,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_dda,
0, str_ddc,
str_ddd,
str_dde,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

static const unichar_t * const tab_e[] = {
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_e33,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_eb3,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_edc,
str_edd,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

static const unichar_t * const tab_f[] = {
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_f0c,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_f43,
0, 0, 0, 0, 0, 0, 0, 0, 0, str_f4d,
0, 0, 0, 0, str_f52,
0, 0, 0, 0, str_f57,
0, 0, 0, 0, str_f5c,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_f69,
0, 0, 0, 0, 0, 0, 0, 0, 0, str_f73,
0, str_f75,
str_f76,
str_f77,
str_f78,
str_f79,
0, 0, 0, 0, 0, 0, 0, str_f81,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_f93,
0, 0, 0, 0, 0, 0, 0, 0, 0, str_f9d,
0, 0, 0, 0, str_fa2,
0, 0, 0, 0, str_fa7,
0, 0, 0, 0, str_fac,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_fb9,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

static const unichar_t * const tab_10[] = {
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_1026,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_10fc,
0, 0, 0, 0};

static const unichar_t * const tab_11[] = {
0, str_1101,
0, 0, str_1104,
0, 0, 0, str_1108,
0, str_110a,
0, 0, str_110d,
0, 0, 0, 0, 0, str_1113,
str_1114,
str_1115,
str_1116,
str_1117,
str_1118,
str_1119,
str_111a,
str_111b,
str_111c,
str_111d,
str_111e,
str_111f,
str_1120,
str_1121,
str_1122,
str_1123,
str_1124,
str_1125,
str_1126,
str_1127,
str_1128,
str_1129,
str_112a,
str_112b,
str_112c,
str_112d,
str_112e,
str_112f,
str_1130,
str_1131,
str_1132,
str_1133,
str_1134,
str_1135,
str_1136,
str_1137,
str_1138,
str_1139,
str_113a,
str_113b,
0, str_113d,
0, str_113f,
0, str_1141,
str_1142,
str_1143,
str_1144,
str_1145,
str_1146,
str_1147,
str_1148,
str_1149,
str_114a,
str_114b,
0, str_114d,
0, str_114f,
0, str_1151,
str_1152,
str_1153,
0, 0, str_1156,
str_1157,
str_1158,
0, 0, 0, 0, 0, 0, 0, 0, 0, str_1162,
0, str_1164,
0, str_1166,
0, str_1168,
0, str_116a,
str_116b,
str_116c,
0, 0, str_116f,
str_1170,
str_1171,
0, 0, str_1174,
0, str_1176,
str_1177,
str_1178,
str_1179,
str_117a,
str_117b,
str_117c,
str_117d,
str_117e,
str_117f,
str_1180,
str_1181,
str_1182,
str_1183,
str_1184,
str_1185,
str_1186,
str_1187,
str_1188,
str_1189,
str_118a,
str_118b,
str_118c,
str_118d,
str_118e,
str_118f,
str_1190,
str_1191,
str_1192,
str_1193,
str_1194,
str_1195,
str_1196,
str_1197,
str_1198,
str_1199,
str_119a,
str_119b,
str_119c,
str_119d,
0, str_119f,
str_11a0,
str_11a1,
str_11a2,
0, 0, 0, 0, 0, str_11a8,
str_11a9,
str_11aa,
str_11ab,
str_11ac,
str_11ad,
str_11ae,
str_11af,
str_11b0,
str_11b1,
str_11b2,
str_11b3,
str_11b4,
str_11b5,
str_11b6,
str_11b7,
str_11b8,
str_11b9,
str_11ba,
str_11bb,
str_11bc,
str_11bd,
str_11be,
str_11bf,
str_11c0,
str_11c1,
str_11c2,
str_11c3,
str_11c4,
str_11c5,
str_11c6,
str_11c7,
str_11c8,
str_11c9,
str_11ca,
str_11cb,
str_11cc,
str_11cd,
str_11ce,
str_11cf,
str_11d0,
str_11d1,
str_11d2,
str_11d3,
str_11d4,
str_11d5,
str_11d6,
str_11d7,
str_11d8,
str_11d9,
str_11da,
str_11db,
str_11dc,
str_11dd,
str_11de,
str_11df,
str_11e0,
str_11e1,
str_11e2,
str_11e3,
str_11e4,
str_11e5,
str_11e6,
str_11e7,
str_11e8,
str_11e9,
str_11ea,
str_11eb,
str_11ec,
str_11ed,
str_11ee,
str_11ef,
str_11f0,
str_11f1,
str_11f2,
str_11f3,
str_11f4,
str_11f5,
str_11f6,
str_11f7,
str_11f8,
str_11f9,
0, 0, 0, 0, 0, 0, 0};

static const unichar_t * const tab_13[] = {
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_13a0,
str_13a1,
str_13a2,
0, 0, 0, 0, 0, 0, str_13a9,
str_13aa,
str_13ab,
str_13ac,
0, 0, 0, 0, str_13b1,
0, str_13b3,
0, 0, 0, str_13b7,
0, 0, 0, str_13bb,
0, 0, str_13be,
0, str_13c0,
0, str_13c2,
str_13c3,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_13cf,
0, 0, 0, 0, 0, 0, 0, 0, 0, str_13d9,
str_13da,
0, 0, 0, str_13de,
str_13df,
0, 0, str_13e2,
0, 0, 0, str_13e6,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_13f4,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

static const unichar_t * const tab_1b[] = {
0, 0, 0, 0, 0, 0, str_1b06,
0, str_1b08,
0, str_1b0a,
0, str_1b0c,
0, str_1b0e,
0, 0, 0, str_1b12,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_1b3b,
0, str_1b3d,
0, 0, str_1b40,
str_1b41,
0, str_1b43,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

static const unichar_t * const tab_1d[] = {
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_1d2c,
str_1d2d,
str_1d2e,
0, str_1d30,
str_1d31,
str_1d32,
str_1d33,
str_1d34,
str_1d35,
str_1d36,
str_1d37,
str_1d38,
str_1d39,
str_1d3a,
0, str_1d3c,
str_1d3d,
str_1d3e,
str_1d3f,
str_1d40,
str_1d41,
str_1d42,
str_1d43,
str_1d44,
str_1d45,
str_1d46,
str_1d47,
str_1d48,
str_1d49,
str_1d4a,
str_1d4b,
str_1d4c,
str_1d4d,
0, str_1d4f,
str_1d50,
str_1d51,
str_1d52,
str_1d53,
str_1d54,
str_1d55,
str_1d56,
str_1d57,
str_1d58,
str_1d59,
str_1d5a,
str_1d5b,
str_1d5c,
str_1d5d,
str_1d5e,
str_1d5f,
str_1d60,
str_1d61,
str_1d62,
str_1d63,
str_1d64,
str_1d65,
str_1d66,
str_1d67,
str_1d68,
str_1d69,
str_1d6a,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_1d78,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_1d9b,
str_1d9c,
str_1d9d,
str_1d9e,
str_1d9f,
str_1da0,
str_1da1,
str_1da2,
str_1da3,
str_1da4,
str_1da5,
str_1da6,
str_1da7,
str_1da8,
str_1da9,
str_1daa,
str_1dab,
str_1dac,
str_1dad,
str_1dae,
str_1daf,
str_1db0,
str_1db1,
str_1db2,
str_1db3,
str_1db4,
str_1db5,
str_1db6,
str_1db7,
str_1db8,
str_1db9,
str_1dba,
str_1dbb,
str_1dbc,
str_1dbd,
str_1dbe,
str_1dbf,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

static const unichar_t * const tab_1e[] = {
str_1e00,
str_1e01,
str_1e02,
str_1e03,
str_1e04,
str_1e05,
str_1e06,
str_1e07,
str_1e08,
str_1e09,
str_1e0a,
str_1e0b,
str_1e0c,
str_1e0d,
str_1e0e,
str_1e0f,
str_1e10,
str_1e11,
str_1e12,
str_1e13,
str_1e14,
str_1e15,
str_1e16,
str_1e17,
str_1e18,
str_1e19,
str_1e1a,
str_1e1b,
str_1e1c,
str_1e1d,
str_1e1e,
str_1e1f,
str_1e20,
str_1e21,
str_1e22,
str_1e23,
str_1e24,
str_1e25,
str_1e26,
str_1e27,
str_1e28,
str_1e29,
str_1e2a,
str_1e2b,
str_1e2c,
str_1e2d,
str_1e2e,
str_1e2f,
str_1e30,
str_1e31,
str_1e32,
str_1e33,
str_1e34,
str_1e35,
str_1e36,
str_1e37,
str_1e38,
str_1e39,
str_1e3a,
str_1e3b,
str_1e3c,
str_1e3d,
str_1e3e,
str_1e3f,
str_1e40,
str_1e41,
str_1e42,
str_1e43,
str_1e44,
str_1e45,
str_1e46,
str_1e47,
str_1e48,
str_1e49,
str_1e4a,
str_1e4b,
str_1e4c,
str_1e4d,
str_1e4e,
str_1e4f,
str_1e50,
str_1e51,
str_1e52,
str_1e53,
str_1e54,
str_1e55,
str_1e56,
str_1e57,
str_1e58,
str_1e59,
str_1e5a,
str_1e5b,
str_1e5c,
str_1e5d,
str_1e5e,
str_1e5f,
str_1e60,
str_1e61,
str_1e62,
str_1e63,
str_1e64,
str_1e65,
str_1e66,
str_1e67,
str_1e68,
str_1e69,
str_1e6a,
str_1e6b,
str_1e6c,
str_1e6d,
str_1e6e,
str_1e6f,
str_1e70,
str_1e71,
str_1e72,
str_1e73,
str_1e74,
str_1e75,
str_1e76,
str_1e77,
str_1e78,
str_1e79,
str_1e7a,
str_1e7b,
str_1e7c,
str_1e7d,
str_1e7e,
str_1e7f,
str_1e80,
str_1e81,
str_1e82,
str_1e83,
str_1e84,
str_1e85,
str_1e86,
str_1e87,
str_1e88,
str_1e89,
str_1e8a,
str_1e8b,
str_1e8c,
str_1e8d,
str_1e8e,
str_1e8f,
str_1e90,
str_1e91,
str_1e92,
str_1e93,
str_1e94,
str_1e95,
str_1e96,
str_1e97,
str_1e98,
str_1e99,
str_1e9a,
str_1e9b,
0, 0, 0, 0, str_1ea0,
str_1ea1,
str_1ea2,
str_1ea3,
str_1ea4,
str_1ea5,
str_1ea6,
str_1ea7,
str_1ea8,
str_1ea9,
str_1eaa,
str_1eab,
str_1eac,
str_1ead,
str_1eae,
str_1eaf,
str_1eb0,
str_1eb1,
str_1eb2,
str_1eb3,
str_1eb4,
str_1eb5,
str_1eb6,
str_1eb7,
str_1eb8,
str_1eb9,
str_1eba,
str_1ebb,
str_1ebc,
str_1ebd,
str_1ebe,
str_1ebf,
str_1ec0,
str_1ec1,
str_1ec2,
str_1ec3,
str_1ec4,
str_1ec5,
str_1ec6,
str_1ec7,
str_1ec8,
str_1ec9,
str_1eca,
str_1ecb,
str_1ecc,
str_1ecd,
str_1ece,
str_1ecf,
str_1ed0,
str_1ed1,
str_1ed2,
str_1ed3,
str_1ed4,
str_1ed5,
str_1ed6,
str_1ed7,
str_1ed8,
str_1ed9,
str_1eda,
str_1edb,
str_1edc,
str_1edd,
str_1ede,
str_1edf,
str_1ee0,
str_1ee1,
str_1ee2,
str_1ee3,
str_1ee4,
str_1ee5,
str_1ee6,
str_1ee7,
str_1ee8,
str_1ee9,
str_1eea,
str_1eeb,
str_1eec,
str_1eed,
str_1eee,
str_1eef,
str_1ef0,
str_1ef1,
str_1ef2,
str_1ef3,
str_1ef4,
str_1ef5,
str_1ef6,
str_1ef7,
str_1ef8,
str_1ef9,
0, 0, 0, 0, 0, 0, 0};

static const unichar_t * const tab_1f[] = {
str_1f00,
str_1f01,
str_1f02,
str_1f03,
str_1f04,
str_1f05,
str_1f06,
str_1f07,
str_1f08,
str_1f09,
str_1f0a,
str_1f0b,
str_1f0c,
str_1f0d,
str_1f0e,
str_1f0f,
str_1f10,
str_1f11,
str_1f12,
str_1f13,
str_1f14,
str_1f15,
0, 0, str_1f18,
str_1f19,
str_1f1a,
str_1f1b,
str_1f1c,
str_1f1d,
0, 0, str_1f20,
str_1f21,
str_1f22,
str_1f23,
str_1f24,
str_1f25,
str_1f26,
str_1f27,
str_1f28,
str_1f29,
str_1f2a,
str_1f2b,
str_1f2c,
str_1f2d,
str_1f2e,
str_1f2f,
str_1f30,
str_1f31,
str_1f32,
str_1f33,
str_1f34,
str_1f35,
str_1f36,
str_1f37,
str_1f38,
str_1f39,
str_1f3a,
str_1f3b,
str_1f3c,
str_1f3d,
str_1f3e,
str_1f3f,
str_1f40,
str_1f41,
str_1f42,
str_1f43,
str_1f44,
str_1f45,
0, 0, str_1f48,
str_1f49,
str_1f4a,
str_1f4b,
str_1f4c,
str_1f4d,
0, 0, str_1f50,
str_1f51,
str_1f52,
str_1f53,
str_1f54,
str_1f55,
str_1f56,
str_1f57,
0, str_1f59,
0, str_1f5b,
0, str_1f5d,
0, str_1f5f,
str_1f60,
str_1f61,
str_1f62,
str_1f63,
str_1f64,
str_1f65,
str_1f66,
str_1f67,
str_1f68,
str_1f69,
str_1f6a,
str_1f6b,
str_1f6c,
str_1f6d,
str_1f6e,
str_1f6f,
str_1f70,
str_1f71,
str_1f72,
str_1f73,
str_1f74,
str_1f75,
str_1f76,
str_1f77,
str_1f78,
str_1f79,
str_1f7a,
str_1f7b,
str_1f7c,
str_1f7d,
0, 0, str_1f80,
str_1f81,
str_1f82,
str_1f83,
str_1f84,
str_1f85,
str_1f86,
str_1f87,
str_1f88,
str_1f89,
str_1f8a,
str_1f8b,
str_1f8c,
str_1f8d,
str_1f8e,
str_1f8f,
str_1f90,
str_1f91,
str_1f92,
str_1f93,
str_1f94,
str_1f95,
str_1f96,
str_1f97,
str_1f98,
str_1f99,
str_1f9a,
str_1f9b,
str_1f9c,
str_1f9d,
str_1f9e,
str_1f9f,
str_1fa0,
str_1fa1,
str_1fa2,
str_1fa3,
str_1fa4,
str_1fa5,
str_1fa6,
str_1fa7,
str_1fa8,
str_1fa9,
str_1faa,
str_1fab,
str_1fac,
str_1fad,
str_1fae,
str_1faf,
str_1fb0,
str_1fb1,
str_1fb2,
str_1fb3,
str_1fb4,
0, str_1fb6,
str_1fb7,
str_1fb8,
str_1fb9,
str_1fba,
str_1fbb,
str_1fbc,
str_1fbd,
str_1fbe,
str_1fbf,
str_1fc0,
str_1fc1,
str_1fc2,
str_1fc3,
str_1fc4,
0, str_1fc6,
str_1fc7,
str_1fc8,
str_1fc9,
str_1fca,
str_1fcb,
str_1fcc,
str_1fcd,
str_1fce,
str_1fcf,
str_1fd0,
str_1fd1,
str_1fd2,
str_1fd3,
0, 0, str_1fd6,
str_1fd7,
str_1fd8,
str_1fd9,
str_1fda,
str_1fdb,
0, str_1fdd,
str_1fde,
str_1fdf,
str_1fe0,
str_1fe1,
str_1fe2,
str_1fe3,
str_1fe4,
str_1fe5,
str_1fe6,
str_1fe7,
str_1fe8,
str_1fe9,
str_1fea,
str_1feb,
str_1fec,
str_1fed,
str_1fee,
str_1fef,
0, 0, str_1ff2,
str_1ff3,
str_1ff4,
0, str_1ff6,
str_1ff7,
str_1ff8,
str_1ff9,
str_1ffa,
str_1ffb,
str_1ffc,
str_1ffd,
str_1ffe,
0, 0};

static const unichar_t * const tab_20[] = {
str_2000,
str_2001,
str_2002,
str_2003,
str_2004,
str_2005,
str_2006,
str_2007,
str_2008,
str_2009,
str_200a,
0, 0, 0, 0, 0, str_2010,
str_2011,
str_2012,
str_2013,
str_2014,
str_2015,
str_2016,
str_2017,
str_2018,
str_2019,
0, 0, str_201c,
str_201d,
0, 0, 0, 0, 0, 0, str_2024,
str_2025,
str_2026,
0, 0, 0, 0, 0, 0, 0, 0, str_202f,
0, 0, str_2032,
str_2033,
str_2034,
str_2035,
str_2036,
str_2037,
0, str_2039,
str_203a,
0, str_203c,
0, str_203e,
0, 0, 0, 0, 0, 0, 0, 0, str_2047,
str_2048,
str_2049,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_2057,
0, 0, 0, 0, 0, 0, 0, str_205f,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_2070,
str_2071,
0, 0, str_2074,
str_2075,
str_2076,
str_2077,
str_2078,
str_2079,
str_207a,
str_207b,
str_207c,
str_207d,
str_207e,
str_207f,
str_2080,
str_2081,
str_2082,
str_2083,
str_2084,
str_2085,
str_2086,
str_2087,
str_2088,
str_2089,
str_208a,
str_208b,
str_208c,
str_208d,
str_208e,
0, str_2090,
str_2091,
str_2092,
str_2093,
str_2094,
str_2095,
str_2096,
str_2097,
str_2098,
str_2099,
str_209a,
str_209b,
str_209c,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_20a8,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

static const unichar_t * const tab_21[] = {
str_2100,
str_2101,
str_2102,
str_2103,
0, str_2105,
str_2106,
str_2107,
0, str_2109,
str_210a,
str_210b,
str_210c,
str_210d,
str_210e,
str_210f,
str_2110,
str_2111,
str_2112,
str_2113,
0, str_2115,
str_2116,
0, 0, str_2119,
str_211a,
str_211b,
str_211c,
str_211d,
0, 0, str_2120,
str_2121,
str_2122,
0, str_2124,
0, str_2126,
0, str_2128,
0, str_212a,
str_212b,
str_212c,
str_212d,
0, str_212f,
str_2130,
str_2131,
0, str_2133,
str_2134,
str_2135,
str_2136,
str_2137,
str_2138,
str_2139,
0, str_213b,
str_213c,
str_213d,
str_213e,
str_213f,
str_2140,
0, 0, 0, 0, str_2145,
str_2146,
str_2147,
str_2148,
str_2149,
0, 0, 0, 0, 0, 0, str_2150,
str_2151,
str_2152,
str_2153,
str_2154,
str_2155,
str_2156,
str_2157,
str_2158,
str_2159,
str_215a,
str_215b,
str_215c,
str_215d,
str_215e,
str_215f,
str_2160,
str_2161,
str_2162,
str_2163,
str_2164,
str_2165,
str_2166,
str_2167,
str_2168,
str_2169,
str_216a,
str_216b,
str_216c,
str_216d,
str_216e,
str_216f,
str_2170,
str_2171,
str_2172,
str_2173,
str_2174,
str_2175,
str_2176,
str_2177,
str_2178,
str_2179,
str_217a,
str_217b,
str_217c,
str_217d,
str_217e,
str_217f,
0, 0, 0, 0, 0, 0, 0, 0, 0, str_2189,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_219a,
str_219b,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_21ae,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_21cd,
str_21ce,
str_21cf,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

static const unichar_t * const tab_22[] = {
0, 0, 0, 0, str_2204,
str_2205,
str_2206,
0, 0, str_2209,
0, 0, str_220c,
0, 0, str_220f,
0, str_2211,
str_2212,
0, 0, str_2215,
str_2216,
str_2217,
str_2218,
str_2219,
0, 0, 0, 0, 0, 0, 0, 0, 0, str_2223,
str_2224,
str_2225,
str_2226,
0, 0, 0, 0, 0, str_222c,
str_222d,
0, str_222f,
str_2230,
0, 0, 0, 0, 0, str_2236,
0, 0, 0, 0, 0, str_223c,
0, 0, 0, 0, str_2241,
0, 0, str_2244,
0, 0, str_2247,
0, str_2249,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_2260,
0, str_2262,
0, 0, 0, 0, 0, 0, 0, str_226a,
str_226b,
0, str_226d,
str_226e,
str_226f,
str_2270,
str_2271,
0, 0, str_2274,
str_2275,
0, 0, str_2278,
str_2279,
0, 0, 0, 0, 0, 0, str_2280,
str_2281,
0, 0, str_2284,
str_2285,
0, 0, str_2288,
str_2289,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_2299,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_22ac,
str_22ad,
str_22ae,
str_22af,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_22c4,
str_22c5,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_22e0,
str_22e1,
str_22e2,
str_22e3,
0, 0, 0, 0, 0, 0, str_22ea,
str_22eb,
str_22ec,
str_22ed,
0, str_22ef,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

static const unichar_t * const tab_23[] = {
0, 0, 0, str_2303,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_2329,
str_232a,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_2373,
str_2374,
str_2375,
0, 0, 0, 0, str_237a,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

static const unichar_t * const tab_24[] = {
str_2400,
str_2401,
str_2402,
str_2403,
str_2404,
str_2405,
str_2406,
str_2407,
str_2408,
str_2409,
str_240a,
str_240b,
str_240c,
str_240d,
str_240e,
str_240f,
str_2410,
str_2411,
str_2412,
str_2413,
str_2414,
str_2415,
str_2416,
str_2417,
str_2418,
str_2419,
str_241a,
str_241b,
str_241c,
str_241d,
str_241e,
str_241f,
str_2420,
str_2421,
str_2422,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_2460,
str_2461,
str_2462,
str_2463,
str_2464,
str_2465,
str_2466,
str_2467,
str_2468,
str_2469,
str_246a,
str_246b,
str_246c,
str_246d,
str_246e,
str_246f,
str_2470,
str_2471,
str_2472,
str_2473,
str_2474,
str_2475,
str_2476,
str_2477,
str_2478,
str_2479,
str_247a,
str_247b,
str_247c,
str_247d,
str_247e,
str_247f,
str_2480,
str_2481,
str_2482,
str_2483,
str_2484,
str_2485,
str_2486,
str_2487,
str_2488,
str_2489,
str_248a,
str_248b,
str_248c,
str_248d,
str_248e,
str_248f,
str_2490,
str_2491,
str_2492,
str_2493,
str_2494,
str_2495,
str_2496,
str_2497,
str_2498,
str_2499,
str_249a,
str_249b,
str_249c,
str_249d,
str_249e,
str_249f,
str_24a0,
str_24a1,
str_24a2,
str_24a3,
str_24a4,
str_24a5,
str_24a6,
str_24a7,
str_24a8,
str_24a9,
str_24aa,
str_24ab,
str_24ac,
str_24ad,
str_24ae,
str_24af,
str_24b0,
str_24b1,
str_24b2,
str_24b3,
str_24b4,
str_24b5,
str_24b6,
str_24b7,
str_24b8,
str_24b9,
str_24ba,
str_24bb,
str_24bc,
str_24bd,
str_24be,
str_24bf,
str_24c0,
str_24c1,
str_24c2,
str_24c3,
str_24c4,
str_24c5,
str_24c6,
str_24c7,
str_24c8,
str_24c9,
str_24ca,
str_24cb,
str_24cc,
str_24cd,
str_24ce,
str_24cf,
str_24d0,
str_24d1,
str_24d2,
str_24d3,
str_24d4,
str_24d5,
str_24d6,
str_24d7,
str_24d8,
str_24d9,
str_24da,
str_24db,
str_24dc,
str_24dd,
str_24de,
str_24df,
str_24e0,
str_24e1,
str_24e2,
str_24e3,
str_24e4,
str_24e5,
str_24e6,
str_24e7,
str_24e8,
str_24e9,
str_24ea,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

static const unichar_t * const tab_25[] = {
str_2500,
0, str_2502,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_25b3,
0, 0, 0, 0, str_25b8,
0, 0, 0, 0, str_25bd,
0, 0, 0, 0, 0, 0, 0, 0, 0, str_25c7,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_25e6,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

static const unichar_t * const tab_26[] = {
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_2662,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

static const unichar_t * const tab_27[] = {
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_2731,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_2758,
0, 0, 0, 0, 0, 0, 0, 0, 0, str_2762,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

static const unichar_t * const tab_2a[] = {
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_2a0c,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_2a74,
str_2a75,
str_2a76,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_2adc,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

static const unichar_t * const tab_2c[] = {
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_2c7c,
str_2c7d,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

static const unichar_t * const tab_2d[] = {
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_2d6f,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

static const unichar_t * const tab_2e[] = {
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_2e28,
str_2e29,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_2e9f,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_2ef3,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

static const unichar_t * const tab_2f[] = {
str_2f00,
str_2f01,
str_2f02,
str_2f03,
str_2f04,
str_2f05,
str_2f06,
str_2f07,
str_2f08,
str_2f09,
str_2f0a,
str_2f0b,
str_2f0c,
str_2f0d,
str_2f0e,
str_2f0f,
str_2f10,
str_2f11,
str_2f12,
str_2f13,
str_2f14,
str_2f15,
str_2f16,
str_2f17,
str_2f18,
str_2f19,
str_2f1a,
str_2f1b,
str_2f1c,
str_2f1d,
str_2f1e,
str_2f1f,
str_2f20,
str_2f21,
str_2f22,
str_2f23,
str_2f24,
str_2f25,
str_2f26,
str_2f27,
str_2f28,
str_2f29,
str_2f2a,
str_2f2b,
str_2f2c,
str_2f2d,
str_2f2e,
str_2f2f,
str_2f30,
str_2f31,
str_2f32,
str_2f33,
str_2f34,
str_2f35,
str_2f36,
str_2f37,
str_2f38,
str_2f39,
str_2f3a,
str_2f3b,
str_2f3c,
str_2f3d,
str_2f3e,
str_2f3f,
str_2f40,
str_2f41,
str_2f42,
str_2f43,
str_2f44,
str_2f45,
str_2f46,
str_2f47,
str_2f48,
str_2f49,
str_2f4a,
str_2f4b,
str_2f4c,
str_2f4d,
str_2f4e,
str_2f4f,
str_2f50,
str_2f51,
str_2f52,
str_2f53,
str_2f54,
str_2f55,
str_2f56,
str_2f57,
str_2f58,
str_2f59,
str_2f5a,
str_2f5b,
str_2f5c,
str_2f5d,
str_2f5e,
str_2f5f,
str_2f60,
str_2f61,
str_2f62,
str_2f63,
str_2f64,
str_2f65,
str_2f66,
str_2f67,
str_2f68,
str_2f69,
str_2f6a,
str_2f6b,
str_2f6c,
str_2f6d,
str_2f6e,
str_2f6f,
str_2f70,
str_2f71,
str_2f72,
str_2f73,
str_2f74,
str_2f75,
str_2f76,
str_2f77,
str_2f78,
str_2f79,
str_2f7a,
str_2f7b,
str_2f7c,
str_2f7d,
str_2f7e,
str_2f7f,
str_2f80,
str_2f81,
str_2f82,
str_2f83,
str_2f84,
str_2f85,
str_2f86,
str_2f87,
str_2f88,
str_2f89,
str_2f8a,
str_2f8b,
str_2f8c,
str_2f8d,
str_2f8e,
str_2f8f,
str_2f90,
str_2f91,
str_2f92,
str_2f93,
str_2f94,
str_2f95,
str_2f96,
str_2f97,
str_2f98,
str_2f99,
str_2f9a,
str_2f9b,
str_2f9c,
str_2f9d,
str_2f9e,
str_2f9f,
str_2fa0,
str_2fa1,
str_2fa2,
str_2fa3,
str_2fa4,
str_2fa5,
str_2fa6,
str_2fa7,
str_2fa8,
str_2fa9,
str_2faa,
str_2fab,
str_2fac,
str_2fad,
str_2fae,
str_2faf,
str_2fb0,
str_2fb1,
str_2fb2,
str_2fb3,
str_2fb4,
str_2fb5,
str_2fb6,
str_2fb7,
str_2fb8,
str_2fb9,
str_2fba,
str_2fbb,
str_2fbc,
str_2fbd,
str_2fbe,
str_2fbf,
str_2fc0,
str_2fc1,
str_2fc2,
str_2fc3,
str_2fc4,
str_2fc5,
str_2fc6,
str_2fc7,
str_2fc8,
str_2fc9,
str_2fca,
str_2fcb,
str_2fcc,
str_2fcd,
str_2fce,
str_2fcf,
str_2fd0,
str_2fd1,
str_2fd2,
str_2fd3,
str_2fd4,
str_2fd5,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

static const unichar_t * const tab_30[] = {
str_3000,
str_3001,
0, 0, 0, 0, 0, 0, str_3008,
str_3009,
str_300a,
str_300b,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_3036,
0, str_3038,
str_3039,
str_303a,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_304c,
0, str_304e,
0, str_3050,
0, str_3052,
0, str_3054,
0, str_3056,
0, str_3058,
0, str_305a,
0, str_305c,
0, str_305e,
0, str_3060,
0, str_3062,
0, 0, str_3065,
0, str_3067,
0, str_3069,
0, 0, 0, 0, 0, 0, str_3070,
str_3071,
0, str_3073,
str_3074,
0, str_3076,
str_3077,
0, str_3079,
str_307a,
0, str_307c,
str_307d,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_3094,
0, 0, 0, 0, 0, 0, str_309b,
str_309c,
0, str_309e,
str_309f,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_30ac,
0, str_30ae,
0, str_30b0,
0, str_30b2,
0, str_30b4,
0, str_30b6,
0, str_30b8,
0, str_30ba,
0, str_30bc,
0, str_30be,
0, str_30c0,
0, str_30c2,
0, 0, str_30c5,
0, str_30c7,
0, str_30c9,
0, 0, 0, 0, 0, 0, str_30d0,
str_30d1,
0, str_30d3,
str_30d4,
0, str_30d6,
str_30d7,
0, str_30d9,
str_30da,
0, str_30dc,
str_30dd,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_30f4,
0, 0, str_30f7,
str_30f8,
str_30f9,
str_30fa,
0, 0, 0, str_30fe,
str_30ff,
0};

static const unichar_t * const tab_31[] = {
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_3131,
str_3132,
str_3133,
str_3134,
str_3135,
str_3136,
str_3137,
str_3138,
str_3139,
str_313a,
str_313b,
str_313c,
str_313d,
str_313e,
str_313f,
str_3140,
str_3141,
str_3142,
str_3143,
str_3144,
str_3145,
str_3146,
str_3147,
str_3148,
str_3149,
str_314a,
str_314b,
str_314c,
str_314d,
str_314e,
str_314f,
str_3150,
str_3151,
str_3152,
str_3153,
str_3154,
str_3155,
str_3156,
str_3157,
str_3158,
str_3159,
str_315a,
str_315b,
str_315c,
str_315d,
str_315e,
str_315f,
str_3160,
str_3161,
str_3162,
str_3163,
str_3164,
str_3165,
str_3166,
str_3167,
str_3168,
str_3169,
str_316a,
str_316b,
str_316c,
str_316d,
str_316e,
str_316f,
str_3170,
str_3171,
str_3172,
str_3173,
str_3174,
str_3175,
str_3176,
str_3177,
str_3178,
str_3179,
str_317a,
str_317b,
str_317c,
str_317d,
str_317e,
str_317f,
str_3180,
str_3181,
str_3182,
str_3183,
str_3184,
str_3185,
str_3186,
str_3187,
str_3188,
str_3189,
str_318a,
str_318b,
str_318c,
str_318d,
str_318e,
0, 0, 0, str_3192,
str_3193,
str_3194,
str_3195,
str_3196,
str_3197,
str_3198,
str_3199,
str_319a,
str_319b,
str_319c,
str_319d,
str_319e,
str_319f,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

static const unichar_t * const tab_32[] = {
str_3200,
str_3201,
str_3202,
str_3203,
str_3204,
str_3205,
str_3206,
str_3207,
str_3208,
str_3209,
str_320a,
str_320b,
str_320c,
str_320d,
str_320e,
str_320f,
str_3210,
str_3211,
str_3212,
str_3213,
str_3214,
str_3215,
str_3216,
str_3217,
str_3218,
str_3219,
str_321a,
str_321b,
str_321c,
str_321d,
str_321e,
0, str_3220,
str_3221,
str_3222,
str_3223,
str_3224,
str_3225,
str_3226,
str_3227,
str_3228,
str_3229,
str_322a,
str_322b,
str_322c,
str_322d,
str_322e,
str_322f,
str_3230,
str_3231,
str_3232,
str_3233,
str_3234,
str_3235,
str_3236,
str_3237,
str_3238,
str_3239,
str_323a,
str_323b,
str_323c,
str_323d,
str_323e,
str_323f,
str_3240,
str_3241,
str_3242,
str_3243,
str_3244,
str_3245,
str_3246,
str_3247,
0, 0, 0, 0, 0, 0, 0, 0, str_3250,
str_3251,
str_3252,
str_3253,
str_3254,
str_3255,
str_3256,
str_3257,
str_3258,
str_3259,
str_325a,
str_325b,
str_325c,
str_325d,
str_325e,
str_325f,
str_3260,
str_3261,
str_3262,
str_3263,
str_3264,
str_3265,
str_3266,
str_3267,
str_3268,
str_3269,
str_326a,
str_326b,
str_326c,
str_326d,
str_326e,
str_326f,
str_3270,
str_3271,
str_3272,
str_3273,
str_3274,
str_3275,
str_3276,
str_3277,
str_3278,
str_3279,
str_327a,
str_327b,
str_327c,
str_327d,
str_327e,
0, str_3280,
str_3281,
str_3282,
str_3283,
str_3284,
str_3285,
str_3286,
str_3287,
str_3288,
str_3289,
str_328a,
str_328b,
str_328c,
str_328d,
str_328e,
str_328f,
str_3290,
str_3291,
str_3292,
str_3293,
str_3294,
str_3295,
str_3296,
str_3297,
str_3298,
str_3299,
str_329a,
str_329b,
str_329c,
str_329d,
str_329e,
str_329f,
str_32a0,
str_32a1,
str_32a2,
str_32a3,
str_32a4,
str_32a5,
str_32a6,
str_32a7,
str_32a8,
str_32a9,
str_32aa,
str_32ab,
str_32ac,
str_32ad,
str_32ae,
str_32af,
str_32b0,
str_32b1,
str_32b2,
str_32b3,
str_32b4,
str_32b5,
str_32b6,
str_32b7,
str_32b8,
str_32b9,
str_32ba,
str_32bb,
str_32bc,
str_32bd,
str_32be,
str_32bf,
str_32c0,
str_32c1,
str_32c2,
str_32c3,
str_32c4,
str_32c5,
str_32c6,
str_32c7,
str_32c8,
str_32c9,
str_32ca,
str_32cb,
str_32cc,
str_32cd,
str_32ce,
str_32cf,
str_32d0,
str_32d1,
str_32d2,
str_32d3,
str_32d4,
str_32d5,
str_32d6,
str_32d7,
str_32d8,
str_32d9,
str_32da,
str_32db,
str_32dc,
str_32dd,
str_32de,
str_32df,
str_32e0,
str_32e1,
str_32e2,
str_32e3,
str_32e4,
str_32e5,
str_32e6,
str_32e7,
str_32e8,
str_32e9,
str_32ea,
str_32eb,
str_32ec,
str_32ed,
str_32ee,
str_32ef,
str_32f0,
str_32f1,
str_32f2,
str_32f3,
str_32f4,
str_32f5,
str_32f6,
str_32f7,
str_32f8,
str_32f9,
str_32fa,
str_32fb,
str_32fc,
str_32fd,
str_32fe,
0, 0};

static const unichar_t * const tab_33[] = {
str_3300,
str_3301,
str_3302,
str_3303,
str_3304,
str_3305,
str_3306,
str_3307,
str_3308,
str_3309,
str_330a,
str_330b,
str_330c,
str_330d,
str_330e,
str_330f,
str_3310,
str_3311,
str_3312,
str_3313,
str_3314,
str_3315,
str_3316,
str_3317,
str_3318,
str_3319,
str_331a,
str_331b,
str_331c,
str_331d,
str_331e,
str_331f,
str_3320,
str_3321,
str_3322,
str_3323,
str_3324,
str_3325,
str_3326,
str_3327,
str_3328,
str_3329,
str_332a,
str_332b,
str_332c,
str_332d,
str_332e,
str_332f,
str_3330,
str_3331,
str_3332,
str_3333,
str_3334,
str_3335,
str_3336,
str_3337,
str_3338,
str_3339,
str_333a,
str_333b,
str_333c,
str_333d,
str_333e,
str_333f,
str_3340,
str_3341,
str_3342,
str_3343,
str_3344,
str_3345,
str_3346,
str_3347,
str_3348,
str_3349,
str_334a,
str_334b,
str_334c,
str_334d,
str_334e,
str_334f,
str_3350,
str_3351,
str_3352,
str_3353,
str_3354,
str_3355,
str_3356,
str_3357,
str_3358,
str_3359,
str_335a,
str_335b,
str_335c,
str_335d,
str_335e,
str_335f,
str_3360,
str_3361,
str_3362,
str_3363,
str_3364,
str_3365,
str_3366,
str_3367,
str_3368,
str_3369,
str_336a,
str_336b,
str_336c,
str_336d,
str_336e,
str_336f,
str_3370,
str_3371,
str_3372,
str_3373,
str_3374,
str_3375,
str_3376,
str_3377,
str_3378,
str_3379,
str_337a,
str_337b,
str_337c,
str_337d,
str_337e,
str_337f,
str_3380,
str_3381,
str_3382,
str_3383,
str_3384,
str_3385,
str_3386,
str_3387,
str_3388,
str_3389,
str_338a,
str_338b,
str_338c,
str_338d,
str_338e,
str_338f,
str_3390,
str_3391,
str_3392,
str_3393,
str_3394,
str_3395,
str_3396,
str_3397,
str_3398,
str_3399,
str_339a,
str_339b,
str_339c,
str_339d,
str_339e,
str_339f,
str_33a0,
str_33a1,
str_33a2,
str_33a3,
str_33a4,
str_33a5,
str_33a6,
str_33a7,
str_33a8,
str_33a9,
str_33aa,
str_33ab,
str_33ac,
str_33ad,
str_33ae,
str_33af,
str_33b0,
str_33b1,
str_33b2,
str_33b3,
str_33b4,
str_33b5,
str_33b6,
str_33b7,
str_33b8,
str_33b9,
str_33ba,
str_33bb,
str_33bc,
str_33bd,
str_33be,
str_33bf,
str_33c0,
str_33c1,
str_33c2,
str_33c3,
str_33c4,
str_33c5,
str_33c6,
str_33c7,
str_33c8,
str_33c9,
str_33ca,
str_33cb,
str_33cc,
str_33cd,
str_33ce,
str_33cf,
str_33d0,
str_33d1,
str_33d2,
str_33d3,
str_33d4,
str_33d5,
str_33d6,
str_33d7,
str_33d8,
str_33d9,
str_33da,
str_33db,
str_33dc,
str_33dd,
str_33de,
str_33df,
str_33e0,
str_33e1,
str_33e2,
str_33e3,
str_33e4,
str_33e5,
str_33e6,
str_33e7,
str_33e8,
str_33e9,
str_33ea,
str_33eb,
str_33ec,
str_33ed,
str_33ee,
str_33ef,
str_33f0,
str_33f1,
str_33f2,
str_33f3,
str_33f4,
str_33f5,
str_33f6,
str_33f7,
str_33f8,
str_33f9,
str_33fa,
str_33fb,
str_33fc,
str_33fd,
str_33fe,
str_33ff,
0};

static const unichar_t * const tab_a6[] = {
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_a69c,
str_a69d,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

static const unichar_t * const tab_a7[] = {
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_a770,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_a7f8,
str_a7f9,
0, 0, 0, 0, 0, 0, 0};

static const unichar_t * const tab_ab[] = {
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_ab5c,
str_ab5d,
str_ab5e,
str_ab5f,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

static const unichar_t * const tab_f9[] = {
str_f900,
str_f901,
str_f902,
str_f903,
str_f904,
str_f905,
str_f906,
str_f907,
str_f908,
str_f909,
str_f90a,
str_f90b,
str_f90c,
str_f90d,
str_f90e,
str_f90f,
str_f910,
str_f911,
str_f912,
str_f913,
str_f914,
str_f915,
str_f916,
str_f917,
str_f918,
str_f919,
str_f91a,
str_f91b,
str_f91c,
str_f91d,
str_f91e,
str_f91f,
str_f920,
str_f921,
str_f922,
str_f923,
str_f924,
str_f925,
str_f926,
str_f927,
str_f928,
str_f929,
str_f92a,
str_f92b,
str_f92c,
str_f92d,
str_f92e,
str_f92f,
str_f930,
str_f931,
str_f932,
str_f933,
str_f934,
str_f935,
str_f936,
str_f937,
str_f938,
str_f939,
str_f93a,
str_f93b,
str_f93c,
str_f93d,
str_f93e,
str_f93f,
str_f940,
str_f941,
str_f942,
str_f943,
str_f944,
str_f945,
str_f946,
str_f947,
str_f948,
str_f949,
str_f94a,
str_f94b,
str_f94c,
str_f94d,
str_f94e,
str_f94f,
str_f950,
str_f951,
str_f952,
str_f953,
str_f954,
str_f955,
str_f956,
str_f957,
str_f958,
str_f959,
str_f95a,
str_f95b,
str_f95c,
str_f95d,
str_f95e,
str_f95f,
str_f960,
str_f961,
str_f962,
str_f963,
str_f964,
str_f965,
str_f966,
str_f967,
str_f968,
str_f969,
str_f96a,
str_f96b,
str_f96c,
str_f96d,
str_f96e,
str_f96f,
str_f970,
str_f971,
str_f972,
str_f973,
str_f974,
str_f975,
str_f976,
str_f977,
str_f978,
str_f979,
str_f97a,
str_f97b,
str_f97c,
str_f97d,
str_f97e,
str_f97f,
str_f980,
str_f981,
str_f982,
str_f983,
str_f984,
str_f985,
str_f986,
str_f987,
str_f988,
str_f989,
str_f98a,
str_f98b,
str_f98c,
str_f98d,
str_f98e,
str_f98f,
str_f990,
str_f991,
str_f992,
str_f993,
str_f994,
str_f995,
str_f996,
str_f997,
str_f998,
str_f999,
str_f99a,
str_f99b,
str_f99c,
str_f99d,
str_f99e,
str_f99f,
str_f9a0,
str_f9a1,
str_f9a2,
str_f9a3,
str_f9a4,
str_f9a5,
str_f9a6,
str_f9a7,
str_f9a8,
str_f9a9,
str_f9aa,
str_f9ab,
str_f9ac,
str_f9ad,
str_f9ae,
str_f9af,
str_f9b0,
str_f9b1,
str_f9b2,
str_f9b3,
str_f9b4,
str_f9b5,
str_f9b6,
str_f9b7,
str_f9b8,
str_f9b9,
str_f9ba,
str_f9bb,
str_f9bc,
str_f9bd,
str_f9be,
str_f9bf,
str_f9c0,
str_f9c1,
str_f9c2,
str_f9c3,
str_f9c4,
str_f9c5,
str_f9c6,
str_f9c7,
str_f9c8,
str_f9c9,
str_f9ca,
str_f9cb,
str_f9cc,
str_f9cd,
str_f9ce,
str_f9cf,
str_f9d0,
str_f9d1,
str_f9d2,
str_f9d3,
str_f9d4,
str_f9d5,
str_f9d6,
str_f9d7,
str_f9d8,
str_f9d9,
str_f9da,
str_f9db,
str_f9dc,
str_f9dd,
str_f9de,
str_f9df,
str_f9e0,
str_f9e1,
str_f9e2,
str_f9e3,
str_f9e4,
str_f9e5,
str_f9e6,
str_f9e7,
str_f9e8,
str_f9e9,
str_f9ea,
str_f9eb,
str_f9ec,
str_f9ed,
str_f9ee,
str_f9ef,
str_f9f0,
str_f9f1,
str_f9f2,
str_f9f3,
str_f9f4,
str_f9f5,
str_f9f6,
str_f9f7,
str_f9f8,
str_f9f9,
str_f9fa,
str_f9fb,
str_f9fc,
str_f9fd,
str_f9fe,
str_f9ff,
0};

static const unichar_t * const tab_fa[] = {
str_fa00,
str_fa01,
str_fa02,
str_fa03,
str_fa04,
str_fa05,
str_fa06,
str_fa07,
str_fa08,
str_fa09,
str_fa0a,
str_fa0b,
str_fa0c,
str_fa0d,
0, 0, str_fa10,
0, str_fa12,
0, 0, str_fa15,
str_fa16,
str_fa17,
str_fa18,
str_fa19,
str_fa1a,
str_fa1b,
str_fa1c,
str_fa1d,
str_fa1e,
0, str_fa20,
0, str_fa22,
0, 0, str_fa25,
str_fa26,
0, 0, 0, str_fa2a,
str_fa2b,
str_fa2c,
str_fa2d,
str_fa2e,
str_fa2f,
str_fa30,
str_fa31,
str_fa32,
str_fa33,
str_fa34,
str_fa35,
str_fa36,
str_fa37,
str_fa38,
str_fa39,
str_fa3a,
str_fa3b,
str_fa3c,
str_fa3d,
str_fa3e,
str_fa3f,
str_fa40,
str_fa41,
str_fa42,
str_fa43,
str_fa44,
str_fa45,
str_fa46,
str_fa47,
str_fa48,
str_fa49,
str_fa4a,
str_fa4b,
str_fa4c,
str_fa4d,
str_fa4e,
str_fa4f,
str_fa50,
str_fa51,
str_fa52,
str_fa53,
str_fa54,
str_fa55,
str_fa56,
str_fa57,
str_fa58,
str_fa59,
str_fa5a,
str_fa5b,
str_fa5c,
str_fa5d,
str_fa5e,
str_fa5f,
str_fa60,
str_fa61,
str_fa62,
str_fa63,
str_fa64,
str_fa65,
str_fa66,
str_fa67,
str_fa68,
str_fa69,
str_fa6a,
str_fa6b,
str_fa6c,
str_fa6d,
0, 0, str_fa70,
str_fa71,
str_fa72,
str_fa73,
str_fa74,
str_fa75,
str_fa76,
str_fa77,
str_fa78,
str_fa79,
str_fa7a,
str_fa7b,
str_fa7c,
str_fa7d,
str_fa7e,
str_fa7f,
str_fa80,
str_fa81,
str_fa82,
str_fa83,
str_fa84,
str_fa85,
str_fa86,
str_fa87,
str_fa88,
str_fa89,
str_fa8a,
str_fa8b,
str_fa8c,
str_fa8d,
str_fa8e,
str_fa8f,
str_fa90,
str_fa91,
str_fa92,
str_fa93,
str_fa94,
str_fa95,
str_fa96,
str_fa97,
str_fa98,
str_fa99,
str_fa9a,
str_fa9b,
str_fa9c,
str_fa9d,
str_fa9e,
str_fa9f,
str_faa0,
str_faa1,
str_faa2,
str_faa3,
str_faa4,
str_faa5,
str_faa6,
str_faa7,
str_faa8,
str_faa9,
str_faaa,
str_faab,
str_faac,
str_faad,
str_faae,
str_faaf,
str_fab0,
str_fab1,
str_fab2,
str_fab3,
str_fab4,
str_fab5,
str_fab6,
str_fab7,
str_fab8,
str_fab9,
str_faba,
str_fabb,
str_fabc,
str_fabd,
str_fabe,
str_fabf,
str_fac0,
str_fac1,
str_fac2,
str_fac3,
str_fac4,
str_fac5,
str_fac6,
str_fac7,
str_fac8,
str_fac9,
str_faca,
str_facb,
str_facc,
str_facd,
str_face,
str_facf,
str_fad0,
str_fad1,
str_fad2,
str_fad3,
str_fad4,
str_fad5,
str_fad6,
str_fad7,
str_fad8,
str_fad9,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

static const unichar_t * const tab_fb[] = {
str_fb00,
str_fb01,
str_fb02,
str_fb03,
str_fb04,
str_fb05,
str_fb06,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_fb13,
str_fb14,
str_fb15,
str_fb16,
str_fb17,
0, 0, 0, 0, 0, str_fb1d,
0, str_fb1f,
str_fb20,
str_fb21,
str_fb22,
str_fb23,
str_fb24,
str_fb25,
str_fb26,
str_fb27,
str_fb28,
str_fb29,
str_fb2a,
str_fb2b,
str_fb2c,
str_fb2d,
str_fb2e,
str_fb2f,
str_fb30,
str_fb31,
str_fb32,
str_fb33,
str_fb34,
str_fb35,
str_fb36,
0, str_fb38,
str_fb39,
str_fb3a,
str_fb3b,
str_fb3c,
0, str_fb3e,
0, str_fb40,
str_fb41,
0, str_fb43,
str_fb44,
0, str_fb46,
str_fb47,
str_fb48,
str_fb49,
str_fb4a,
str_fb4b,
str_fb4c,
str_fb4d,
str_fb4e,
str_fb4f,
str_fb50,
str_fb51,
str_fb52,
str_fb53,
str_fb54,
str_fb55,
str_fb56,
str_fb57,
str_fb58,
str_fb59,
str_fb5a,
str_fb5b,
str_fb5c,
str_fb5d,
str_fb5e,
str_fb5f,
str_fb60,
str_fb61,
str_fb62,
str_fb63,
str_fb64,
str_fb65,
str_fb66,
str_fb67,
str_fb68,
str_fb69,
str_fb6a,
str_fb6b,
str_fb6c,
str_fb6d,
str_fb6e,
str_fb6f,
str_fb70,
str_fb71,
str_fb72,
str_fb73,
str_fb74,
str_fb75,
str_fb76,
str_fb77,
str_fb78,
str_fb79,
str_fb7a,
str_fb7b,
str_fb7c,
str_fb7d,
str_fb7e,
str_fb7f,
str_fb80,
str_fb81,
str_fb82,
str_fb83,
str_fb84,
str_fb85,
str_fb86,
str_fb87,
str_fb88,
str_fb89,
str_fb8a,
str_fb8b,
str_fb8c,
str_fb8d,
str_fb8e,
str_fb8f,
str_fb90,
str_fb91,
str_fb92,
str_fb93,
str_fb94,
str_fb95,
str_fb96,
str_fb97,
str_fb98,
str_fb99,
str_fb9a,
str_fb9b,
str_fb9c,
str_fb9d,
str_fb9e,
str_fb9f,
str_fba0,
str_fba1,
str_fba2,
str_fba3,
str_fba4,
str_fba5,
str_fba6,
str_fba7,
str_fba8,
str_fba9,
str_fbaa,
str_fbab,
str_fbac,
str_fbad,
str_fbae,
str_fbaf,
str_fbb0,
str_fbb1,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_fbd3,
str_fbd4,
str_fbd5,
str_fbd6,
str_fbd7,
str_fbd8,
str_fbd9,
str_fbda,
str_fbdb,
str_fbdc,
str_fbdd,
str_fbde,
str_fbdf,
str_fbe0,
str_fbe1,
str_fbe2,
str_fbe3,
str_fbe4,
str_fbe5,
str_fbe6,
str_fbe7,
str_fbe8,
str_fbe9,
str_fbea,
str_fbeb,
str_fbec,
str_fbed,
str_fbee,
str_fbef,
str_fbf0,
str_fbf1,
str_fbf2,
str_fbf3,
str_fbf4,
str_fbf5,
str_fbf6,
str_fbf7,
str_fbf8,
str_fbf9,
str_fbfa,
str_fbfb,
str_fbfc,
str_fbfd,
str_fbfe,
str_fbff,
0};

static const unichar_t * const tab_fc[] = {
str_fc00,
str_fc01,
str_fc02,
str_fc03,
str_fc04,
str_fc05,
str_fc06,
str_fc07,
str_fc08,
str_fc09,
str_fc0a,
str_fc0b,
str_fc0c,
str_fc0d,
str_fc0e,
str_fc0f,
str_fc10,
str_fc11,
str_fc12,
str_fc13,
str_fc14,
str_fc15,
str_fc16,
str_fc17,
str_fc18,
str_fc19,
str_fc1a,
str_fc1b,
str_fc1c,
str_fc1d,
str_fc1e,
str_fc1f,
str_fc20,
str_fc21,
str_fc22,
str_fc23,
str_fc24,
str_fc25,
str_fc26,
str_fc27,
str_fc28,
str_fc29,
str_fc2a,
str_fc2b,
str_fc2c,
str_fc2d,
str_fc2e,
str_fc2f,
str_fc30,
str_fc31,
str_fc32,
str_fc33,
str_fc34,
str_fc35,
str_fc36,
str_fc37,
str_fc38,
str_fc39,
str_fc3a,
str_fc3b,
str_fc3c,
str_fc3d,
str_fc3e,
str_fc3f,
str_fc40,
str_fc41,
str_fc42,
str_fc43,
str_fc44,
str_fc45,
str_fc46,
str_fc47,
str_fc48,
str_fc49,
str_fc4a,
str_fc4b,
str_fc4c,
str_fc4d,
str_fc4e,
str_fc4f,
str_fc50,
str_fc51,
str_fc52,
str_fc53,
str_fc54,
str_fc55,
str_fc56,
str_fc57,
str_fc58,
str_fc59,
str_fc5a,
str_fc5b,
str_fc5c,
str_fc5d,
str_fc5e,
str_fc5f,
str_fc60,
str_fc61,
str_fc62,
str_fc63,
str_fc64,
str_fc65,
str_fc66,
str_fc67,
str_fc68,
str_fc69,
str_fc6a,
str_fc6b,
str_fc6c,
str_fc6d,
str_fc6e,
str_fc6f,
str_fc70,
str_fc71,
str_fc72,
str_fc73,
str_fc74,
str_fc75,
str_fc76,
str_fc77,
str_fc78,
str_fc79,
str_fc7a,
str_fc7b,
str_fc7c,
str_fc7d,
str_fc7e,
str_fc7f,
str_fc80,
str_fc81,
str_fc82,
str_fc83,
str_fc84,
str_fc85,
str_fc86,
str_fc87,
str_fc88,
str_fc89,
str_fc8a,
str_fc8b,
str_fc8c,
str_fc8d,
str_fc8e,
str_fc8f,
str_fc90,
str_fc91,
str_fc92,
str_fc93,
str_fc94,
str_fc95,
str_fc96,
str_fc97,
str_fc98,
str_fc99,
str_fc9a,
str_fc9b,
str_fc9c,
str_fc9d,
str_fc9e,
str_fc9f,
str_fca0,
str_fca1,
str_fca2,
str_fca3,
str_fca4,
str_fca5,
str_fca6,
str_fca7,
str_fca8,
str_fca9,
str_fcaa,
str_fcab,
str_fcac,
str_fcad,
str_fcae,
str_fcaf,
str_fcb0,
str_fcb1,
str_fcb2,
str_fcb3,
str_fcb4,
str_fcb5,
str_fcb6,
str_fcb7,
str_fcb8,
str_fcb9,
str_fcba,
str_fcbb,
str_fcbc,
str_fcbd,
str_fcbe,
str_fcbf,
str_fcc0,
str_fcc1,
str_fcc2,
str_fcc3,
str_fcc4,
str_fcc5,
str_fcc6,
str_fcc7,
str_fcc8,
str_fcc9,
str_fcca,
str_fccb,
str_fccc,
str_fccd,
str_fcce,
str_fccf,
str_fcd0,
str_fcd1,
str_fcd2,
str_fcd3,
str_fcd4,
str_fcd5,
str_fcd6,
str_fcd7,
str_fcd8,
str_fcd9,
str_fcda,
str_fcdb,
str_fcdc,
str_fcdd,
str_fcde,
str_fcdf,
str_fce0,
str_fce1,
str_fce2,
str_fce3,
str_fce4,
str_fce5,
str_fce6,
str_fce7,
str_fce8,
str_fce9,
str_fcea,
str_fceb,
str_fcec,
str_fced,
str_fcee,
str_fcef,
str_fcf0,
str_fcf1,
str_fcf2,
str_fcf3,
str_fcf4,
str_fcf5,
str_fcf6,
str_fcf7,
str_fcf8,
str_fcf9,
str_fcfa,
str_fcfb,
str_fcfc,
str_fcfd,
str_fcfe,
str_fcff,
0};

static const unichar_t * const tab_fd[] = {
str_fd00,
str_fd01,
str_fd02,
str_fd03,
str_fd04,
str_fd05,
str_fd06,
str_fd07,
str_fd08,
str_fd09,
str_fd0a,
str_fd0b,
str_fd0c,
str_fd0d,
str_fd0e,
str_fd0f,
str_fd10,
str_fd11,
str_fd12,
str_fd13,
str_fd14,
str_fd15,
str_fd16,
str_fd17,
str_fd18,
str_fd19,
str_fd1a,
str_fd1b,
str_fd1c,
str_fd1d,
str_fd1e,
str_fd1f,
str_fd20,
str_fd21,
str_fd22,
str_fd23,
str_fd24,
str_fd25,
str_fd26,
str_fd27,
str_fd28,
str_fd29,
str_fd2a,
str_fd2b,
str_fd2c,
str_fd2d,
str_fd2e,
str_fd2f,
str_fd30,
str_fd31,
str_fd32,
str_fd33,
str_fd34,
str_fd35,
str_fd36,
str_fd37,
str_fd38,
str_fd39,
str_fd3a,
str_fd3b,
str_fd3c,
str_fd3d,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_fd50,
str_fd51,
str_fd52,
str_fd53,
str_fd54,
str_fd55,
str_fd56,
str_fd57,
str_fd58,
str_fd59,
str_fd5a,
str_fd5b,
str_fd5c,
str_fd5d,
str_fd5e,
str_fd5f,
str_fd60,
str_fd61,
str_fd62,
str_fd63,
str_fd64,
str_fd65,
str_fd66,
str_fd67,
str_fd68,
str_fd69,
str_fd6a,
str_fd6b,
str_fd6c,
str_fd6d,
str_fd6e,
str_fd6f,
str_fd70,
str_fd71,
str_fd72,
str_fd73,
str_fd74,
str_fd75,
str_fd76,
str_fd77,
str_fd78,
str_fd79,
str_fd7a,
str_fd7b,
str_fd7c,
str_fd7d,
str_fd7e,
str_fd7f,
str_fd80,
str_fd81,
str_fd82,
str_fd83,
str_fd84,
str_fd85,
str_fd86,
str_fd87,
str_fd88,
str_fd89,
str_fd8a,
str_fd8b,
str_fd8c,
str_fd8d,
str_fd8e,
str_fd8f,
0, 0, str_fd92,
str_fd93,
str_fd94,
str_fd95,
str_fd96,
str_fd97,
str_fd98,
str_fd99,
str_fd9a,
str_fd9b,
str_fd9c,
str_fd9d,
str_fd9e,
str_fd9f,
str_fda0,
str_fda1,
str_fda2,
str_fda3,
str_fda4,
str_fda5,
str_fda6,
str_fda7,
str_fda8,
str_fda9,
str_fdaa,
str_fdab,
str_fdac,
str_fdad,
str_fdae,
str_fdaf,
str_fdb0,
str_fdb1,
str_fdb2,
str_fdb3,
str_fdb4,
str_fdb5,
str_fdb6,
str_fdb7,
str_fdb8,
str_fdb9,
str_fdba,
str_fdbb,
str_fdbc,
str_fdbd,
str_fdbe,
str_fdbf,
str_fdc0,
str_fdc1,
str_fdc2,
str_fdc3,
str_fdc4,
str_fdc5,
str_fdc6,
str_fdc7,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_fdf0,
str_fdf1,
str_fdf2,
str_fdf3,
str_fdf4,
str_fdf5,
str_fdf6,
str_fdf7,
str_fdf8,
str_fdf9,
str_fdfa,
str_fdfb,
str_fdfc,
0, 0, 0, 0};

static const unichar_t * const tab_fe[] = {
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_fe10,
str_fe11,
str_fe12,
str_fe13,
str_fe14,
str_fe15,
str_fe16,
str_fe17,
str_fe18,
str_fe19,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, str_fe30,
str_fe31,
str_fe32,
str_fe33,
str_fe34,
str_fe35,
str_fe36,
str_fe37,
str_fe38,
str_fe39,
str_fe3a,
str_fe3b,
str_fe3c,
str_fe3d,
str_fe3e,
str_fe3f,
str_fe40,
str_fe41,
str_fe42,
str_fe43,
str_fe44,
0, 0, str_fe47,
str_fe48,
str_fe49,
str_fe4a,
str_fe4b,
str_fe4c,
str_fe4d,
str_fe4e,
str_fe4f,
str_fe50,
str_fe51,
str_fe52,
0, str_fe54,
str_fe55,
str_fe56,
str_fe57,
str_fe58,
str_fe59,
str_fe5a,
str_fe5b,
str_fe5c,
str_fe5d,
str_fe5e,
str_fe5f,
str_fe60,
str_fe61,
str_fe62,
str_fe63,
str_fe64,
str_fe65,
str_fe66,
0, str_fe68,
str_fe69,
str_fe6a,
str_fe6b,
0, 0, 0, 0, str_fe70,
str_fe71,
str_fe72,
0, str_fe74,
0, str_fe76,
str_fe77,
str_fe78,
str_fe79,
str_fe7a,
str_fe7b,
str_fe7c,
str_fe7d,
str_fe7e,
str_fe7f,
str_fe80,
str_fe81,
str_fe82,
str_fe83,
str_fe84,
str_fe85,
str_fe86,
str_fe87,
str_fe88,
str_fe89,
str_fe8a,
str_fe8b,
str_fe8c,
str_fe8d,
str_fe8e,
str_fe8f,
str_fe90,
str_fe91,
str_fe92,
str_fe93,
str_fe94,
str_fe95,
str_fe96,
str_fe97,
str_fe98,
str_fe99,
str_fe9a,
str_fe9b,
str_fe9c,
str_fe9d,
str_fe9e,
str_fe9f,
str_fea0,
str_fea1,
str_fea2,
str_fea3,
str_fea4,
str_fea5,
str_fea6,
str_fea7,
str_fea8,
str_fea9,
str_feaa,
str_feab,
str_feac,
str_fead,
str_feae,
str_feaf,
str_feb0,
str_feb1,
str_feb2,
str_feb3,
str_feb4,
str_feb5,
str_feb6,
str_feb7,
str_feb8,
str_feb9,
str_feba,
str_febb,
str_febc,
str_febd,
str_febe,
str_febf,
str_fec0,
str_fec1,
str_fec2,
str_fec3,
str_fec4,
str_fec5,
str_fec6,
str_fec7,
str_fec8,
str_fec9,
str_feca,
str_fecb,
str_fecc,
str_fecd,
str_fece,
str_fecf,
str_fed0,
str_fed1,
str_fed2,
str_fed3,
str_fed4,
str_fed5,
str_fed6,
str_fed7,
str_fed8,
str_fed9,
str_feda,
str_fedb,
str_fedc,
str_fedd,
str_fede,
str_fedf,
str_fee0,
str_fee1,
str_fee2,
str_fee3,
str_fee4,
str_fee5,
str_fee6,
str_fee7,
str_fee8,
str_fee9,
str_feea,
str_feeb,
str_feec,
str_feed,
str_feee,
str_feef,
str_fef0,
str_fef1,
str_fef2,
str_fef3,
str_fef4,
str_fef5,
str_fef6,
str_fef7,
str_fef8,
str_fef9,
str_fefa,
str_fefb,
str_fefc,
0, 0, 0, 0};

static const unichar_t * const tab_ff[] = {
0, str_ff01,
str_ff02,
str_ff03,
str_ff04,
str_ff05,
str_ff06,
str_ff07,
str_ff08,
str_ff09,
str_ff0a,
str_ff0b,
str_ff0c,
str_ff0d,
str_ff0e,
str_ff0f,
str_ff10,
str_ff11,
str_ff12,
str_ff13,
str_ff14,
str_ff15,
str_ff16,
str_ff17,
str_ff18,
str_ff19,
str_ff1a,
str_ff1b,
str_ff1c,
str_ff1d,
str_ff1e,
str_ff1f,
str_ff20,
str_ff21,
str_ff22,
str_ff23,
str_ff24,
str_ff25,
str_ff26,
str_ff27,
str_ff28,
str_ff29,
str_ff2a,
str_ff2b,
str_ff2c,
str_ff2d,
str_ff2e,
str_ff2f,
str_ff30,
str_ff31,
str_ff32,
str_ff33,
str_ff34,
str_ff35,
str_ff36,
str_ff37,
str_ff38,
str_ff39,
str_ff3a,
str_ff3b,
str_ff3c,
str_ff3d,
str_ff3e,
str_ff3f,
str_ff40,
str_ff41,
str_ff42,
str_ff43,
str_ff44,
str_ff45,
str_ff46,
str_ff47,
str_ff48,
str_ff49,
str_ff4a,
str_ff4b,
str_ff4c,
str_ff4d,
str_ff4e,
str_ff4f,
str_ff50,
str_ff51,
str_ff52,
str_ff53,
str_ff54,
str_ff55,
str_ff56,
str_ff57,
str_ff58,
str_ff59,
str_ff5a,
str_ff5b,
str_ff5c,
str_ff5d,
str_ff5e,
str_ff5f,
str_ff60,
str_ff61,
str_ff62,
str_ff63,
str_ff64,
str_ff65,
str_ff66,
str_ff67,
str_ff68,
str_ff69,
str_ff6a,
str_ff6b,
str_ff6c,
str_ff6d,
str_ff6e,
str_ff6f,
str_ff70,
str_ff71,
str_ff72,
str_ff73,
str_ff74,
str_ff75,
str_ff76,
str_ff77,
str_ff78,
str_ff79,
str_ff7a,
str_ff7b,
str_ff7c,
str_ff7d,
str_ff7e,
str_ff7f,
str_ff80,
str_ff81,
str_ff82,
str_ff83,
str_ff84,
str_ff85,
str_ff86,
str_ff87,
str_ff88,
str_ff89,
str_ff8a,
str_ff8b,
str_ff8c,
str_ff8d,
str_ff8e,
str_ff8f,
str_ff90,
str_ff91,
str_ff92,
str_ff93,
str_ff94,
str_ff95,
str_ff96,
str_ff97,
str_ff98,
str_ff99,
str_ff9a,
str_ff9b,
str_ff9c,
str_ff9d,
str_ff9e,
str_ff9f,
str_ffa0,
str_ffa1,
str_ffa2,
str_ffa3,
str_ffa4,
str_ffa5,
str_ffa6,
str_ffa7,
str_ffa8,
str_ffa9,
str_ffaa,
str_ffab,
str_ffac,
str_ffad,
str_ffae,
str_ffaf,
str_ffb0,
str_ffb1,
str_ffb2,
str_ffb3,
str_ffb4,
str_ffb5,
str_ffb6,
str_ffb7,
str_ffb8,
str_ffb9,
str_ffba,
str_ffbb,
str_ffbc,
str_ffbd,
str_ffbe,
0, 0, 0, str_ffc2,
str_ffc3,
str_ffc4,
str_ffc5,
str_ffc6,
str_ffc7,
0, 0, str_ffca,
str_ffcb,
str_ffcc,
str_ffcd,
str_ffce,
str_ffcf,
0, 0, str_ffd2,
str_ffd3,
str_ffd4,
str_ffd5,
str_ffd6,
str_ffd7,
0, 0, str_ffda,
str_ffdb,
str_ffdc,
0, 0, 0, str_ffe0,
str_ffe1,
str_ffe2,
str_ffe3,
str_ffe4,
str_ffe5,
str_ffe6,
0, str_ffe8,
str_ffe9,
str_ffea,
str_ffeb,
str_ffec,
str_ffed,
str_ffee,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

const unichar_t *const * const unicode_alternates[] = {
tab_0,
tab_1,
tab_2,
tab_3,
tab_4,
tab_5,
tab_6,
up_allzeros, up_allzeros, tab_9,
tab_a,
tab_b,
tab_c,
tab_d,
tab_e,
tab_f,
tab_10,
tab_11,
up_allzeros, tab_13,
up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, tab_1b,
up_allzeros, tab_1d,
tab_1e,
tab_1f,
tab_20,
tab_21,
tab_22,
tab_23,
tab_24,
tab_25,
tab_26,
tab_27,
up_allzeros, up_allzeros, tab_2a,
up_allzeros, tab_2c,
tab_2d,
tab_2e,
tab_2f,
tab_30,
tab_31,
tab_32,
tab_33,
up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, tab_a6,
tab_a7,
up_allzeros, up_allzeros, up_allzeros, tab_ab,
up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, up_allzeros, tab_f9,
tab_fa,
tab_fb,
tab_fc,
tab_fd,
tab_fe,
tab_ff,
0};
