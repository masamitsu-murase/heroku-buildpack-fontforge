#ifndef FONTFORGE_AUTOSAVE_H
#define FONTFORGE_AUTOSAVE_H

extern int DoAutoRecoveryExtended(int inquire);
extern void DoAutoSaves(void);
extern void CleanAutoRecovery(void);

#endif /* FONTFORGE_AUTOSAVE_H */
