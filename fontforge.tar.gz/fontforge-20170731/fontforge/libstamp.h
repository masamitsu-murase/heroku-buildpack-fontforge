#ifndef FONTFORGE_LIBSTAMP_H
#define FONTFORGE_LIBSTAMP_H

extern int check_library_version(Library_Version_Configuration *exe_lib_version, int fatal, int quiet);

#endif /* FONTFORGE_LIBSTAMP_H */
