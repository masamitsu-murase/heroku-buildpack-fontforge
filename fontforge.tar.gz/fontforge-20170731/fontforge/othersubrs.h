#ifndef FONTFORGE_OTHERSUBRS_H
#define FONTFORGE_OTHERSUBRS_H

extern int ReadOtherSubrsFile(char *filename);
extern void DefaultOtherSubrs(void);

#endif /* FONTFORGE_OTHERSUBRS_H */
