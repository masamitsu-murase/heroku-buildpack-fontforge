#ifndef FONTFORGE_SPLINEREFIGURE_H
#define FONTFORGE_SPLINEREFIGURE_H

#include "splinefont.h"

extern void SplineRefigure3(Spline *spline);

#endif /* FONTFORGE_SPLINEREFIGURE_H */
