#ifndef FONTFORGE_TABLES_H
#define FONTFORGE_TABLES_H

/* Declarations for data tables */

extern const int amspua[], cns14pua[];
extern const char (*SaveTablesPref[]);

#endif /* FONTFORGE_TABLES_H */
